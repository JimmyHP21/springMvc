

CREATE PROCEDURE [dbo].[SPGet_Contas] @convenio     BIGINT = NULL,
									   @dataInicial  DATETIME = NULL,
									   @dataFinal    DATETIME = NULL,
                                       @registro     BIGINT = NULL,
                                       @tipoRegistro VARCHAR(max) = NULL
AS
  BEGIN
      IF @tipoRegistro = ''
        SET @tipoRegistro = NULL;

      IF @convenio = 0
        SET @convenio = NULL;

      IF @registro = 0
        SET @registro = NULL;

      SET @tipoRegistro = UPPER(@tipoRegistro);

      SELECT *
      FROM   (SELECT ISNULL(ATEND.FATURACONTA,0)      AS fatura,
                     ( CASE
                         WHEN FAT_PARC.REGISTRO_INTERNO IS NULL THEN 'TOTAL'
                         ELSE 'FINAL'
                       END )                AS tipoFatura,
                     ATEND.DATAFATURAMENTO  AS dataFaturamento,
                     'INTERNO'              AS tipoRegistro,
                     ATEND.REGISTRO         AS registroInicial,
                     ATEND.REGISTRO         AS registro,
                     ATEND.CONVENIO         AS convenio,
                     PAC.NOME               AS nome,
                     ISNULL(ATEND.VALORTOTALCONTA,0)  AS valorTotal,
                     ISNULL(ATEND.VALORMATMED,0)      AS valorTotalMatMed,
                     ISNULL(ATEND.VALORINSUMO,0)      AS valorTotalInsumo,
                     ISNULL(ATEND.VALORDIAGNOSTICO,0) AS valorTotalDiagnostico,
                     ISNULL(ATEND.VALORHONORARIO,0)   AS valorTotalHonorario,
                     ISNULL(ATEND.VALORMATERIAL,0)    AS valorTotalMaterial,
                     ISNULL(ATEND.VALORMEDICAMENTO,0) AS ValorTotalMedicamento
              FROM   INTERNO AS ATEND WITH (READPAST)
								
                     INNER JOIN FICHAS AS PAC WITH (READPAST)
                             ON PAC.FICHA = ATEND.FICHA
							
                     LEFT JOIN (SELECT DISTINCT EXT.REGISTRO_INTERNO
                                FROM   FAT_INTERNO_EXTERNO EXT) FAT_PARC
                            ON FAT_PARC.REGISTRO_INTERNO = ATEND.REGISTRO                     

              WHERE  ATEND.DATAINTERNACAO >= @dataInicial AND ATEND.DATAINTERNACAO < @dataFinal
                     AND 'INTERNO' = isnull(@tipoRegistro, 'INTERNO')
					 AND (ATEND.REGISTRO = @registro OR @registro IS NULL)
					 AND (ATEND.CONVENIO = @convenio OR @convenio IS NULL)
					 
              UNION ALL
              SELECT ISNULL(ATEND.FATURACONTA,0)      AS fatura,
                     'TOTAL'                AS tipoFatura,
                     ATEND.DATAFATURAMENTO  AS dataFaturamento,
                     ( CASE
                         WHEN ATEND.AMBUPA = 1 THEN 'AMBULATORIAL'
                         WHEN ATEND.AMBUPA = 2 THEN 'URGENCIA'
                       END )                AS tipoRegistro,
                     ATEND.REGISTRO         AS registroInicial,
                     ATEND.REGISTRO         AS registro,
                     ATEND.CONVENIO         AS convenio,
                     PAC.NOME               AS nome,
                     ISNULL(ATEND.VALORTOTALCONTA,0)  AS valorTotal,
                     ISNULL(ATEND.VALORMATMED,0)      AS valorTotalMatMed,
                     ISNULL(ATEND.VALORINSUMO,0)      AS valorTotalInsumo,
                     ISNULL(ATEND.VALORDIAGNOSTICO,0) AS valorTotalDiagnostico,
                     ISNULL(ATEND.VALORHONORARIO,0)   AS valorTotalHonorario,
                     ISNULL(ATEND.VALORMATERIAL,0)    AS valorTotalMaterial,
                     ISNULL(ATEND.VALORMEDICAMENTO,0) AS ValorTotalMedicamento
              FROM   AMBULATORIAL AS ATEND WITH (READPAST)																 
                     INNER JOIN FICHAS AS PAC WITH (READPAST)
                             ON PAC.FICHA = ATEND.FICHA
							
              WHERE  ATEND.DATAINTERNACAO >= @dataInicial AND ATEND.DATAINTERNACAO < @dataFinal
                     AND ( ( 'AMBULATORIAL' = isnull(@tipoRegistro, 'AMBULATORIAL')
                             AND ATEND.AMBUPA = 1 )
                            OR ( 'URGENCIA' = isnull(@tipoRegistro, 'URGENCIA')
                                 AND ATEND.AMBUPA = 2 ) )
					 AND (ATEND.REGISTRO = @registro OR @registro IS NULL)
					 AND (ATEND.CONVENIO = @convenio OR @convenio IS NULL)

              UNION ALL
              SELECT ISNULL(ATEND.FATURACONTA,0)                                       AS fatura,
                     ( CASE
                         WHEN FAT_PARC.REGISTRO_INTERNO IS NULL THEN 'TOTAL'
                         ELSE 'PARCIAL'
                       END )                                                 AS tipoFatura,
                     ISNULL(FAT_PARC.DATAFATURAMENTO, ATEND.DATAFATURAMENTO) AS dataFaturamento,
                     ( CASE
                         WHEN FAT_PARC.REGISTRO_INTERNO IS NULL THEN 'EXTERNO'
                         ELSE 'INTERNO'
                       END )                                                 AS tipoRegistro,
                     ISNULL(FAT_PARC.REGISTRO_INTERNO, ATEND.REGISTRO)       AS registroInicial,
                     ATEND.REGISTRO                                          AS registro,
                     ATEND.CONVENIO                                          AS convenio,
                     PAC.NOME                                                AS nome,
                     ISNULL(ATEND.VALORTOTALCONTA,0)  						 AS valorTotal,
                     ISNULL(ATEND.VALORMATMED,0)      						 AS valorTotalMatMed,
                     ISNULL(ATEND.VALORINSUMO,0)      						 AS valorTotalInsumo,
                     ISNULL(ATEND.VALORDIAGNOSTICO,0) 						 AS valorTotalDiagnostico,
                     ISNULL(ATEND.VALORHONORARIO,0)   						 AS valorTotalHonorario,
                     ISNULL(ATEND.VALORMATERIAL,0)    						 AS valorTotalMaterial,
                     ISNULL(ATEND.VALORMEDICAMENTO,0) 						 AS ValorTotalMedicamento
              FROM   EXTERNO AS ATEND WITH (READPAST)

  					 INNER JOIN FICHAS AS PAC WITH (READPAST)
                             ON PAC.FICHA = ATEND.FICHA
							
                     LEFT JOIN FAT_INTERNO_EXTERNO FAT_PARC WITH (READPAST)
                            ON FAT_PARC.REGISTRO_EXTERNO = ATEND.REGISTRO
							
              WHERE  ATEND.DATAINTERNACAO >= @dataInicial AND ATEND.DATAINTERNACAO < @dataFinal
                     AND ( 'EXTERNO' = ISNULL(@tipoRegistro, 'EXTERNO')
                            OR ('INTERNO' = ISNULL(@tipoRegistro, 'INTERNO') AND FAT_PARC.REGISTRO_INTERNO IS NOT NULL))
					 AND (ATEND.REGISTRO = @registro OR @registro IS NULL)
					 AND (ATEND.CONVENIO = @convenio OR @convenio IS NULL)) T
      ORDER  BY T.FATURA,
                T.TIPOREGISTRO,
                T.REGISTRO
  END
go

