

CREATE PROCEDURE SP_TISS_030200_CABECALHO @TIPO_TRANSACAO   VARCHAR(MAX),
                                          @CONVENIO         BIGINT,
                                          @CODIGO_PRESTADOR VARCHAR(14) = NULL,
										  @WEB_SERVICE		BIT = 0
AS
  BEGIN
      SELECT
      ------------------------------------------------------------------------------------------------------------------------------------------------
      ----------CABEÇALHO DAS MENSAGENS---------------------------------------------------------------------------------------------------------------
      ------------------------------------------------------------------------------------------------------------------------------------------------
	  
      ------------------------------------------------------------------------------------------------------------------------------------------------
      ----------IDENTIFICAÇÃO DA MENSAGEM-------------------------------------------------------------------------------------------------------------
      ------------------------------------------------------------------------------------------------------------------------------------------------
      @TIPO_TRANSACAO                                             AS cabecalhoIdentificacaoTransacaoTipoTransacao,--Tipo de transação String Nome do tipo de transação. Obrigatório.
      LEFT(CAST(CAST(GETDATE() AS TIMESTAMP) AS BIGINT), 12)      AS cabecalhoIdentificacaoTransacaoSequencialTransacao,--Sequencial da transação String 12 Identificador da transação eletrônica Obrigatório.
      CONVERT(VARCHAR, GETDATE(), 103)                            AS cabecalhoIdentificacaoTransacaoDataRegistroTransacao,--Data de registro da transação eletrônica Date 8 DDMMAAAA Data de registro da transação eletrônica Obrigatório.
      CONVERT(VARCHAR, GETDATE(), 108)                            AS cabecalhoIdentificacaoTransacaoHoraRegistroTransacao,--Hora de registro da transação Time 8 HH:MM:SS Hora de registro da transação eletrônica Obrigatório.
      ''                                                          AS cabecalhoFalhaNegocio,--Código da mensagem de retorno String 4 Código da mensagem de retorno, conforme tabela de domínio nº 38. Condicionado. Deve ser preenchido quando a operadora for informar algum retorno à comunicação enviada pelo prestador.
	  CASE WHEN @WEB_SERVICE = 1 THEN
		  CASE ISNULL(CONV.VERSAOGUIATISSWS ,3)
			  WHEN 0 THEN '2.02.03'
			  WHEN 3 THEN '3.02.00'
			  WHEN 4 THEN '3.02.01'
			  WHEN 1 THEN '3.02.02'
			  WHEN 2 THEN '3.03.00'
			  WHEN 5 THEN '3.03.01'
			  WHEN 6 THEN '3.03.02'
			  WHEN 7 THEN '3.03.03'
		  END 
	 ELSE
		CASE ISNULL(CONV.VERSAOGUIATISS ,3)
			  WHEN 0 THEN '2.02.03'
			  WHEN 3 THEN '3.02.00'
			  WHEN 4 THEN '3.02.01'
			  WHEN 1 THEN '3.02.02'
			  WHEN 2 THEN '3.03.00'
			  WHEN 5 THEN '3.03.01'
			  WHEN 6 THEN '3.03.02'
			  WHEN 7 THEN '3.03.03'
		  END
	END															  AS cabecalhoVersaoPadrao,--Versão do padrão String 7 Versão do Padrão TISS em que a transação está ocorrendo Obrigatório.
      ''                                                          AS cabecalhoLoginSenhaPrestadorLoginPrestador,--Login String 20 Login do prestador de serviços que está encaminhando a mensagem na operadora.Condicionado. Deve ser preenchido quando o prestador consumir webservice da operadora sem a utilização de certificado digital
      ''                                                          AS cabecalhoLoginSenhaPrestadorSenhaPrestador,--Senha String 20 Senha do prestador de serviços que está encaminhando a mensagem na operadora. Condicionado. Deve ser preenchido quando o prestador consumir webservice da operadora sem a utilização de certificado digital.
      ------------------------------------------------------------------------------------------------------------------------------------------------
      ----------IDENTIFICAÇÃO DA ORIGEM DA MENSAGEM---------------------------------------------------------------------------------------------------
      ------------------------------------------------------------------------------------------------------------------------------------------------	  	  
      ( CASE
          WHEN ISNULL(ISNULL(@CODIGO_PRESTADOR, CONV.CODIGOTISS), '') <> '' THEN
			(CASE WHEN DBO.FN_VALIDACPFCNPJ(DBO.FN_SONUMERICO(ISNULL(ISNULL(@CODIGO_PRESTADOR, CONV.CODIGOTISS), ''))) = 1  
				  THEN 'CNPJ'
				  ELSE 'CODIGO'
			END)
		  WHEN DBO.FN_VALIDACPFCNPJ(DBO.FN_SONUMERICO(ISNULL(PAR.CGC, ''))) = 1  
		  THEN 'CNPJ'
          ELSE 'CODIGO'
        END )                                                     AS cabecalhoOrigemIdentificacaoPrestadorItemTipo,
      ( CASE
          WHEN ISNULL(ISNULL(@CODIGO_PRESTADOR, CONV.CODIGOTISS), '') <> '' 
          THEN ISNULL(@CODIGO_PRESTADOR, CONV.CODIGOTISS)
          ELSE PAR.CGC
        END )													  AS cabecalhoOrigemIdentificacaoPrestadorItem,--Código do contratado executante na operadora String 14 Código identificador do prestador contratado executante junto a operadora, conforme contrato estabelecido. Obrigatório.
      ------------------------------------------------------------------------------------------------------------------------------------------------
      ----------IDENTIFICAÇÃO DO DESTINO DA MENSAGEM--------------------------------------------------------------------------------------------------
      ------------------------------------------------------------------------------------------------------------------------------------------------	  
      RIGHT(REPLICATE('0',6) + CAST(CONV.REGISTROANS AS VARCHAR(6)),6)  AS cabecalhoDestinoRegistroANS --Registro ANS String 6 Registro da operadora de plano privado de assistência à saúde na Agência Nacional de Saúde Suplementar (ANS) Obrigatório.
      FROM   CONVENIOS AS CONV WITH (READPAST)
             CROSS JOIN PARAMETROS AS PAR WITH (READPAST)
      WHERE  CONV.CONVENIO = @CONVENIO
  END
go

