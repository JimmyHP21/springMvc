 
-- =============================================
-- AUTHOR:		M2 TECNOLOGIA
-- CREATE DATE:	28/06/2016
-- DESCRIPTION:	
-- REVISIONS:	
-- =============================================
CREATE PROCEDURE DBO.SPD_TISS_VERSAO_MENSAGEM
	@ID INT 
AS
BEGIN
	SET NOCOUNT ON
	DELETE FROM DBO.TISS_VERSAO_MENSAGEM
	WHERE
		ID = @ID
END
go

