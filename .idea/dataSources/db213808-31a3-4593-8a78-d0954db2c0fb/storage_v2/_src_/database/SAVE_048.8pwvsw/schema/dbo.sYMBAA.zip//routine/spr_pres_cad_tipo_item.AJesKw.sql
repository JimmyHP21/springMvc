-- =============================================
-- author:		m2 tecnologia
-- create date:	27/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_pres_cad_tipo_item
	@id int = null,
	@descricao varchar(50) = null,
	@ordemimpressao int = null,
	@utilizavia int = null,
	@utilizaunidade int = null,
	@atualizacao varchar(150) = null,
	@utilizaintervalo int = null,
	@utilizaapresentacao int = null,
	@log bigint = null,
	@utilizaprodutoestoque int = null,
	@exibe_em_dispensacao int = null,
	@exibe_em_impressao int = null,
	@assoc_material int = null,
	@assoc_medicamento int = null,
	@assoc_procedimento int = null,
	@assoc_taxa int = null,
	@exibe_em_prescricao int = null
as
begin
	set nocount on
	select
	 id, descricao, ordemimpressao, utilizavia, utilizaunidade, atualizacao, utilizaintervalo, utilizaapresentacao, log, utilizaprodutoestoque, exibe_em_dispensacao, exibe_em_impressao, assoc_material, assoc_medicamento, assoc_procedimento, assoc_taxa, exibe_em_prescricao
	from dbo.pres_cad_tipo_item
where (id = @id or @id is null )
 and (descricao = @descricao or @descricao is null )
 and (ordemimpressao = @ordemimpressao or @ordemimpressao is null )
 and (utilizavia = @utilizavia or @utilizavia is null )
 and (utilizaunidade = @utilizaunidade or @utilizaunidade is null )
 and (atualizacao = @atualizacao or @atualizacao is null )
 and (utilizaintervalo = @utilizaintervalo or @utilizaintervalo is null )
 and (utilizaapresentacao = @utilizaapresentacao or @utilizaapresentacao is null )
 and (log = @log or @log is null )
 and (utilizaprodutoestoque = @utilizaprodutoestoque or @utilizaprodutoestoque is null )
 and (exibe_em_dispensacao = @exibe_em_dispensacao or @exibe_em_dispensacao is null )
 and (exibe_em_impressao = @exibe_em_impressao or @exibe_em_impressao is null )
 and (assoc_material = @assoc_material or @assoc_material is null )
 and (assoc_medicamento = @assoc_medicamento or @assoc_medicamento is null )
 and (assoc_procedimento = @assoc_procedimento or @assoc_procedimento is null )
 and (assoc_taxa = @assoc_taxa or @assoc_taxa is null )
 and (exibe_em_prescricao = @exibe_em_prescricao or @exibe_em_prescricao is null )
end
go

