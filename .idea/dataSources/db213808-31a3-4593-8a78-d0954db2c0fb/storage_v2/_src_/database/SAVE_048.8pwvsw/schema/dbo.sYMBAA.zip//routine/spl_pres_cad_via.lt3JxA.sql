-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spl_pres_cad_via

as
begin
	set nocount on
	select
	 via, descricao, atualizacao
	from dbo.pres_cad_via
end
go

