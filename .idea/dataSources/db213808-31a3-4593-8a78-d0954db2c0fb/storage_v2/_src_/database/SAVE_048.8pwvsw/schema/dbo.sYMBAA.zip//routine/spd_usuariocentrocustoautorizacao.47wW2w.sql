-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spd_usuariocentrocustoautorizacao
	@usuario int ,
	@centrocusto smallint 
as
begin
	set nocount on
	delete from dbo.usuariocentrocustoautorizacao
	where
		usuario = @usuario
		and centrocusto = @centrocusto
end
go

