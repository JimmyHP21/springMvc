
-- =============================================
-- Author:		SSRM2 
-- Create date:	25/08/2014
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPDel_TUSS_TAB42	@CODIGO nvarchar(255)
AS
BEGIN
	SET NOCOUNT ON
	DELETE FROM TUSS_TAB42
	WHERE
		CODIGO = @CODIGO
END
go

