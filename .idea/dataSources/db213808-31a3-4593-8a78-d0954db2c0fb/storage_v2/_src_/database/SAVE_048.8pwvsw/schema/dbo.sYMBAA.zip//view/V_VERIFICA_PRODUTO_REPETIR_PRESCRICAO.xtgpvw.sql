CREATE VIEW V_VERIFICA_PRODUTO_REPETIR_PRESCRICAO
AS

	--ESTA VIEW VERIFICA SE A PRESCRIÇÃO DO PACIENTE ATENDE AOS TESTES DE REPETIR 

	 SELECT A.REGISTRO, A.NOTA 
	 FROM MOVIM_PRES_INT A INNER JOIN PRODUTO B ON A.PROCEDIMENTO = B.PRODUTO 
	                       LEFT  JOIN PRODUTOCENTROCUSTO C ON A.PROCEDIMENTO = C.PRODUTO 
	                                                      AND A.CENTROCUSTO = C.CENTROCUSTO 
	 WHERE 1 = 1
	 AND   A.REGISTRO = 179013
--	 AND   A.NOTA = 79580
	 AND   A.PROCEDIMENTO NOT IN (SELECT D.PRODUTO 
	                          FROM PRES_PRODUTO_CONTROLE D 
	                          WHERE A.REGISTRO = D.REGISTRO
	                          AND   A.PROCEDIMENTO = B.PRODUTO 
	                          AND   A.NOTA = D.PRESCRICAO )
	 UNION ALL 
	 SELECT A.REGISTRO, A.NOTA 
	 FROM MOVIM_PRES_INT A INNER JOIN PRODUTO B ON A.PROCEDIMENTO = B.PRODUTO 
	                       LEFT  JOIN PRODUTOCENTROCUSTO C ON A.PROCEDIMENTO = C.PRODUTO 
	                                                      AND A.CENTROCUSTO = C.CENTROCUSTO 
	                       INNER  JOIN PRES_PRODUTO_REPETIR D ON A.REGISTRO = D.REGISTRO 
	                                                        AND A.NOTA = D.PRESCRICAO 
	                                                        AND A.PROCEDIMENTO = D.PRODUTO 
	                       INNER JOIN PRES_PRODUTO_CONTROLE E ON A.REGISTRO = E.REGISTRO  
	                                                         AND A.NOTA = E.PRESCRICAO 
	                                                         AND A.PROCEDIMENTO = E.PRODUTO 
	 WHERE 1 = 1
	 AND   A.REGISTRO = 179013
--	 AND   A.NOTA = 79580
	 AND   (ISNULL(D.DIAS_REPETIR,0) <> ISNULL(D.DIAS_REPETIDO,0))
	 AND   ISNULL(A.PRES_INTERVALO_DIA,0) = 0 
	 UNION ALL 
	 SELECT A.REGISTRO, A.NOTA 
	 FROM MOVIM_PRES_INT A INNER JOIN PRODUTO B ON A.PROCEDIMENTO = B.PRODUTO 
	                       LEFT  JOIN PRODUTOCENTROCUSTO C ON A.PROCEDIMENTO = C.PRODUTO 
	                                                      AND A.CENTROCUSTO = C.CENTROCUSTO 
	                       INNER JOIN PRES_PRODUTO_CONTROLE E ON A.REGISTRO = E.REGISTRO  
	                                                         AND A.NOTA = E.PRESCRICAO 
	                                                         AND A.PROCEDIMENTO = E.PRODUTO 
	 WHERE 1 = 1
	 AND   A.REGISTRO = 179013
--	 AND   A.NOTA = 79580
         AND   (CONVERT(CHAR(10),DATEADD(DAY, ISNULL(PRES_INTERVALO_DIA,0),E.DATA_ULTIMA_REALIZACAO),103) = '02/12/2008')
	 AND   ISNULL(A.PRES_INTERVALO_DIA,0) <> 0 
	 AND   A.PROCEDIMENTO NOT IN (SELECT D.PRODUTO 
	                          FROM PRES_PRODUTO_REPETIR D 
	                          WHERE A.REGISTRO = D.REGISTRO
	                          AND   A.PROCEDIMENTO = B.PRODUTO 
	                          AND   A.NOTA = D.PRESCRICAO )
	 UNION ALL 
	 SELECT A.REGISTRO, A.NOTA 
	 FROM MOVIM_PRES_INT A INNER JOIN PRODUTO B ON A.PROCEDIMENTO = B.PRODUTO 
	                       LEFT  JOIN PRODUTOCENTROCUSTO C ON A.PROCEDIMENTO = C.PRODUTO 
	                                                      AND A.CENTROCUSTO = C.CENTROCUSTO 
	                       INNER  JOIN PRES_PRODUTO_REPETIR D ON A.REGISTRO = D.REGISTRO 
	                                                        AND A.NOTA = D.PRESCRICAO 
	                                                        AND A.PROCEDIMENTO = D.PRODUTO 
	                       INNER JOIN PRES_PRODUTO_CONTROLE E ON A.REGISTRO = E.REGISTRO  
	                                                         AND A.NOTA = E.PRESCRICAO 
	                                                         AND A.PROCEDIMENTO = E.PRODUTO 
	 WHERE 1 = 1
	 AND   A.REGISTRO = 179013
--	 AND   A.NOTA = 79580
	 AND   (ISNULL(D.DIAS_REPETIR,0) <> ISNULL(D.DIAS_REPETIDO,0))
	 AND   (CONVERT(CHAR(10),DATEADD(DAY, ISNULL(PRES_INTERVALO_DIA,0),E.DATA_ULTIMA_REALIZACAO),103) = '02/12/2008')
	 AND   ISNULL(A.PRES_INTERVALO_DIA,0) <> 0
go

