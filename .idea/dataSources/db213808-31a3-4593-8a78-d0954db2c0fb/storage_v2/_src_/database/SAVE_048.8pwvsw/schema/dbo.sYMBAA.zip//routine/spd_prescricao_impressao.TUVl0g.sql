-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spd_prescricao_impressao
	@id bigint 
as
begin
	set nocount on
	delete from dbo.prescricao_impressao
	where
		id = @id
end
go

