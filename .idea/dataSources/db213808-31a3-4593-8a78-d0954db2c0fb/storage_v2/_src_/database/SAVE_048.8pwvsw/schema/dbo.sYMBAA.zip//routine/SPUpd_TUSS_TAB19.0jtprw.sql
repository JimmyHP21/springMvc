
-- =============================================
-- Author:		SSRM2 
-- Create date:	25/08/2014
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPUpd_TUSS_TAB19	@CODIGO int,
	@DESCRICAO nvarchar(255),
	@REFERENCIA nvarchar(255),
	@FABRICANTE nvarchar(255),
	@INICIOVIGENCIA datetime,
	@FIMVIGENCIA datetime,
	@FIMIMPLANTACAO datetime
AS
BEGIN
	SET NOCOUNT ON
	UPDATE TUSS_TAB19
	SET
		DESCRICAO = @DESCRICAO,
		REFERENCIA = @REFERENCIA,
		FABRICANTE = @FABRICANTE,
		INICIOVIGENCIA = @INICIOVIGENCIA,
		FIMVIGENCIA = @FIMVIGENCIA,
		FIMIMPLANTACAO = @FIMIMPLANTACAO
	WHERE
		CODIGO = @CODIGO
END
go

