 
-- =============================================
-- AUTHOR:		M2 TECNOLOGIA
-- CREATE DATE:	28/06/2016
-- DESCRIPTION:	
-- REVISIONS:	
-- =============================================
CREATE PROCEDURE DBO.SPD_TISS_LOTEGUIA
	@ID BIGINT 
AS
BEGIN
	SET NOCOUNT ON
	DELETE FROM DBO.TISS_LOTEGUIA
	WHERE
		ID = @ID
END
go

