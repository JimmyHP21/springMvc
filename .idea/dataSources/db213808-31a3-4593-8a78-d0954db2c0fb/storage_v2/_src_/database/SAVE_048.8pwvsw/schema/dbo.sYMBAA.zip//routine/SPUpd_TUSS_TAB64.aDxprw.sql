 
-- =============================================
-- Author:		M2 TECNOLOGIA
-- Create date:	06/09/2017
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPUpd_TUSS_TAB64	@TERMINOLOGIA varchar(2),
	@CODIGOTUSS varchar(10),
	@INICIOVIGENCIA datetime,
	@ENVIO varchar(40),
	@GRUPO varchar(1000),
	@DESCRICAO varchar(1000),
	@FIMVIGENCIA datetime,
	@FIMIMPLANTACAO datetime
AS
BEGIN
	SET NOCOUNT ON
	UPDATE TUSS_TAB64
	SET
		ENVIO = @ENVIO,
		GRUPO = @GRUPO,
		DESCRICAO = @DESCRICAO,
		FIMVIGENCIA = @FIMVIGENCIA,
		FIMIMPLANTACAO = @FIMIMPLANTACAO
	WHERE
		TERMINOLOGIA = @TERMINOLOGIA
		AND CODIGOTUSS = @CODIGOTUSS
		AND INICIOVIGENCIA = @INICIOVIGENCIA
END
go

