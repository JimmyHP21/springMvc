
create proc spx_add_primary_key
	@const_name nvarchar(max) = null,	
	@schema nvarchar(max) = 'dbo',
	@table nvarchar(max),
	@table_cols nvarchar(max), 
	@read_only bit = 1
as
begin
	declare @crlf nvarchar(6)
	declare @cmd nvarchar(max)	
	
	if @const_name is null
		set @const_name = 'pk_' + @table
		
	set @const_name = replace(replace(replace(@const_name,',','_'),' ',''),'.','_')
	set @crlf = char(13)+char(10)
	set @cmd = 'alter table "' + @schema + '"."' + @table +'"'+ @crlf +
				case when isnull(@const_name,'') <> '' then 'add constraint "' + @const_name +'"' + @crlf else @crlf + 'add ' end +
			   'primary key clustered (' + @table_cols + ');';
	print @cmd;
	if @read_only <> 1 exec(@cmd);
end
go

