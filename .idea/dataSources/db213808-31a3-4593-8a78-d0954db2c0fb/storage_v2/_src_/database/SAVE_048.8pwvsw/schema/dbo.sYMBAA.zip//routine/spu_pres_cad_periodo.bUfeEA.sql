-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spu_pres_cad_periodo
	@id int ,
	@descricao varchar(255) ,
	@hora_inicio datetime  = null,
	@hora_fim datetime  = null,
	@hora_padrao datetime ,
	@cor_rotulo varchar(15)  = null,
	@ordem_exibicao int  = null,
	@atualizacao varchar(150)  = null,
	@log bigint  = null
as
begin
	set nocount on
	update dbo.pres_cad_periodo
	set
		descricao = @descricao,
		hora_inicio = @hora_inicio,
		hora_fim = @hora_fim,
		hora_padrao = @hora_padrao,
		cor_rotulo = @cor_rotulo,
		ordem_exibicao = @ordem_exibicao,
		atualizacao = @atualizacao,
		log = @log
	where
		id = @id
end
go

