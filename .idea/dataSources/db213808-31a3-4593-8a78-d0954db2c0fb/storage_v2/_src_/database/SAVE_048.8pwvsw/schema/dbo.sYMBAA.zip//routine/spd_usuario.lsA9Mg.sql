-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spd_usuario
	@usuario int 
as
begin
	set nocount on
	delete from dbo.usuario
	where
		usuario = @usuario
end
go

