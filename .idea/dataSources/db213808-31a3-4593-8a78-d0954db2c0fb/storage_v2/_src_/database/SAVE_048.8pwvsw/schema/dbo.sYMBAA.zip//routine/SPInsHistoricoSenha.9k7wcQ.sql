 CREATE PROCEDURE SPInsHistoricoSenha @id_usuario integer, 
                                    @dataInclusao datetime, 
                                    @senhaAntiga varchar(15) 
 as 
 begin 
   SET NOCOUNT ON 
   INSERT INTO [dbo].[HISTORICO_SENHA] 
              ([ID_USUARIO] 
              ,[DATA_INCLUSAO] 
              ,[SENHA_ANTIGA]) 
        VALUES 
              (@id_usuario  
              ,@dataInclusao 
              ,@senhaAntiga) 
 END
 go

