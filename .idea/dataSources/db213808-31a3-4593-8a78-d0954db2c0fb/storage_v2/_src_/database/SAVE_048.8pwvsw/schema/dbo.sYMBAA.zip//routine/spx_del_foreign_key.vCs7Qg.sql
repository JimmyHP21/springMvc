
create proc spx_del_foreign_key 
@schema nvarchar(max) = 'dbo',
@table nvarchar(max),
@column nvarchar(max) = null,
@refer nvarchar(max) = null,
@read_only bit = 1
as
begin
	declare @crlf nvarchar(6)
	declare @cmd nvarchar(max)		
	set @crlf = char(13)+char(10)
	set @cmd = ''
	select @cmd=@cmd+'alter table ' + @schema + '.' + @table + @crlf +
		   'drop constraint ' + fk.name + ';' + @crlf
	from sys.foreign_keys fk
	inner join sysconstraints ct 
	on ct.constid = fk.object_id	
	where fk.parent_object_id = object_id(@table,'u')
	and fk.referenced_object_id = isnull(object_id(@refer,'u'),fk.referenced_object_id)
	and (ct.colid in (select column_id 
					 from sys.all_columns 
					 where object_id = object_id(@table,'u') 
					 and name = @column)
					 or @column is null )
	print @cmd;
	if @read_only <> 1 exec(@cmd);
end
go

