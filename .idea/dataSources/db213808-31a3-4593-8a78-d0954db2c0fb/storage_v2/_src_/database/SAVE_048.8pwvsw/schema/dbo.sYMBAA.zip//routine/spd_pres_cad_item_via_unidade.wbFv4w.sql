-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spd_pres_cad_item_via_unidade
	@id int 
as
begin
	set nocount on
	delete from dbo.pres_cad_item_via_unidade
	where
		id = @id
end
go

