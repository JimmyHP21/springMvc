-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_pres_cad_via
	@via int = null,
	@descricao varchar(50) = null,
	@atualizacao varchar(150) = null
as
begin
	set nocount on
	select
	 via, descricao, atualizacao
	from dbo.pres_cad_via
where (via = @via or @via is null )
 and (descricao = @descricao or @descricao is null )
 and (atualizacao = @atualizacao or @atualizacao is null )
end
go

