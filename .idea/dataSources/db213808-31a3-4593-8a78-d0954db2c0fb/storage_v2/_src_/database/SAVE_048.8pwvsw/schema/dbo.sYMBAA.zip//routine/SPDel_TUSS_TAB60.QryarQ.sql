 
-- =============================================
-- Author:		M2 TECNOLOGIA
-- Create date:	06/09/2017
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPDel_TUSS_TAB60	@CODIGO int,
	@INICIOVIGENCIA datetime
AS
BEGIN
	SET NOCOUNT ON
	DELETE FROM TUSS_TAB60
	WHERE
		CODIGO = @CODIGO
		AND INICIOVIGENCIA = @INICIOVIGENCIA
END
go

