

CREATE PROCEDURE SP_TISS_030200_RESUMO_INTERNACAO_IDENTIFICACAO_EQUIPE 	 @REGISTRO      BIGINT,
																		 @TIPO_REGISTRO VARCHAR(MAX),
																		 @GUIA          VARCHAR(MAX),																		 
																		 @PROCEDIMENTO  VARCHAR(MAX) = '0',
																		 @TIPO_FATURA	VARCHAR(MAX)='TOTAL',
																		 @CODIGOEXECUTANTE VARCHAR(MAX) = NULL,
																		 @SEQUENCIAL     BIGINT = 0																 
																		 
AS
BEGIN
    IF @TIPO_REGISTRO = 'INTERNO' AND (@TIPO_FATURA = 'TOTAL' OR @TIPO_FATURA = 'FINAL')
      BEGIN
          SELECT DISTINCT
		  MOVIM.SEQUENCIA			AS SEQUENCIA,
		  MOVIM.PROCEDIMENTO		AS PROCEDIMENTO,		  
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------IDENTIFICACAO DA EQUIPE---------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  
          T35.CODIGO                 				AS identEquipeIdentificacaoEquipeGrauPart,--Grau de participação do profissional  |  String  |  2  |    |  Grau de participação do profissional na realização do procedimento, conforme tabela de domínio nº 35.  |  Condicionado. Deve ser preenchido sempre que houver honorários profissionais relativos aos procedimentos realizados e tratar-se de procedimento realizado por equipe.
          (CASE WHEN ISNULL(@CODIGOEXECUTANTE,'') <> '' THEN 'CODIGO' 
				ELSE PROE.TIPO_PROFISSIONAL_EXECUTANTE 
		   END)                     	  			AS identEquipeIdentificacaoEquipeCodProfissionalItemTipo,--Campo criado para atender a situação do código do Profissional Participante na Equipe
		  DBO.FN_SONUMERICO((CASE WHEN ISNULL(@CODIGOEXECUTANTE,'') <> '' THEN @CODIGOEXECUTANTE
								  ELSE PROE.CODIGO_PROFISSIONAL_EXECUTANTE 
							 END))                  AS identEquipeIdentificacaoEquipeCodProfissionalItem,--Código do contratado executante na operadora  |  String  |  14  |    |  Código na Operadora ou CPF do profissional que executou o procedimento.  |  Condicionado. Deve ser preenchido sempre que houver honorários profissionais relativos aos procedimentos realizados.
          PROE.NOME_PROFISSIONAL_EXECUTANTE		    AS identEquipeIdentificacaoEquipeNomeProf,--Nome do profissional executante  |  String  |  70  |    |  Nome do profissional que executou o procedimento.  |  Condicionado. Deve ser preenchido sempre que houver honorários profissionais relativos aos procedimentos realizados.
          ISNULL(T26.CODIGO,10)      AS identEquipeIdentificacaoEquipeConselho,--Conselho profissional do executante  |  String  |  2  |    |  Código do conselho do profissional que executou o procedimento, conforme tabela de domínio nº 26.  |  Condicionado. Deve ser preenchido sempre que houver honorários profissionais relativos aos procedimentos realizados.
          MEXEC.CRM                  AS identEquipeIdentificacaoEquipeNumeroConselhoProfissional,--Número do executante no conselho profissional  |  String  |  15  |    |  Número de registro no respectivo Conselho Profissional do profissional que executou o procedimento.  |  Condicionado. Deve ser preenchido sempre que houver  honorários profissionais relativos aos procedimentos realizados.
          UFEXEC.CODIGO_TUSS         AS identEquipeIdentificacaoEquipeUF,--UF do conselho do profissional executante  |  String  |  2  |    |  Sigla da Unidade Federativa do Conselho Profissional do executante do procedimento, conforme tabela de domínio nº 59.  |  Condicionado. Deve ser preenchido sempre que houver  honorários profissionais relativos aos procedimentos realizados.
          ISNULL(T24.CODIGO,'999999')
									 AS identEquipeIdentificacaoEquipeCBOS --Código na Classificação Brasileira de Ocupações do executante  |  String  |  6  |    |  Código na Classificação Brasileira de Ocupações do profissional executante do procedimento, conforme tabela de domínio nº 24.  |  Condicionado. Deve ser preenchido sempre que houver  honorários profissionais relativos aos procedimentos realizados.
          FROM   V_RECUPERADADOSTISS AS RDT
                 INNER JOIN INTERNO AS ATEND WITH (READPAST)
                         ON ATEND.REGISTRO = RDT.REGISTRO
                            AND RDT.TIPOREGISTRO = 2
                            AND ISNULL(ATEND.CANCELADO, 0) = 0
                            AND RDT.GUIAINTERNA = @GUIA
                            AND ATEND.REGISTRO IN ( @REGISTRO )
							
                 INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                         ON ATEND.CONVENIO = CONV.CONVENIO						 
                 LEFT JOIN CONVENIODATA_PERIODO AS CDP
                         ON CONV.CONVENIO = CDP.CONVENIO
                            AND CDP.FATURA = ATEND.FATURACONTA
							
                 INNER JOIN MOVIM_INT AS MOVIM WITH (READPAST)
                         ON MOVIM.REGISTRO = ATEND.REGISTRO
                            AND (MOVIM.PROCEDIMENTO = @PROCEDIMENTO OR @PROCEDIMENTO = '0')
							AND MOVIM.QUANTIDADE > 0
                            AND MOVIM.TIPOLANCAMENTO IN ( 2, 3 )
                            AND ISNULL(MOVIM.GUIAINTERNA, 0) = RDT.GUIAINTERNA
							AND MOVIM.TIPOGUIA = 'H'
							AND (MOVIM.SEQUENCIA = @SEQUENCIAL OR @SEQUENCIAL = 0)
										 
                 LEFT JOIN DADOSGUIA AS DG WITH (READPAST)
                        ON DG.REGISTRO = RDT.REGISTRO
                           AND DG.TIPOREGISTRO = RDT.TIPOREGISTRO
										 
                 INNER JOIN ATUACOES AS ATO WITH (READPAST)
                        ON ATO.ATUACAO = MOVIM.ATUACAO
                 LEFT JOIN TUSS_TAB35 AS T35 WITH (READPAST)
                        ON T35.CODIGO = ATO.GRAUPARTICIPACAO
				 
				 --EXECUTANTE		
                 INNER JOIN MEDICOS AS MEXEC WITH (READPAST)
                        ON MEXEC.MEDICO = MOVIM.MEDICO
                 LEFT JOIN UF AS UFEXEC WITH (READPAST)
                        ON UFEXEC.ID_UF = MEXEC.UFCRM
						
				 LEFT JOIN V_TISS_PROFISSIONAL_EXECUTANTE PROE
						ON PROE.CONVENIO = ATEND.CONVENIO
					   AND PROE.MEDICO = MEXEC.MEDICO
					   AND PROE.TIPOREGISTRO = 1

                 LEFT JOIN ESPMEDICA ESPEXEC WITH (READPAST)
                        ON ESPEXEC.ESPECMEDICA = MEXEC.ESPECMEDICA
				 
				 LEFT JOIN TUSS_TAB24 AS T24 WITH (READPAST)
						ON T24.CODIGO = ISNULL(ESPEXEC.CBOS030200, ESPEXEC.CBO2002)
            
				 LEFT JOIN TUSS_TAB26 AS T26 WITH (READPAST)
					ON T26.CODIGO = (CASE WHEN ISNULL(MEXEC.CONSELHOPROFISSIONAL,0) IN(0,7,11,12) THEN 10
										  WHEN MEXEC.CONSELHOPROFISSIONAL >= 8 AND MEXEC.CONSELHOPROFISSIONAL <= 10 THEN MEXEC.CONSELHOPROFISSIONAL -1
										  ELSE MEXEC.CONSELHOPROFISSIONAL END)
                                  
                 CROSS JOIN PARAMETRO AS PAR WITH (READPAST)
				WHERE CDP.FATURA IS NOT NULL OR @SEQUENCIAL = 0
      END
      ELSE IF @TIPO_REGISTRO = 'INTERNO' AND @TIPO_FATURA = 'PARCIAL'
      BEGIN
          SELECT DISTINCT
		  MOVIM.SEQUENCIA			AS SEQUENCIA,
		  MOVIM.PROCEDIMENTO		AS PROCEDIMENTO,		  
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------IDENTIFICACAO DA EQUIPE---------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  
          T35.CODIGO                 AS identEquipeIdentificacaoEquipeGrauPart,--Grau de participação do profissional  |  String  |  2  |    |  Grau de participação do profissional na realização do procedimento, conforme tabela de domínio nº 35.  |  Condicionado. Deve ser preenchido sempre que houver honorários profissionais relativos aos procedimentos realizados e tratar-se de procedimento realizado por equipe.
          (CASE WHEN ISNULL(@CODIGOEXECUTANTE,'') <> '' THEN 'CODIGO' 
				ELSE PROE.TIPO_PROFISSIONAL_EXECUTANTE 
		   END)                     	  			AS identEquipeIdentificacaoEquipeCodProfissionalItemTipo,--Campo criado para atender a situação do código do Profissional Participante na Equipe
		  DBO.FN_SONUMERICO((CASE WHEN ISNULL(@CODIGOEXECUTANTE,'') <> '' THEN @CODIGOEXECUTANTE
								  ELSE PROE.CODIGO_PROFISSIONAL_EXECUTANTE 
							 END))                  AS identEquipeIdentificacaoEquipeCodProfissionalItem,--Código do contratado executante na operadora  |  String  |  14  |    |  Código na Operadora ou CPF do profissional que executou o procedimento.  |  Condicionado. Deve ser preenchido sempre que houver honorários profissionais relativos aos procedimentos realizados.
          PROE.NOME_PROFISSIONAL_EXECUTANTE		    AS identEquipeIdentificacaoEquipeNomeProf,--Nome do profissional executante  |  String  |  70  |    |  Nome do profissional que executou o procedimento.  |  Condicionado. Deve ser preenchido sempre que houver honorários profissionais relativos aos procedimentos realizados.
          ISNULL(T26.CODIGO,10)      AS identEquipeIdentificacaoEquipeConselho,--Conselho profissional do executante  |  String  |  2  |    |  Código do conselho do profissional que executou o procedimento, conforme tabela de domínio nº 26.  |  Condicionado. Deve ser preenchido sempre que houver honorários profissionais relativos aos procedimentos realizados.
          MEXEC.CRM                  AS identEquipeIdentificacaoEquipeNumeroConselhoProfissional,--Número do executante no conselho profissional  |  String  |  15  |    |  Número de registro no respectivo Conselho Profissional do profissional que executou o procedimento.  |  Condicionado. Deve ser preenchido sempre que houver  honorários profissionais relativos aos procedimentos realizados.
          UFEXEC.CODIGO_TUSS         AS identEquipeIdentificacaoEquipeUF,--UF do conselho do profissional executante  |  String  |  2  |    |  Sigla da Unidade Federativa do Conselho Profissional do executante do procedimento, conforme tabela de domínio nº 59.  |  Condicionado. Deve ser preenchido sempre que houver  honorários profissionais relativos aos procedimentos realizados.
		  ISNULL(T24.CODIGO,'999999')
                                     AS identEquipeIdentificacaoEquipeCBOS --Código na Classificação Brasileira de Ocupações do executante  |  String  |  6  |    |  Código na Classificação Brasileira de Ocupações do profissional executante do procedimento, conforme tabela de domínio nº 24.  |  Condicionado. Deve ser preenchido sempre que houver  honorários profissionais relativos aos procedimentos realizados.
		  FROM   V_RECUPERADADOSTISS AS RDT
                 INNER JOIN EXTERNO AS ATEND WITH (READPAST)
                         ON ATEND.REGISTRO = RDT.REGISTRO
                            AND RDT.TIPOREGISTRO = 3
                            AND ISNULL(ATEND.CANCELADO, 0) = 0
                            AND ATEND.REGISTRO IN ( @REGISTRO )
                            
                 INNER JOIN INTERNO AS INTER WITH (READPAST)
                         ON INTER.REGISTRO = ATEND.PACIENTE_INTERNO_FATURADO
                            AND ISNULL(INTER.CANCELADO, 0) = 0                            
						 
                 INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                         ON ATEND.CONVENIO = CONV.CONVENIO						 
				  LEFT JOIN CONVENIODATA_PERIODO AS CDP
                         ON CONV.CONVENIO = CDP.CONVENIO
                            AND CDP.FATURA = ATEND.FATURACONTA
							
                 INNER JOIN MOVIM_EXT AS MOVIM WITH (READPAST)
                         ON MOVIM.REGISTRO = ATEND.REGISTRO
                         	AND (MOVIM.PROCEDIMENTO = @PROCEDIMENTO OR @PROCEDIMENTO = '0')
							AND MOVIM.QUANTIDADE > 0
                            AND MOVIM.TIPOLANCAMENTO IN ( 2, 3)
                            AND ISNULL(MOVIM.GUIAINTERNA, 0) = RDT.GUIAINTERNA
							AND MOVIM.TIPOGUIA = 'H'
							AND (MOVIM.SEQUENCIA = @SEQUENCIAL OR @SEQUENCIAL = 0)

                 LEFT JOIN DADOSGUIA AS DG WITH (READPAST)
                        ON DG.REGISTRO = RDT.REGISTRO
                           AND DG.TIPOREGISTRO = RDT.TIPOREGISTRO
										 
                 INNER JOIN ATUACOES AS ATO WITH (READPAST)
                        ON ATO.ATUACAO = MOVIM.ATUACAO
                 LEFT JOIN TUSS_TAB35 AS T35
                        ON T35.CODIGO = ATO.GRAUPARTICIPACAO
				 
				 --EXECUTANTE		
                 INNER JOIN MEDICOS AS MEXEC WITH (READPAST)
                        ON MEXEC.MEDICO = MOVIM.MEDICO
                 LEFT JOIN UF AS UFEXEC WITH (READPAST)
                        ON UFEXEC.ID_UF = MEXEC.UFCRM
						
				 LEFT JOIN V_TISS_PROFISSIONAL_EXECUTANTE PROE
						ON PROE.CONVENIO = ATEND.CONVENIO
					   AND PROE.MEDICO = MEXEC.MEDICO
					   AND PROE.TIPOREGISTRO = 1

                 LEFT JOIN ESPMEDICA ESPEXEC WITH (READPAST)
                        ON ESPEXEC.ESPECMEDICA = MEXEC.ESPECMEDICA
				 LEFT JOIN TUSS_TAB24 AS T24 WITH (READPAST)
						ON T24.CODIGO = ISNULL(ESPEXEC.CBOS030200, ESPEXEC.CBO2002)
            
				 LEFT JOIN TUSS_TAB26 AS T26 WITH (READPAST)
					ON T26.CODIGO = (CASE WHEN ISNULL(MEXEC.CONSELHOPROFISSIONAL,0) IN(0,7,11,12) THEN 10
										  WHEN MEXEC.CONSELHOPROFISSIONAL >= 8 AND MEXEC.CONSELHOPROFISSIONAL <= 10 THEN MEXEC.CONSELHOPROFISSIONAL -1
										  ELSE MEXEC.CONSELHOPROFISSIONAL END)            
						
                 CROSS JOIN PARAMETRO AS PAR WITH (READPAST)
				WHERE CDP.FATURA IS NOT NULL OR @SEQUENCIAL = 0
      END  
END
go

