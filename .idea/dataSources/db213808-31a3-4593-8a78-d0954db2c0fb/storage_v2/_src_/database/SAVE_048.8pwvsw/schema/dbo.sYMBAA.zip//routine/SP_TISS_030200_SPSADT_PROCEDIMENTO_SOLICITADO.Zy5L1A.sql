CREATE PROCEDURE SP_TISS_030200_SPSADT_PROCEDIMENTO_SOLICITADO 	@REGISTRO      BIGINT = NULL,
																@TIPO_REGISTRO VARCHAR(MAX) = NULL,
																@GUIA          VARCHAR(MAX) = NULL,
																@TIPO_FATURA   VARCHAR(MAX)= 'TOTAL'
AS
DECLARE @ID VARBINARY(8000)
SELECT @ID = HashBytes('MD5', NET_ADDRESS) FROM MASTER..SYSPROCESSES WHERE SPID = @@SPID

    IF @TIPO_REGISTRO = 'AMBULATORIAL'
        OR @TIPO_REGISTRO = 'URGENCIA'		
      BEGIN
            SELECT
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------PROCEDIMENTOS--------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  																		       

		  HON.TIPO_TABELA                                                                                          AS codigoTabela,
          HON.COD_TUSS                                                                                             AS codigoProcedimento,
          SUBSTRING(HON.DESC_TUSS,0,150)                                                                           AS descricaoProcedimento,
		  ISNULL(A.QUANTIDADE_AUX,1)																		       AS quantidadeSolicitada,
		  ISNULL(B.QUANTIDADEAUTORIZADA, 0)																	       AS quantidadeAutorizada
          FROM  AMBULATORIAL E WITH (NOLOCK)  
				INNER JOIN AMBULATORIALPROCEDIMENTO A WITH (NOLOCK) 
						ON   E.REGISTRO=A.REGISTRO 
				INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                         ON E.CONVENIO = CONV.CONVENIO 
				LEFT JOIN AUTORIZACAOPROCEDIMENTOAMBULATORIAL B WITH (NOLOCK) 
						 ON A.AUTORIZACAOPROCEDIMENTO = B.AUTORIZACAOPROCEDIMENTO 
				INNER JOIN V_TUSS AS HON ON 
				 CONV.TABELAHONORARIO  = HON.TAB_CONVENIO	
                 AND HON.TIPO_DESC = 'PROCEDIMENTO'
                 AND HON.COD_SAVE = A.PROCEDIMENTO
				 --AND B.AUTORIZACAOPROCEDIMENTO IS NULL	--verificar	
		 WHERE A.REGISTRO = @REGISTRO
      END 
	  ELSE IF @TIPO_REGISTRO = 'INTERNO' 
      BEGIN
                    SELECT DISTINCT
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------PROCEDIMENTOS--------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  																		      g

		  HON.TIPO_TABELA                                                                                          AS codigoTabela,
          HON.COD_TUSS                                                                                             AS codigoProcedimento,
          SUBSTRING(HON.DESC_TUSS,0,150)                                                                           AS descricaoProcedimento,
		  ISNULL(A.QUANTIDADE_AUX,1)																		       AS quantidadeSolicitada,
		  ISNULL(B.QUANTIDADEAUTORIZADA, 0)																	       AS quantidadeAutorizada
          FROM  INTERNO E WITH (NOLOCK)  
				INNER JOIN INTERNOPROCEDIMENTO A WITH (NOLOCK) 
						ON   E.REGISTRO=A.REGISTRO 
				INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                        ON E.CONVENIO = CONV.CONVENIO 
				LEFT JOIN AUTORIZACAOPROCEDIMENTOINTERNO B WITH (NOLOCK) 
					    ON A.AUTORIZACAOPROCEDIMENTO = B.AUTORIZACAOPROCEDIMENTO 
				INNER JOIN V_TUSS AS HON ON 
				 CONV.TABELAHONORARIO  = HON.TAB_CONVENIO	
                 AND HON.TIPO_DESC = 'PROCEDIMENTO'
                 AND HON.COD_SAVE = A.PROCEDIMENTO		
		 WHERE A.REGISTRO = @REGISTRO									
      END 	  	  
      IF @TIPO_REGISTRO = 'EXTERNO'
      BEGIN
          SELECT
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------PROCEDIMENTOS--------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  																		       

		  HON.TIPO_TABELA                                                                                          AS codigoTabela,
          HON.COD_TUSS                                                                                             AS codigoProcedimento,
          SUBSTRING(HON.DESC_TUSS,0,150)                                                                           AS descricaoProcedimento,
		  ISNULL(A.QUANTIDADE_AUX,1)																		       AS quantidadeSolicitada,
		  ISNULL(B.QUANTIDADEAUTORIZADA, 0)																	       AS quantidadeAutorizada
          FROM  EXTERNO E WITH (NOLOCK)  
				INNER JOIN EXTERNOPROCEDIMENTO A WITH (NOLOCK) 
						ON   E.REGISTRO=A.REGISTRO 
				INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                        ON E.CONVENIO = CONV.CONVENIO 
				LEFT JOIN AUTORIZACAOPROCEDIMENTOEXTERNO B WITH (NOLOCK) 
						ON A.AUTORIZACAOPROCEDIMENTO = B.AUTORIZACAOPROCEDIMENTO 
				INNER JOIN V_TUSS AS HON ON 
				 CONV.TABELAHONORARIO  = HON.TAB_CONVENIO	
                 AND HON.TIPO_DESC = 'PROCEDIMENTO'
                 AND HON.COD_SAVE = A.PROCEDIMENTO		
		 WHERE A.REGISTRO = @REGISTRO									
      END

go

