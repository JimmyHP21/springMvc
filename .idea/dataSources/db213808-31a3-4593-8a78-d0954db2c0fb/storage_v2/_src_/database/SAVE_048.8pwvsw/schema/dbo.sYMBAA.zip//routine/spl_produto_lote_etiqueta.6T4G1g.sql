-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spl_produto_lote_etiqueta

as
begin
	set nocount on
	select
	 produto, lote, validadelote, sequencia
	from dbo.produto_lote_etiqueta
end
go

