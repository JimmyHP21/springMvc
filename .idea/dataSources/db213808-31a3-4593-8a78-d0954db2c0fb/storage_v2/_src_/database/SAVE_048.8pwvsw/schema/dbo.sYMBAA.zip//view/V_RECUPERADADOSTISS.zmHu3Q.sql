CREATE VIEW V_RECUPERADADOSTISS 
AS 
SELECT A.REGISTRO, 
         A.TIPOREGISTRO, 
         ( CASE 
             WHEN LTRIM(RTRIM(ISNULL(A.GUIADIFCONVENIO, ''))) = '' THEN LTRIM(RTRIM(ISNULL(A.NGUIA, ''))) 
             ELSE LTRIM(RTRIM(A.GUIADIFCONVENIO)) 
           END )                                     AS GUIATISS, 
         0                                           AS GUIAINTERNA, 
         A.REGISTRO                                  AS GUIAPRESTADOR, 
         ( CASE 
             WHEN LTRIM(RTRIM(ISNULL(A.GUIADIFCONVENIO, ''))) = '' THEN LTRIM(RTRIM(ISNULL(A.NGUIA, ''))) 
             ELSE LTRIM(RTRIM(A.GUIADIFCONVENIO)) 
           END )                                     AS GUIAOPERADORA, 
         ISNULL(A.NGUIA, '')                         AS GUIAPRINCIPAL, 
         LTRIM(RTRIM(ISNULL(A.GUIADIFCONVENIO, ''))) AS GUIADIFCONVENIO, 
         0                                           AS TIPOGUIA, 
         (CASE WHEN ISNULL(A.GUIASENHA,'0') = '0' THEN NULL ELSE A.GUIASENHA END) 
                                                    AS SENHA, 
         A.DATA                                      AS DATA, 
         ( CASE 
             WHEN A.TIPOREGISTRO = 1 THEN B.MEDICO 
             WHEN A.TIPOREGISTRO = 2 THEN C.MEDICO 
             WHEN A.TIPOREGISTRO = 3 THEN D.MEDICO 
           END )                                     AS MEDICO, 
         ( CASE 
            WHEN ISNULL(A.TIPOATENDIMENTO, 0) <> 0 THEN A.TIPOATENDIMENTO 
             WHEN B.TIPOTRATAMENTO IN( 2, 4, 6 ) THEN 4 
             WHEN B.TIPOTRATAMENTO IN( 5 ) THEN 3  
--ORTOPEDIA=TERAPIAS 
             WHEN B.TIPOTRATAMENTO IN( 1, 3 ) THEN 2 
             WHEN B.TIPOTRATAMENTO IN( 7 ) THEN 5 
             --AGUDOS 27/05/2012 KCOND 
             --WHEN ISNULL(A.TISS_TIPOATENDIMENTO ,0)<>0 AND (A.TIPOREGISTRO=3 OR A.TIPOREGISTRO=1)  THEN A.TISS_TIPOATENDIMENTO 
             WHEN A.TIPOREGISTRO = 3 THEN ISNULL(A.TISS_TIPOATENDIMENTO,5) 
             ELSE 4 
           END )                                     AS TIPOTRATAMENTO, 
         A.ACOMODACAO 
  FROM   DADOSGUIA A WITH (NOLOCK) 
         LEFT JOIN AMBULATORIAL B WITH (NOLOCK) 
                ON A.REGISTRO = B.REGISTRO 
                   AND A.TIPOREGISTRO = 1 
         LEFT JOIN INTERNO C WITH (NOLOCK) 
                ON A.REGISTRO = C.REGISTRO 
                   AND A.TIPOREGISTRO = 2 
         LEFT JOIN EXTERNO D WITH (NOLOCK) 
                ON A.REGISTRO = D.REGISTRO 
                   AND A.TIPOREGISTRO = 3 
  UNION ALL 
  SELECT X.REGISTRO, 
         X.TIPOREGISTRO, 
         LTRIM(RTRIM(CONVERT(CHAR(15),X.GUIA)))  AS GUIATISS, 
         X.GUIAINTERNA, 
         LTRIM(RTRIM(CONVERT(CHAR(15), X.GUIA))) AS GUIAPRESTADOR, 
         ( CASE 
             WHEN LTRIM(RTRIM(ISNULL(Y.GUIADIFCONVENIO, ''))) = '' THEN LTRIM(RTRIM(ISNULL(Y.NGUIA, ''))) 
             ELSE LTRIM(RTRIM(Y.GUIADIFCONVENIO)) 
           END )                                 AS GUIAOPERADORA, 
         ISNULL(Y.NGUIA, '')                     AS GUIAPRINCIPAL, 
         NULL                                    AS GUIADIFCONVENIO, 
         1                                       AS TIPOGUIA, 
         (CASE WHEN ISNULL(X.SENHA,'') NOT IN ('0','') THEN X.SENHA WHEN ISNULL(Y.GUIASENHA,'') NOT IN ('','0') THEN Y.GUIASENHA ELSE NULL END) 
                                               AS SENHA, 
         Y.DATA                                  AS DATA, 
         X.MEDICO, 
         ( CASE WHEN ISNULL(X.TIPOATENDIMENTO,0) <> 0 THEN X.TIPOATENDIMENTO 
               WHEN ISNULL(Y.TIPOATENDIMENTO, 0) <> 0 THEN Y.TIPOATENDIMENTO 
               WHEN B.TIPOTRATAMENTO IN( 2, 4, 6 ) THEN 4 
               WHEN B.TIPOTRATAMENTO IN( 5 ) THEN 3  
--ORTOPEDIA=TERAPIAS 
               WHEN B.TIPOTRATAMENTO IN( 1, 3 ) THEN 2 
               WHEN B.TIPOTRATAMENTO IN( 7 ) THEN 5 
                WHEN Y.TIPOREGISTRO = 3 THEN ISNULL(Y.TISS_TIPOATENDIMENTO,5) 
               ELSE 4 
           END ), 
         Y.ACOMODACAO 
  FROM   DADOSGUIASECUNDARIO X WITH (NOLOCK) 
         INNER JOIN DADOSGUIA Y WITH (NOLOCK) 
                 ON X.REGISTRO = Y.REGISTRO 
                    AND X.TIPOREGISTRO = Y.TIPOREGISTRO 
         LEFT JOIN AMBULATORIAL B WITH (NOLOCK) 
                ON Y.REGISTRO = B.REGISTRO 
                   AND Y.TIPOREGISTRO = 1
go

