 CREATE PROCEDURE [dbo].[SP_LISTACOMBOCONVENIO]                           
 AS                                                                       
 BEGIN                                                                    
   Select                                                                 
            CONVENIO                                                      
           , STR(CONVENIO) + ' - ' + descricao as DESCRICAOCONVENIO       
           ,DESCRICAO AS NOMECONVENIO                                     
            from CONVENIOS                                                
            WHERE DATATERMINO IS NULL                                     
 END
 go

