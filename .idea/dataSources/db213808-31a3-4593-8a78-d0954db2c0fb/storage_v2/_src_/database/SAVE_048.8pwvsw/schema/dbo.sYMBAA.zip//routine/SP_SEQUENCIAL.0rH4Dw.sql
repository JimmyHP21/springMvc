CREATE PROCEDURE SP_SEQUENCIAL 
     @PTABELA NVARCHAR(255) 
   , @PCAMPO NVARCHAR(255) 
   , @PCONDICAO NVARCHAR(255) = '1 = 1' 
   , @PVIRTUAL BIT = 0 
   , @ID INT = NULL OUTPUT 
AS 
BEGIN 
   DECLARE @MAX INT; 
   DECLARE @QUERY NVARCHAR(MAX); 
   DECLARE @EXISTE AS BIGINT; 
 
   SET @PCONDICAO = ISNULL(@PCONDICAO, '1 = 1'); 
   SET @PVIRTUAL = ISNULL(@PVIRTUAL, 0); 
 
   IF ISNULL(@PTABELA, '') = '' 
       RETURN; 
 
   IF ISNULL(@PCAMPO, '') = '' 
       RETURN; 
 
   BEGIN TRANSACTION TRAN_SEQUENCIA; 
 
   IF OBJECT_ID('SEQUENCIAL') IS NULL 
   BEGIN 
       CREATE TABLE SEQUENCIAL ( 
           TABELA NVARCHAR(512) 
           , CAMPO NVARCHAR(512) 
           , CONDICAO NVARCHAR(512) 
           , VALOR BIGINT 
           , DATA DATETIME 
           , VIRTUAL BIT 
           , PRIMARY KEY ( 
               TABELA 
               , CAMPO 
               , CONDICAO 
               , VALOR 
               ) 
           ) 
   END 
 
   IF EXISTS ( 
           SELECT TOP 1 1 
           FROM SEQUENCIAL 
           WHERE TABELA = @PTABELA 
               AND CAMPO = @PCAMPO 
               AND ISNULL(CONDICAO, '') = ISNULL(@PCONDICAO, '') 
           ) 
   BEGIN 
       UPDATE SEQUENCIAL 
       SET VALOR = VALOR + 1 
           , DATA = GETDATE() 
       WHERE TABELA = @PTABELA 
           AND CAMPO = @PCAMPO 
           AND ISNULL(CONDICAO, '') = ISNULL(@PCONDICAO, ''); 
   END 
   ELSE 
   BEGIN 
       IF @PVIRTUAL = 0 
       BEGIN 
           SET @QUERY = N'SELECT @MAX = ISNULL(MAX(' + @PCAMPO + '),1) FROM ' + @PTABELA + ' WHERE  ' + @PCONDICAO 
 
           EXEC SP_EXECUTESQL @QUERY 
               , N'@MAX INT OUTPUT' 
               , @MAX OUTPUT; 
 
           PRINT @QUERY; 
       END 
       ELSE 
       BEGIN 
           SET @MAX = 1; 
       END; 
 
       INSERT INTO SEQUENCIAL 
       VALUES ( 
           @PTABELA 
           , @PCAMPO 
           , @PCONDICAO 
           , @MAX 
           , GETDATE() 
           , @PVIRTUAL 
           ); 
   END; 
 
   COMMIT TRANSACTION TRAN_SEQUENCIA; 
 
   SELECT @ID = VALOR 
   FROM SEQUENCIAL 
   WHERE TABELA = @PTABELA 
       AND CAMPO = @PCAMPO 
       AND ISNULL(CONDICAO, '') = ISNULL(@PCONDICAO, ''); 
 
   SELECT @ID AS SEQUENCIA; 
END
go

