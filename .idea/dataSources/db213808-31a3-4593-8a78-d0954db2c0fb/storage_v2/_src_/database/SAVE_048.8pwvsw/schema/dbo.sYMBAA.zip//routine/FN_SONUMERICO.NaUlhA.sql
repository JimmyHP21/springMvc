

CREATE FUNCTION DBO.FN_SONUMERICO(@STR_TEXTO VARCHAR(MAX)) RETURNS VARCHAR(MAX) AS
BEGIN
DECLARE
        @RESULTADO VARCHAR (8000),
        @LETRA CHAR(1),
        @NUMERO INT,
        @CONT INT,
        @ZERO INT,
        @NOVE INT

         SELECT

        @RESULTADO = '',
        @CONT = 0,
        @ZERO = UNICODE(0),
        @NOVE = UNICODE(9),
        @NUMERO = LEN(@STR_TEXTO)

        WHILE @CONT < @NUMERO
        BEGIN
                SET @CONT = @CONT + 1
                SET @LETRA = SUBSTRING(@STR_TEXTO, @CONT, 1)
                IF UNICODE(@LETRA) BETWEEN @ZERO AND @NOVE
                BEGIN
                       SET @RESULTADO = @RESULTADO + @LETRA
                END
       END

      RETURN @RESULTADO

END
go

