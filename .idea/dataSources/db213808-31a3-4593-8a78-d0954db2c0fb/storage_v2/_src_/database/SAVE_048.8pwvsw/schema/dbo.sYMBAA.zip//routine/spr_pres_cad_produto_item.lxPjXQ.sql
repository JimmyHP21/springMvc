-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_pres_cad_produto_item
	@id int = null,
	@produto int = null,
	@item int = null,
	@apresentacao int = null,
	@via int = null,
	@atualizacao varchar(150) = null,
	@log bigint = null
as
begin
	set nocount on
	select
	 id, produto, item, apresentacao, via, atualizacao, log
	from dbo.pres_cad_produto_item
where (id = @id or @id is null )
 and (produto = @produto or @produto is null )
 and (item = @item or @item is null )
 and (apresentacao = @apresentacao or @apresentacao is null )
 and (via = @via or @via is null )
 and (atualizacao = @atualizacao or @atualizacao is null )
 and (log = @log or @log is null )
end
go

