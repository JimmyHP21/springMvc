

CREATE PROCEDURE SP_TISS_030200_HONORARIOS_PROCEDIMENTO_REALIZADO  @REGISTRO      BIGINT,
																   @TIPO_REGISTRO VARCHAR(MAX),
																   @GUIA          VARCHAR(MAX),
																   @TIPO_FATURA   VARCHAR(MAX) = 'TOTAL'
AS
BEGIN
  
    IF @TIPO_REGISTRO = 'INTERNO' AND (@TIPO_FATURA = 'TOTAL' OR @TIPO_FATURA = 'FINAL')
      BEGIN
          SELECT
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------CHAVES--------------------------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------
          MOVIM.PROCEDIMENTO                                                                                        AS PROCEDIMENTO,
		  MOVIM.SEQUENCIA                                                                                           AS SEQUENCIAL,
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------PROCEDIMENTOS REALIZADOS--------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  
          COALESCE(MOVIM.DATACONSUMO + MOVIM.HORACONSUMO, ATEND.DATAINTERNACAO + ATEND.HORAINTERNACAO)				AS procedimentoRealizadoDataExecucao,--Data de realiza��o  |  Date  |  8  |  DDMMAAAA  |  Data em que o atendimento/procedimento foi realizado  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          COALESCE(MOVIM.DATACONSUMO + MOVIM.HORACONSUMO, ATEND.DATAINTERNACAO + ATEND.HORAINTERNACAO)	            AS procedimentoRealizadoHoraInicial,--Hora inicial da realiza��o do procedimento  |  Time  |  8  |  HH:MM:SS  |  Hor�rio inicial da realiza��o do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de atendimento de urg�ncia ou emerg�ncia.
          COALESCE(MOVIM.DATACONSUMO + MOVIM.HORACONSUMO, ATEND.DATAINTERNACAO + ATEND.HORAINTERNACAO)	            AS procedimentoRealizadoHoraFinal,--Hora final da realiza��o do procedimento  |  Time  |  8  |  HH:MM:SS  |  Hor�rio final da realiza��o do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo           HON.TIPO_TABELA                                                                                           AS procedimentoRealizadoProcedimentoCodigoTabela,--Tabela de refer�ncia do procedimento ou item assistencial realizado  |  String  |  2  |    |  C�digo da tabela utilizada para identificar os procedimentos realizados ou itens assistenciais utilizados, conforme tabela de dom�nio n� 87.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
		  HON.TIPO_TABELA                                                                                           AS procedimentoRealizadoProcedimentoCodigoTabela,--Tabela de refer�ncia do procedimento ou item assistencial realizado  |  String  |  2  |    |  C�digo da tabela utilizada para identificar os procedimentos realizados ou itens assistenciais utilizados, conforme tabela de dom�nio n� 87.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.		  
          HON.COD_TUSS                                                                                              AS procedimentoRealizadoProcedimentoCodigoProcedimento,--C�digo do procedimento realizado  |  String  |  10  |    |  C�digo identificador do procedimento realizado pelo prestador, conforme tabela de dom�nio.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          HON.DESC_TUSS                                                                                             AS procedimentoRealizadoProcedimentoDescricaoProcedimento,--Descri��o do procedimento realizado  |  String  |  150  |    |  Descri��o do procedimento realizado  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
		  (CASE WHEN CAST( ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) > 0 THEN CAST(ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) ELSE 1 END)        AS procedimentoRealizadoQuantidadeExecutada,--Quantidade de procedimentos realizados  |  Integer  |  3  |    |  Quantidade realizada do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          T61.CODIGO                                                                                                AS procedimentoRealizadoViaAcesso,--Via de acesso  |  String  |  1  |    |  C�digo da via de acesso utilizada para realiza��o do procedimento, conforme tabela de dom�nio n� 61.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de procedimento cir�rgico.
          T48.CODIGO                                                                                                AS procedimentoRealizadoTecnicaUtilizada,--T�cnica utilizada para realiza��o do procedimento  |  String  |  1  |    |  C�digo da t�cnica utilizada para realiza��o do procedimento, conforme tabela de dom�nio n� 48.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de procedimento cir�rgico.
          (CASE WHEN ISNULL(MOVIM.FATORREDUTOR,0) = 0 THEN 1 ELSE MOVIM.FATORREDUTOR END)                           AS procedimentoRealizadoReducaoAcrescimo,--Fator de redu��o ou acr�scimo  |  Num�rico  |  1,2  |    |  Fator de redu��o ou acr�scimo sobre o valor do procedimento realizado ou item assistencial utilizado.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado. Caso n�o haja redu��o ou acr�scimo sobre o valor do procedimento o fator � igual a 1,00.
          (ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO) * ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE)) / (CASE WHEN CAST( ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) > 0 
														   THEN CAST(ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) ELSE 1 END)		AS procedimentoRealizadoValorUnitario,--Valor unit�rio do procedimento realizado  |  Num�rico  |  6,2  |    |  Valor unit�rio do procedimento realizado.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado. Nos casos em que esse valor n�o possa ser definido previamente por for�a contratual, o campo deve ser preenchido com zero.			
		  ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO) * ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE)                    										        AS procedimentoRealizadoValorTotal --Valor total dos dos procedimentos realizados  |  Num�rico  |  6,2  |    |  Valor total dos itens assistenciais utilizados, considerando a quantidade do item assistencial, o valor unit�rio e o fator de redu��o ou acr�scimo.  |  Obrigat�rio.			
          FROM   V_RECUPERADADOSTISS AS RDT 
                 INNER JOIN INTERNO AS ATEND WITH (READPAST)
                         ON ATEND.REGISTRO = RDT.REGISTRO							
                            AND RDT.TIPOREGISTRO = 2
                            AND ISNULL(ATEND.CANCELADO, 0) = 0
                            AND RDT.GUIAINTERNA = @GUIA							
                            AND ATEND.REGISTRO = @REGISTRO 
							--AND RDT.TIPOGUIA = 1
							
                 INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                         ON ATEND.CONVENIO = CONV.CONVENIO
						 
                 INNER JOIN MOVIM_INT AS MOVIM WITH (READPAST)
                         ON MOVIM.REGISTRO = ATEND.REGISTRO
							AND ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) > 0
                            AND MOVIM.TIPOLANCAMENTO = 3
                            AND ISNULL(MOVIM.GUIAINTERNA, 0) = RDT.GUIAINTERNA
							AND MOVIM.TIPOGUIA = ''

                 LEFT JOIN TUSS_PROCEDIMENTO AS HON
                        ON HON.TIPO_DESC = 'PROCEDIMENTO'
				       AND HON.COD_SAVE = MOVIM.PROCEDIMENTO
					   AND MOVIM.TIPOLANCAMENTO = 3
					   AND ( CASE
								 WHEN MOVIM.TIPOLANCAMENTO = 2 THEN CONV.TABELA
								 ELSE CONV.TABELAHONORARIO
							 END ) = HON.TAB_CONVENIO					 
                 AND ISNULL(MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO) BETWEEN HON.INICIO_VIGENCIA AND ISNULL(HON.FIM_VIGENCIA, GETDATE())
				 
/* 				 LEFT JOIN CIRURGIA CI WITH (READPAST)
						 ON CI.REGISTRO = MOVIM.REGISTRO
						AND CI.TIPOREGISTRO = 1	
						
				 LEFT JOIN CIRURGIAPROCEDIMENTO CP WITH (READPAST)
						ON CP.REGISTRO = CI.REGISTRO
					   AND CP.TIPOREGISTRO = CI.TIPOREGISTRO
					   AND CP.DOCUMENTO = CI.DOCUMENTO
					   AND CP.PROCEDIMENTO = MOVIM.PROCEDIMENTO */
					   
                 LEFT JOIN TUSS_TAB61 AS T61 WITH (READPAST)
                        ON T61.CODIGO = (CASE WHEN ISNULL(MOVIM.VIAACESSO,3) = 0 THEN 1
											  WHEN ISNULL(MOVIM.VIAACESSO,3) = 1 THEN 2
											  WHEN ISNULL(MOVIM.VIAACESSO,3) = 2 THEN 3
											  ELSE NULL END)
											  
                 LEFT JOIN TUSS_TAB48 AS T48 WITH (READPAST)
                        ON T48.CODIGO = NULL--(CASE WHEN CI.REGISTRO IS NOT NULL AND HON.DESC_TUSS LIKE '%VIDEO%' THEN 2 ELSE 1 END)
						
			ORDER BY ISNULL(MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO)						
      END
      ELSE IF @TIPO_REGISTRO = 'INTERNO' AND @TIPO_FATURA = 'PARCIAL'
      BEGIN
          SELECT
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------CHAVES--------------------------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------
          MOVIM.PROCEDIMENTO                                                                                        AS PROCEDIMENTO,
		  MOVIM.SEQUENCIA                                                                                           AS SEQUENCIAL,		  
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------PROCEDIMENTOS REALIZADOS--------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  
          COALESCE(MOVIM.DATACONSUMO + MOVIM.HORACONSUMO, ATEND.DATAINTERNACAO + ATEND.HORAINTERNACAO)		        AS procedimentoRealizadoDataExecucao,--Data de realiza��o  |  Date  |  8  |  DDMMAAAA  |  Data em que o atendimento/procedimento foi realizado  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          COALESCE(MOVIM.DATACONSUMO + MOVIM.HORACONSUMO, ATEND.DATAINTERNACAO + ATEND.HORAINTERNACAO)              AS procedimentoRealizadoHoraInicial,--Hora inicial da realiza��o do procedimento  |  Time  |  8  |  HH:MM:SS  |  Hor�rio inicial da realiza��o do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de atendimento de urg�ncia ou emerg�ncia.
          COALESCE(MOVIM.DATACONSUMO + MOVIM.HORACONSUMO, ATEND.DATAINTERNACAO + ATEND.HORAINTERNACAO)              AS procedimentoRealizadoHoraFinal,--Hora final da realiza��o do procedimento  |  Time  |  8  |  HH:MM:SS  |  Hor�rio final da realiza��o do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de atendimento de urg�ncia ou emerg�ncia.
          HON.TIPO_TABELA                                                                                           AS procedimentoRealizadoProcedimentoCodigoTabela,--Tabela de refer�ncia do procedimento ou item assistencial realizado  |  String  |  2  |    |  C�digo da tabela utilizada para identificar os procedimentos realizados ou itens assistenciais utilizados, conforme tabela de dom�nio n� 87.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          HON.COD_TUSS                                                                                              AS procedimentoRealizadoProcedimentoCodigoProcedimento,--C�digo do procedimento realizado  |  String  |  10  |    |  C�digo identificador do procedimento realizado pelo prestador, conforme tabela de dom�nio.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          HON.DESC_TUSS                                                                                             AS procedimentoRealizadoProcedimentoDescricaoProcedimento,--Descri��o do procedimento realizado  |  String  |  150  |    |  Descri��o do procedimento realizado  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
		  (CASE WHEN CAST( ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) > 0 THEN CAST(ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) ELSE 1 END)        AS procedimentoRealizadoQuantidadeExecutada,--Quantidade de procedimentos realizados  |  Integer  |  3  |    |  Quantidade realizada do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          T61.CODIGO                                                                                                AS procedimentoRealizadoViaAcesso,--Via de acesso  |  String  |  1  |    |  C�digo da via de acesso utilizada para realiza��o do procedimento, conforme tabela de dom�nio n� 61.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de procedimento cir�rgico.
          T48.CODIGO                                                                                                AS procedimentoRealizadoTecnicaUtilizada,--T�cnica utilizada para realiza��o do procedimento  |  String  |  1  |    |  C�digo da t�cnica utilizada para realiza��o do procedimento, conforme tabela de dom�nio n� 48.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de procedimento cir�rgico.
          (CASE WHEN ISNULL(MOVIM.FATORREDUTOR,0) = 0 THEN 1 ELSE MOVIM.FATORREDUTOR END)                           AS procedimentoRealizadoReducaoAcrescimo,--Fator de redu��o ou acr�scimo  |  Num�rico  |  1,2  |    |  Fator de redu��o ou acr�scimo sobre o valor do procedimento realizado ou item assistencial utilizado.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado. Caso n�o haja redu��o ou acr�scimo sobre o valor do procedimento o fator � igual a 1,00.
          (ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO) * ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE)) / (CASE WHEN CAST( ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) > 0 
														   THEN CAST(ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) ELSE 1 END)		AS procedimentoRealizadoValorUnitario,--Valor unit�rio do procedimento realizado  |  Num�rico  |  6,2  |    |  Valor unit�rio do procedimento realizado.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado. Nos casos em que esse valor n�o possa ser definido previamente por for�a contratual, o campo deve ser preenchido com zero.			
		  ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO) * ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE)                    										        AS procedimentoRealizadoValorTotal --Valor total dos dos procedimentos realizados  |  Num�rico  |  6,2  |    |  Valor total dos itens assistenciais utilizados, considerando a quantidade do item assistencial, o valor unit�rio e o fator de redu��o ou acr�scimo.  |  Obrigat�rio.			
          FROM   V_RECUPERADADOSTISS AS RDT
                 INNER JOIN EXTERNO AS ATEND WITH (READPAST)
                         ON ATEND.REGISTRO = RDT.REGISTRO
                            AND RDT.TIPOREGISTRO = 3
                            AND ISNULL(ATEND.CANCELADO, 0) = 0
                            AND RDT.GUIAINTERNA = @GUIA
                            AND ATEND.REGISTRO = @REGISTRO
							AND RDT.TIPOGUIA = 1
							
                 INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                         ON ATEND.CONVENIO = CONV.CONVENIO
                 INNER JOIN MOVIM_EXT AS MOVIM WITH (READPAST)
                         ON MOVIM.REGISTRO = ATEND.REGISTRO
							AND ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) > 0
                            AND MOVIM.TIPOLANCAMENTO = 3
                            AND ISNULL(MOVIM.GUIAINTERNA, 0) = RDT.GUIAINTERNA
							AND MOVIM.TIPOGUIA = ''
										 
                 LEFT JOIN TUSS_PROCEDIMENTO AS HON
                        ON HON.TIPO_DESC = 'PROCEDIMENTO'
					   AND HON.COD_SAVE = MOVIM.PROCEDIMENTO
					   AND MOVIM.TIPOLANCAMENTO = 3
					   AND ( CASE
								 WHEN MOVIM.TIPOLANCAMENTO = 2 THEN CONV.TABELA
								 ELSE CONV.TABELAHONORARIO
						     END ) = HON.TAB_CONVENIO	
                 AND ISNULL(MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO) BETWEEN HON.INICIO_VIGENCIA AND ISNULL(HON.FIM_VIGENCIA, GETDATE())
				 
/* 				 LEFT JOIN CIRURGIA CI WITH (READPAST)
						 ON CI.REGISTRO = MOVIM.REGISTRO
						AND CI.TIPOREGISTRO = 3
						
				 LEFT JOIN CIRURGIAPROCEDIMENTO CP WITH (READPAST)
						ON CP.REGISTRO = CI.REGISTRO
					   AND CP.TIPOREGISTRO = CI.TIPOREGISTRO
					   AND CP.DOCUMENTO = CI.DOCUMENTO
					   AND CP.PROCEDIMENTO = MOVIM.PROCEDIMENTO */
					   
                 LEFT JOIN TUSS_TAB61 AS T61 WITH (READPAST)
                        ON T61.CODIGO = (CASE WHEN ISNULL(MOVIM.VIAACESSO,3) = 0 THEN 1
											  WHEN ISNULL(MOVIM.VIAACESSO,3) = 1 THEN 2
											  WHEN ISNULL(MOVIM.VIAACESSO,3) = 2 THEN 3
											  ELSE NULL END)
											  
                 LEFT JOIN TUSS_TAB48 AS T48 WITH (READPAST)
                        ON T48.CODIGO = NULL--(CASE WHEN CI.REGISTRO IS NOT NULL AND HON.DESC_TUSS LIKE '%VIDEO%' THEN 2 ELSE 1 END)
						
			ORDER BY ISNULL(MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO)											
      END 
END
go

