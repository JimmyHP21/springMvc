CREATE PROCEDURE SP_RECORD_SIMPRO 
   @ID_SIMPRO          INT, 
    @CD_USUARIO        VARCHAR(15), 
    @CD_FRACAO         VARCHAR(15), 
    @DESCRICAO         VARCHAR(100), 
    @VIGENCIA              VARCHAR(8), 
    @IDENTIF           VARCHAR(01), 
    @PC_EM_FAB         DECIMAL(11,2), 
    @PC_EM_VEN         DECIMAL(11,2), 
    @PC_EM_USU         DECIMAL(11,2), 
    @PC_FR_FAB         DECIMAL(12,3), 
    @PC_FR_VEN         DECIMAL(12,3), 
    @PC_FR_USU         DECIMAL(12,3), 
    @TP_EMBAL              VARCHAR(03), 
    @TP_FRACAO         VARCHAR(04), 
    @QTDE_EMBAL        DECIMAL(08,2), 
    @QTDE_FRAC         DECIMAL(08,2), 
    @PERC_LUCR         DECIMAL(06,2), 
    @TIP_ALT           VARCHAR(01), 
    @FABRICA           VARCHAR(20), 
    @CD_SIMPRO         VARCHAR(10), 
    @CD_MERC           VARCHAR(03), 
    @PERC_DESC         DECIMAL(06,2)= NULL, 
    @VLR_IPI           DECIMAL(04,2) = NULL, 
    @CD_REG_ANV        VARCHAR(18)  = '', 
    @DT_REG_ANV        VARCHAR(13)  = '', 
    @CD_BARRA              DECIMAL(13,0) = NULL, 
    @LISTA             VARCHAR(1) = '', 
    @HOSPITALAR        VARCHAR(1) = '', 
    @FRACIONADO        VARCHAR(1) = '', 
   @CD_TUSS            VARCHAR(8) = '', 
   @CAMPO_EXTRA        VARCHAR(2) = '',  
-- INDICA A CLASSIFICACAO DO PRODUTO 
   @REFPRODUTO         VARCHAR(100) = '', 
   @INDPRODGENERICO    VARCHAR(1) = '', 
   @INDMATMED          VARCHAR(1) = '', 
    @VERSAO                INT, 
   @PRECO_ATUALIZADO   INT 
    
   AS 
    
   IF (SELECT COUNT(*) FROM SIMPRO WHERE ID_SIMPRO = @ID_SIMPRO) = 0 
       BEGIN 
        UPDATE SIMPRO SET VIGENTE = 0 WHERE CD_SIMPRO = @CD_SIMPRO 
        INSERT INTO 
               SIMPRO 
               (CD_USUARIO,CD_FRACAO,DESCRICAO,VIGENCIA,IDENTIF,PC_EM_FAB,PC_EM_VEN,PC_EM_USU,PC_FR_FAB,PC_FR_VEN,PC_FR_USU,TP_EMBAL,TP_FRACAO,QTDE_EMBAL,QTDE_FRAC,PERC_LUCR,TIP_ALT,FABRICA,CD_SIMPRO,CD_MERC,PERC_DESC,VLR_IPI,CD_REG_ANV,DT_REG_ANV,CD_BARRA,LISTA,HOSPITALAR,FRACIONADO,CD_TUSS,CAMPO_EXTRA,VERSAO,DT_IMPORTACAO,PRECO_ATUALIZADO,VIGENTE, REFPRODUTO, INDPRODGENERICO, INDMATMED) 
           VALUES 
        (@CD_USUARIO,@CD_FRACAO,@DESCRICAO,@VIGENCIA,@IDENTIF,@PC_EM_FAB,@PC_EM_VEN,@PC_EM_USU,@PC_FR_FAB,@PC_FR_VEN,@PC_FR_USU,@TP_EMBAL,@TP_FRACAO,@QTDE_EMBAL,@QTDE_FRAC,@PERC_LUCR,@TIP_ALT,@FABRICA,@CD_SIMPRO,@CD_MERC,@PERC_DESC,@VLR_IPI,@CD_REG_ANV,@DT_REG_ANV,@CD_BARRA,@LISTA,@HOSPITALAR,@FRACIONADO,@CD_TUSS,@CAMPO_EXTRA,@VERSAO,GETDATE(),0,1,@REFPRODUTO, @INDPRODGENERICO, @INDMATMED) 
 
       END 
   ELSE 
       BEGIN 
           UPDATE 
               SIMPRO 
               SET 
                   CD_USUARIO          = @CD_USUARIO, 
                   CD_FRACAO           = @CD_FRACAO, 
                   DESCRICAO           = @DESCRICAO, 
                   VIGENCIA            = @VIGENCIA, 
                   IDENTIF             = @IDENTIF, 
                   PC_EM_FAB           = @PC_EM_FAB  , 
                   PC_EM_VEN           = @PC_EM_VEN  , 
                   PC_EM_USU           = @PC_EM_USU  , 
                   PC_FR_FAB           = @PC_FR_FAB  , 
                   PC_FR_VEN           = @PC_FR_VEN  , 
                   PC_FR_USU           = @PC_FR_USU  , 
                   TP_EMBAL            = @TP_EMBAL  , 
                   TP_FRACAO           = @TP_FRACAO  , 
                   QTDE_EMBAL          = @QTDE_EMBAL , 
                   QTDE_FRAC           = @QTDE_FRAC  , 
                   PERC_LUCR           = @PERC_LUCR, 
                   TIP_ALT             = @TIP_ALT  , 
                   FABRICA             = @FABRICA  , 
                   CD_SIMPRO           = @CD_SIMPRO  , 
                   CD_MERC             = @CD_MERC  , 
                   PERC_DESC           = @PERC_DESC  , 
                   VLR_IPI             = @VLR_IPI  , 
                   CD_REG_ANV          = @CD_REG_ANV , 
                   DT_REG_ANV          = @DT_REG_ANV , 
                   CD_BARRA            = @CD_BARRA  , 
                   LISTA               = @LISTA    , 
                   HOSPITALAR          = @HOSPITALAR, 
                   FRACIONADO          = @FRACIONADO, 
                   CD_TUSS             = @CD_TUSS, 
                   CAMPO_EXTRA         = @CAMPO_EXTRA, 
                   VERSAO              = @VERSAO, 
                   PRECO_ATUALIZADO    = @PRECO_ATUALIZADO, 
                   REFPRODUTO          = @REFPRODUTO, 
                   INDPRODGENERICO     = @INDPRODGENERICO, 
                   INDMATMED           = @INDMATMED 
               WHERE 
                    ID_SIMPRO = @ID_SIMPRO 
       END 
        
  RETURN SCOPE_IDENTITY();
go

