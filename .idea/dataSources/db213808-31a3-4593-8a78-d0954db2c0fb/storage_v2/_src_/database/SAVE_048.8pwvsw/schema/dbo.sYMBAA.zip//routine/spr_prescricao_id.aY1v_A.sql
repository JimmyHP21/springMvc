-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_prescricao_id
	@id bigint 
as
begin
	set nocount on
	select
	 id, tipoatendimento, registro, medico, data, datacriacao, datafinalizacao, usuario, atualizacao, statusprescricao, log, urgente, horario_inicio
	from dbo.prescricao
	where
		id = @id
end
go

