 
-- =============================================
-- Author:		M2 TECNOLOGIA
-- Create date:	06/09/2017
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPList_TUSS_TAB64
AS
BEGIN
	SET NOCOUNT ON

	SELECT
	 TERMINOLOGIA, 
	 CODIGOTUSS, 
	 ENVIO, 
	 GRUPO, 
	 DESCRICAO, 
	 INICIOVIGENCIA, 
	 FIMVIGENCIA, 
	 FIMIMPLANTACAO
	FROM TUSS_TAB64
END
go

