CREATE PROCEDURE [dbo].[SP_INS_VIGENCIA_PORTE_CBHPM]                                                            
                       @DATA_INICIO_VIGENCIA   AS DATETIME = NULL,                                              
                       @DATA_FIM_VIGENCIA      AS DATETIME = NULL,                                              
                       @DESCRICAO_VIGENCIA     AS VARCHAR(100)   ,                                              
                       @NEW_ID_VIGENCIA        AS INTEGER = NULL                                                
AS                                                                                                              
   BEGIN                                                                                                        
       SET NOCOUNT ON                                                                                           
       INSERT INTO VIGENCIA_PORTE_CBHPM ( DATA_INICIO_VIGENCIA                                                  
                                        , DATA_FIM_VIGENCIA                                                     
                                        , DESCRICAO )                                                           
               VALUES                                                                                           
                                   (  @DATA_INICIO_VIGENCIA                                                     
                                     ,@DATA_FIM_VIGENCIA                                                        
                                     ,@DESCRICAO_VIGENCIA )                                                     
                                                                                                                
       SET @NEW_ID_VIGENCIA = SCOPE_IDENTITY();                                                                 
       SELECT @NEW_ID_VIGENCIA AS NEW_ID_VIGENCIA                                                               
   END
go

