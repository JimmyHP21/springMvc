-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_prescricao_item_horario
	@id bigint = null,
	@prescricao_item bigint = null,
	@horario datetime = null,
	@status int = null,
	@usuario int = null,
	@data datetime = null,
	@atualizacao varchar(150) = null,
	@log bigint = null,
	@status_horario int = null
as
begin
	set nocount on
	select
	 id, prescricao_item, horario, status, usuario, data, atualizacao, log
	from dbo.prescricao_item_horario
where (id = @id or @id is null )
 and (prescricao_item = @prescricao_item or @prescricao_item is null )
 and (horario = @horario or @horario is null )
 and (status = @status or @status is null )
 and (usuario = @usuario or @usuario is null )
 and (data = @data or @data is null )
 and (atualizacao = @atualizacao or @atualizacao is null )
 and (log = @log or @log is null )
end
go

