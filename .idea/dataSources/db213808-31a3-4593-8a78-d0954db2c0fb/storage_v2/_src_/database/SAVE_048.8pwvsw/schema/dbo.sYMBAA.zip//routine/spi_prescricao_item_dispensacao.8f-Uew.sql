-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spi_prescricao_item_dispensacao
	@id bigint  output,
	@prescricao_item int  = null,
	@item_horario bigint  = null,
	@produto int ,
	@lote varchar(20) ,
	@validade datetime ,
	@etiqueta int  = null,
	@quantidade money  = null,
	@centrocusto_dispensacao smallint  = null,
	@centrocusto_paciente smallint  = null,
	@usuario int  = null,
	@data datetime  = null,
	@atualizacao varchar(150)  = null,
	@log bigint  = null
as
begin
	set nocount on
	insert into dbo.prescricao_item_dispensacao
		( prescricao_item, item_horario, produto, lote, validade, etiqueta, quantidade, centrocusto_dispensacao, centrocusto_paciente, usuario, data, atualizacao, log)
	values
		(@prescricao_item,@item_horario,@produto,@lote,@validade,@etiqueta,@quantidade,@centrocusto_dispensacao,@centrocusto_paciente,@usuario,@data,@atualizacao,@log)

	select @id = scope_identity()
end
go

