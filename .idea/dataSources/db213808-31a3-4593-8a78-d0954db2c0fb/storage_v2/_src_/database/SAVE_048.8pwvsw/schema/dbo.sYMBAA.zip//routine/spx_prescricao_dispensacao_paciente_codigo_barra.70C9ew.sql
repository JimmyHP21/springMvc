
create proc dbo.spx_prescricao_dispensacao_paciente_codigo_barra
	@prescricao int,
	@horario datetime,
	@setor_estoque int,
	@setor_paciente int,
	@codigo_barra nvarchar(max),
	@usuario int,
	@atualizacao varchar(150),
	@saida int out --[-1]
as
begin tran	
	begin try
	declare @saldo money
	declare @produto bigint
	declare @lote varchar(20)
	declare @validade datetime
	declare @item_horario int
	declare @prescricao_item bigint
	declare @quantidade_prescrita money
	declare @quantidade_dispensada money
	declare @quantidade_dispensar money
	declare @data datetime
	declare @status_prescricao int
	declare @tiporegistro int
	declare @registro int

	set nocount on	
	set @quantidade_dispensar = 1;
	set @saida = 0
	set @data = getdate()
	
	--Prescrição está ativa?
	select @status_prescricao = p.statusprescricao,
		   @tiporegistro = p.tipoatendimento,
		   @registro = p.registro
	from prescricao p
	where p.id = @prescricao;
	
	if isnull(@status_prescricao,0) in (0,2,6) --Aberta, Suspensa e Finalizada
	begin
		set @saida = -10 --Prescrição está impedida de dispensacao
		goto fim
	end;	
	
	--Produto lido pertence a prescrição?
	select top 1
		   @produto = ple.produto,
		   @lote = ple.lote,
		   @validade = ple.validadelote,
		   @prescricao_item = pi.id
	from prescricao_item pi 			
	inner join pres_cad_produto_item as pcpi 
			on pcpi.item = pi.item		
		   and (pi.via = pcpi.via or pi.via is null)
	inner join produto_lote_etiqueta as ple 
			on ple.produto = pcpi.produto 			
	where pi.prescricao = @prescricao
	and ple.sequencia = @codigo_barra;
	
	if isnull(@produto,0) = 0 
	begin
		set @saida = -20 --Item não foi prescrito
		goto fim
	end;

	--Horário pertence a prescrição	
	select top 1 @item_horario = pih.id
	from prescricao_item_horario pih
	where pih.prescricao_item = @prescricao_item
	and pih.horario = @horario
	
	if isnull(@item_horario,0) = 0 
	begin 
		set @saida = -30 --Horário não prescrito para o item
		goto fim
	end
	
	--Horário já foi atendido
	select @quantidade_prescrita = pi.quantidade,
		   @quantidade_dispensada  = sum(isnull(pihd.quantidade,0))
	from prescricao_item pi 
	inner join prescricao_item_horario pih
			on pih.prescricao_item = pi.id
		   and pih.id = @item_horario
	left join prescricao_item_dispensacao pihd
			on pihd.item_horario = pih.id
	group by pi.quantidade
	
	if (@quantidade_dispensada + @quantidade_dispensar) > @quantidade_prescrita 
	begin
		set @saida = -40; --Horário prescrito já foi dispensado
		goto fim
	end
		
	--Verifica se existe saldo
	select @saldo = cc.saldo
	from produtocentrocustolote cc
   where cc.centrocusto = @setor_estoque
	 and cc.produto = @produto
	 and cc.lote = @lote
	 and cc.validade = @validade;
	
	if isnull(@saldo,0) < @quantidade_dispensar
	begin 
		set @saida = -50 --Não há saldo suficiente no sistema
		goto fim
	end;
	
	/*
		update a
		   set a.saldo = a.saldo - (@quantidade_dispensar)
		from produtocentrocusto a
		inner join produto b
				on b.produto = a.produto
		where a.centrocusto = @setor_estoque
		  and a.produto = 
	*/
		
	exec dbo.spi_prescricao_item_dispensacao
		 @prescricao_item = @prescricao_item
		,@item_horario=@item_horario
		,@produto=@produto
		,@lote=@lote
		,@validade=@validade
		,@etiqueta=@codigo_barra
		,@quantidade=@quantidade_dispensar
		,@centrocusto_dispensacao=@setor_estoque
		,@centrocusto_paciente=@setor_paciente
		,@usuario=@usuario
		,@data=@data
		,@atualizacao=@atualizacao
		,@log=null
		,@id=@saida OUTPUT;	
	
	--select 'passou';
	
	if(@tiporegistro = 1)
		insert into movim_int(registro, sequencia, tipolancamento, procedimento,procedimentonome, familia, 
		unidadefaturamento, quantidade, quantidadedispensada, valorunitario, valorgenerico, valorconvenio, data, 
		hora, centrocusto, nota, localconsumo, dataconsumo, horaconsumo, sembaixa, taxasala,substituido, usuario, atualizacao, 
		valorunitcusto, valorcustogenerico, centrocusto_internado, travado, fatorestoque, convlanc, lote, validadelote, 
		local_lancado,observacaoprescricao,datadigitacao)
		SELECT  a.registro	as registro,
				isnull(max(m.sequencia) + 1, 1) as sequencia,
				1	as tipolancamento,
				p.produto	as procedimento,
				p.descricao	as procedimentonome,
				p.familia	as familia,
				p.unidadefaturamento	as unidadefaturamento,
				1	as quantidade,
				1	as quantidadedispensada,
				0.0	as valorunitario,
				0.0	as valorgenerico,
				0.0	as valorconvenio,
				convert(smalldatetime,@data) as data,
				@data	as hora,
				@setor_estoque	as centrocusto,
				@prescricao	as nota,
				1	as localconsumo,
				convert(smalldatetime,@data)	as dataconsumo,
				@data	as horaconsumo,
				0	as sembaixa,
				0	as taxasala,
				0	as substituido,
				u.logon	as usuario,
				@atualizacao	as atualizacao,
				p.custo	as valorunitcusto,
				0	as valorcustogenerico,
				@setor_paciente	as centrocusto_internado,
				0	as travado,
				p.fatorestoque	as fatorestoque,
				p.convlanc	as convlanc,
				@lote	as lote,
				@validade	as validadelote,
				'nova_prescricao'	as local_lancado,
				''	as observacaoprescricao,
				getdate() as datadigitacao
		from interno a
		left join movim_int m 
			   on m.registro = a.registro
		join produto p on p.produto = @produto
		join usuario u on u.usuario = @usuario
		where a.registro = @registro
		group by a.registro, p.produto, p.descricao, p.familia, p.unidadefaturamento, u.logon, p.custo, p.fatorestoque, p.convlanc;
		
	else if @tiporegistro = 2
		insert into movim_amb(registro, sequencia, tipolancamento, procedimento,procedimentonome, familia, 
		unidadefaturamento, quantidade, quantidadedispensada, valorunitario, valorgenerico, valorconvenio, data, 
		hora, centrocusto, nota, localconsumo, dataconsumo, horaconsumo, sembaixa, taxasala,substituido, usuario, atualizacao, 
		valorunitcusto, valorcustogenerico, centrocusto_internado, travado, fatorestoque, convlanc, lote, validadelote, 
		local_lancado,observacaoprescricao,datadigitacao)
		SELECT  a.registro	as registro,
				isnull(max(m.sequencia) + 1, 1) as sequencia,
				1	as tipolancamento,
				p.produto	as procedimento,
				p.descricao	as procedimentonome,
				p.familia	as familia,
				p.unidadefaturamento	as unidadefaturamento,
				1	as quantidade,
				1	as quantidadedispensada,
				0.0	as valorunitario,
				0.0	as valorgenerico,
				0.0	as valorconvenio,
				convert(smalldatetime,@data) as data,
				@data	as hora,
				@setor_estoque	as centrocusto,
				@prescricao	as nota,
				1	as localconsumo,
				convert(smalldatetime,@data)	as dataconsumo,
				@data	as horaconsumo,
				0	as sembaixa,
				0	as taxasala,
				0	as substituido,
				u.logon	as usuario,
				@atualizacao	as atualizacao,
				p.custo	as valorunitcusto,
				0	as valorcustogenerico,
				@setor_paciente	as centrocusto_internado,
				0	as travado,
				p.fatorestoque	as fatorestoque,
				p.convlanc	as convlanc,
				@lote	as lote,
				@validade	as validadelote,
				'nova_prescricao'	as local_lancado,
				''	as observacaoprescricao,
				getdate() as datadigitacao
		from ambulatorial a
		left join movim_amb m 
			   on m.registro = a.registro
		join produto p on p.produto = @produto
		join usuario u on u.usuario = @usuario
		where a.registro = @registro
		group by a.registro, p.produto, p.descricao, p.familia, p.unidadefaturamento, u.logon, p.custo, p.fatorestoque, p.convlanc;
	else if @tiporegistro = 3
		insert into movim_ext(registro, sequencia, tipolancamento, procedimento,procedimentonome, familia, 
		unidadefaturamento, quantidade, quantidadedispensada, valorunitario, valorgenerico, valorconvenio, data, 
		hora, centrocusto, nota, localconsumo, dataconsumo, horaconsumo, sembaixa, taxasala,substituido, usuario, atualizacao, 
		valorunitcusto, valorcustogenerico, centrocusto_internado, travado, fatorestoque, convlanc, lote, validadelote, 
		local_lancado,observacaoprescricao,datadigitacao)
		SELECT  a.registro	as registro,
				isnull(max(m.sequencia) + 1, 1) as sequencia,
				1	as tipolancamento,
				p.produto	as procedimento,
				p.descricao	as procedimentonome,
				p.familia	as familia,
				p.unidadefaturamento	as unidadefaturamento,
				1	as quantidade,
				1	as quantidadedispensada,
				0.0	as valorunitario,
				0.0	as valorgenerico,
				0.0	as valorconvenio,
				convert(smalldatetime,@data) as data,
				@data	as hora,
				@setor_estoque	as centrocusto,
				@prescricao	as nota,
				1	as localconsumo,
				convert(smalldatetime,@data)	as dataconsumo,
				@data	as horaconsumo,
				0	as sembaixa,
				0	as taxasala,
				0	as substituido,
				u.logon	as usuario,
				@atualizacao	as atualizacao,
				p.custo	as valorunitcusto,
				0	as valorcustogenerico,
				@setor_paciente	as centrocusto_internado,
				0	as travado,
				p.fatorestoque	as fatorestoque,
				p.convlanc	as convlanc,
				@lote	as lote,
				@validade	as validadelote,
				'nova_prescricao'	as local_lancado,
				''	as observacaoprescricao,
				getdate() as datadigitacao
		from externo a
		left join movim_ext m 
			   on m.registro = a.registro
		join produto p on p.produto = @produto
		join usuario u on u.usuario = @usuario
		where a.registro = @registro
		group by a.registro, p.produto, p.descricao, p.familia, p.unidadefaturamento, u.logon, p.custo, p.fatorestoque, p.convlanc;
	
	fim:
	commit tran
	--select @saida
end try
begin catch
	rollback tran
    select
        error_number() as errornumber
        ,error_severity() as errorseverity
        ,error_state() as errorstate
        ,error_procedure() as errorprocedure
        ,error_line() as errorline
        ,error_message() as errormessage;	
end catch;
go

