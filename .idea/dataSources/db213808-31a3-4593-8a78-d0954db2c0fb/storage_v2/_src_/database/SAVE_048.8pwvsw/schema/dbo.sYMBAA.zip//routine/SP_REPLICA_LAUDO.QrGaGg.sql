CREATE PROCEDURE SP_REPLICA_LAUDO         @MEDICOCOPIAR            BIGINT = NULL,
                                   @CENTROCUSTO            BIGINT = NULL,
                                   @MEDICOCOPIA            BIGINT = NULL,
                                   @CENTROCUSTODESTINO     BIGINT = NULL
AS
BEGIN TRAN
INSERT INTO LAU_MODELO
       ([LAUDO]
       ,[NOMELAUDO]
       ,[TEXTO]
       ,[TEXTOFORMATADO]
       ,[CENTROCUSTO]
       ,[MEDICO]
       ,[ATUALIZACAO]
       ,[GRUPO]
       ,[RASCUNHO]
       ,[IMPRIMEFOLHASEPARADA]
       ,[DESATIVADO]
       ,[QTDEMAXIMA]
       ,[IMPRIMERASCUNHOSEPARADO]
       ,[INTERFACEAMENTOLABORATORIO]
       ,[SEQUENCIAIMPRESSAORDEM]
       ,[RESULTADOANTERIOR]
       ,[EXAMETERCEIRIZADO]
       ,[VALORCH]
       ,[NOME_ABREVIADO]
       ,[INTEGRARLABORATORIO])
SELECT     
       [LAUDO]
       ,[NOMELAUDO]
       ,[TEXTO]
       ,[TEXTOFORMATADO]
       ,@CENTROCUSTODESTINO
       ,@MEDICOCOPIA
       ,[ATUALIZACAO]
       ,[GRUPO]
       ,[RASCUNHO]
       ,[IMPRIMEFOLHASEPARADA]
       ,[DESATIVADO]
       ,[QTDEMAXIMA]
       ,[IMPRIMERASCUNHOSEPARADO]
       ,[INTERFACEAMENTOLABORATORIO]
       ,[SEQUENCIAIMPRESSAORDEM]
       ,[RESULTADOANTERIOR]
       ,[EXAMETERCEIRIZADO]
       ,[VALORCH]
       ,[NOME_ABREVIADO]
       ,[INTEGRARLABORATORIO] FROM LAU_MODELO 
       WHERE MEDICO = @MEDICOCOPIAR 
           AND CENTROCUSTO = @CENTROCUSTO
           AND NOMELAUDO NOT IN(SELECT NOMELAUDO FROM LAU_MODELO 
                                                 WHERE MEDICO = @MEDICOCOPIA 
                                                       AND CENTROCUSTO = @CENTROCUSTODESTINO);
INSERT INTO LAU_MODELO_ELEMENTO
           ([LAUDO]
           ,[CENTROCUSTO]
           ,[MEDICO]
           ,[CODIGO]
           ,[DESCRICAO]
           ,[ATUALIZACAO])
SELECT      [LAUDO]
           ,@CENTROCUSTODESTINO
           ,@MEDICOCOPIA
           ,[CODIGO]
           ,[DESCRICAO]
           ,[ATUALIZACAO]
           FROM LAU_MODELO_ELEMENTO 
           WHERE MEDICO = @MEDICOCOPIAR 
               AND CENTROCUSTO = @CENTROCUSTO
               AND LAUDO NOT IN(SELECT LAUDO FROM LAU_MODELO_ELEMENTO 
                                                       WHERE MEDICO = @MEDICOCOPIA 
                                                           AND CENTROCUSTO = @CENTROCUSTODESTINO);
INSERT INTO [dbo].[LAU_LAUDOCONVENIO]
           ([LAUDO]
           ,[CODIGOTABELA]
           ,[NOMETABELA]
           ,[ATUALIZACAO]
           ,[CODIGOPROCEDIMENTO]
           ,[TIPO]
           ,[PROCEDIMENTONOME]
           ,[MEDICO]
           ,[CENTROCUSTO]
           ,[INCIDENCIA])
SELECT     [LAUDO]
           ,[CODIGOTABELA]
           ,[NOMETABELA]
           ,[ATUALIZACAO]
           ,[CODIGOPROCEDIMENTO]
           ,[TIPO]
           ,[PROCEDIMENTONOME]
           ,@MEDICOCOPIA
           ,@CENTROCUSTODESTINO
           ,[INCIDENCIA]
          FROM [LAU_LAUDOCONVENIO]
          WHERE MEDICO = @MEDICOCOPIAR 
               AND CENTROCUSTO = @CENTROCUSTO
               AND CODIGOPROCEDIMENTO NOT IN(SELECT CODIGOPROCEDIMENTO FROM [LAU_LAUDOCONVENIO] 
                                       WHERE MEDICO = @MEDICOCOPIA 
                                           AND CENTROCUSTO = @CENTROCUSTODESTINO);
INSERT INTO [dbo].[LAU_MODELO_ELEMENTO_CLASSIFICACAO]
                  ([LAUDO]
                  ,[MEDICO]
                  ,[CENTROCUSTO]
                  ,[CODIGOLINHA]
                  ,[CODIGO]
                  ,[DESCRICAO]
                  ,[ATUALIZACAO])
SELECT [LAUDO] 
                  ,@MEDICOCOPIA
                  ,@CENTROCUSTODESTINO
                  ,[CODIGOLINHA]
                  ,[CODIGO]
                  ,[DESCRICAO]
                  ,[ATUALIZACAO]
          FROM [dbo].[LAU_MODELO_ELEMENTO_CLASSIFICACAO]
          WHERE MEDICO = @MEDICOCOPIAR 
               AND CENTROCUSTO = @CENTROCUSTO
               AND DESCRICAO NOT IN(SELECT DESCRICAO FROM [LAU_MODELO_ELEMENTO_CLASSIFICACAO] 
                                                       WHERE MEDICO = @MEDICOCOPIA 
                                                           AND CENTROCUSTO = @CENTROCUSTODESTINO);
COMMIT
go

