
-- =============================================
-- Author:		Samuel Remoardo
-- Create date:	26/08/2014
-- Description:	
-- Revisions:	
-- =============================================
Create Procedure SPIns_SDU_DatabaseVersion
	@idVerDatabase bigint,
	@idReqVerSysA int,
	@idReqVerSysB int,
	@idReqVerSysC int,
	@idReqVerSysD int,
	@dthBegin datetime,
	@dthEnd datetime,
	@idUser bigint,
	@nameUser varchar(max),
	@idSession bigint,
	@hostname varchar(100),
	@ipAddress varchar(15),
	@macAddress varchar(24),
	@logExecution varchar(max)
AS
Begin
	SET NOCOUNT ON
	insert into SDU_DatabaseVersion
		( idVerDatabase,idReqVerSysA,idReqVerSysB,idReqVerSysC,idReqVerSysD,dthBegin, dthEnd, idUser, nameUser, idSession, hostname, ipAddress, macAddress, logExecution)
	values
		(@idVerDatabase,@idReqVerSysA,@idReqVerSysB,@idReqVerSysC,@idReqVerSysD,@dthBegin,@dthEnd,@idUser,@nameUser,@idSession,@hostname,@ipAddress,@macAddress,@logExecution)

	--select @idVerDatabase = SCOPE_IDENTITY()
	select @idVerDatabase
End
go

