-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spl_prescricao_item_dispensacao

as
begin
	set nocount on
	select
	 id, prescricao_item, item_horario, produto, lote, validade, etiqueta, quantidade, centrocusto_dispensacao, centrocusto_paciente, usuario, data, atualizacao, log
	from dbo.prescricao_item_dispensacao
end
go

