 
-- =============================================
-- Author:		M2 TECNOLOGIA
-- Create date:	06/09/2017
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPList_TUSS_TAB63
AS
BEGIN
	SET NOCOUNT ON

	SELECT
	 CODIGO, 
	 GRUPO, 
	 INICIOVIGENCIA, 
	 FIMVIGENCIA, 
	 FIMIMPLANTACAO
	FROM TUSS_TAB63
END
go

