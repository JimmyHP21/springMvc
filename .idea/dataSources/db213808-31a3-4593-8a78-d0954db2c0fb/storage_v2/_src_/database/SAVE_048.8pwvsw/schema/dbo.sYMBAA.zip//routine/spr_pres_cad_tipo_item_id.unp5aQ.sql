-- =============================================
-- author:		m2 tecnologia
-- create date:	27/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_pres_cad_tipo_item_id
	@id int 
as
begin
	set nocount on
	select
	 id, descricao, ordemimpressao, utilizavia, utilizaunidade, atualizacao, utilizaintervalo, utilizaapresentacao, log, utilizaprodutoestoque, exibe_em_dispensacao, exibe_em_impressao, assoc_material, assoc_medicamento, assoc_procedimento, assoc_taxa, exibe_em_prescricao
	from dbo.pres_cad_tipo_item
	where
		id = @id
end
go

