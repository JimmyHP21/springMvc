create view v_entrada_nota
as
	select b.fabricante as fornecedor
		,a.pedidocompra as pedido
		,a.notafiscal as nota
		,a.serie as serie
		,a.centrocusto as centrocusto
		,a.produto as produto
		,a.lote as lote
		,a.validadelote as validade
		,a.quantidade - isnull(a.quantidadedevolvida, 0) as quantidade
		,a.valorunitario as valor
		,a.dataemissao as data_emissao
		,a.dataentrega as data_lancamento
		,convert(datetime, left(a.atualizacao, 19)) as data_movimento
-- ,a.dataentrega as data_movimento
		,0 as  doacao
		,a.consignacao
	from pedidocompraprodutonota1 a
	inner join pedidocompra1 b on a.pedidocompra = b.pedidocompra
-- where a.dataentrega >= '2014/08/01' and a.dataentrega <= '2014/08/31'
	union all	
	select a.fornecedor
		,null as pedido
		,a.documento as nota
		,a.serie as serie
		,a.ccorigem as centrocusto
		,a.produto as produto
		,a.lote as lote
		,a.validadelote as validade
		,a.quantidade - (sum(isnull(h.quantidade, 0))) as quantidade
		,a.precobrasindice as valor
		,a.data as data_emissao
		,a.datalancamento as data_lancamento
		,convert(datetime, left(a.atualizacao, 19)) as data_movimento
-- ,a.datalancamento as data_movimento
		,a.doacao
		,a.consignacao
	from movimentoavulso a
	left join movimentoavulso h  on a.ccorigem = h.ccorigem
								and a.fornecedor = h.fornecedor
								and a.data = h.data
								and a.produto = h.produto
								and a.documento = h.documento
								and a.lote = h.lote
								and a.validadelote = h.validadelote
								and h.tipo = 1
	where 1 = 1
		and a.tipo = 0
-- and a.datalancamento >= '2014/08/01' and a.datalancamento <= '2014/08/31'
	group by a.fornecedor
		,a.documento
		,a.serie
		,a.ccorigem
		,a.produto
		,a.lote
		,a.validadelote
		,a.quantidade
		,a.precobrasindice
		,a.data
		,a.datalancamento
		,a.atualizacao
		,a.doacao
		,a.consignacao
	having (a.quantidade - (sum(isnull(h.quantidade, 0)))) > 0
go

