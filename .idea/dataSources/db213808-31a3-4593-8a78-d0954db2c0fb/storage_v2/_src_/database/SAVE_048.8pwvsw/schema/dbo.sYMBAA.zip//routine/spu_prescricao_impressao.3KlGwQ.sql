-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spu_prescricao_impressao
	@id bigint ,
	@data_impressao datetime ,
	@prescricao bigint ,
	@atualizacao varchar(150)  = null,
	@log bigint  = null,
	@data datetime  = null,
	@usuario int  = null
as
begin
	set nocount on
	update dbo.prescricao_impressao
	set
		data_impressao = @data_impressao,
		prescricao = @prescricao,
		atualizacao = @atualizacao,
		log = @log,
		data = @data,
		usuario = @usuario
	where
		id = @id
end
go

