-- =============================================
-- author:		m2 tecnologia
-- create date:	27/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spi_pres_cad_tipo_item
	@id int  output,
	@descricao varchar(50)  = null,
	@ordemimpressao int  = null,
	@utilizavia int  = null,
	@utilizaunidade int  = null,
	@atualizacao varchar(150)  = null,
	@utilizaintervalo int  = null,
	@utilizaapresentacao int  = null,
	@log bigint  = null,
	@utilizaprodutoestoque int  = null,
	@exibe_em_dispensacao int  = null,
	@exibe_em_impressao int  = null,
	@assoc_material int  = null,
	@assoc_medicamento int  = null,
	@assoc_procedimento int  = null,
	@assoc_taxa int  = null,
	@exibe_em_prescricao int  = null
as
begin
	set nocount on
	insert into dbo.pres_cad_tipo_item
		( descricao, ordemimpressao, utilizavia, utilizaunidade, atualizacao, utilizaintervalo, utilizaapresentacao, log, utilizaprodutoestoque, exibe_em_dispensacao, exibe_em_impressao, assoc_material, assoc_medicamento, assoc_procedimento, assoc_taxa, exibe_em_prescricao)
	values
		(@descricao,@ordemimpressao,@utilizavia,@utilizaunidade,@atualizacao,@utilizaintervalo,@utilizaapresentacao,@log,@utilizaprodutoestoque,@exibe_em_dispensacao,@exibe_em_impressao,@assoc_material,@assoc_medicamento,@assoc_procedimento,@assoc_taxa,@exibe_em_prescricao)

	select @id = scope_identity()
end
go

