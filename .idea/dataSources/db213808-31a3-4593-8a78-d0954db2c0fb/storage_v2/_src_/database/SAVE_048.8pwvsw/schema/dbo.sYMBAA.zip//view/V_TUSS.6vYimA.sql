

CREATE VIEW V_TUSS
AS
  --DIARIAS, TAXAS, E GASES MEDICINAIS                                                
  SELECT DISTINCT (CASE WHEN ISNULL(CONVERT(VARCHAR,A.UNIDADEFATURAMENTO),'') NOT IN ('','0') AND 
							 ISNULL(CONVERT(VARCHAR,A.UNIDADEFATURAMENTO),'') <> ISNULL(B.CODIGO,'') THEN '00'
						ELSE ISNULL(C.TABELA, ISNULL(D.TABELA,'00'))    END)											AS TIPO_TABELA,
         'INSUMO'                                                                                                       AS TIPO_DESC,
         A.INSUMO                                                                                                       AS COD_SAVE,
		 (CASE WHEN ISNULL(CONVERT(VARCHAR,A.UNIDADEFATURAMENTO),'') NOT IN ('','0') THEN CONVERT(VARCHAR,A.UNIDADEFATURAMENTO)
			   WHEN ISNULL(CONVERT(VARCHAR,B.CODIGO),'') NOT IN ('','0') THEN CONVERT(VARCHAR,B.CODIGO)
			   ELSE CONVERT(VARCHAR,A.INSUMO)
		 END)																											AS COD_TUSS,
         ISNULL(B.DESCRICAO, A.DESCRICAO)                                                                               AS DESC_TUSS,
         ISNULL(B.INICIOVIGENCIA, '1900/01/01')                                                                         AS INICIO_VIGENCIA_TUSS,
         B.FIMVIGENCIA + '23:59:59'                                                                                     AS FIM_VIGENCIA_TUSS,
         '1900/01/01'							                                                                        AS INICIO_VIGENCIA,
         NULL                                                                                                           AS FIM_VIGENCIA,         
         A.CONVENIO                                                                                                     AS CONVENIO,
         (CASE WHEN ISNULL(CONVERT(VARCHAR,A.UNIDADEFATURAMENTO),'') NOT IN ('','0') THEN 2
			   WHEN ISNULL(CONVERT(VARCHAR,B.CODIGO),'') NOT IN ('','0') THEN 1
			   ELSE 2		 
		 END)                                                                                                           AS TAB_CONVENIO,--1-CODIGO_TUSS, 2-CODIGO_PROPRIO, 3-BRASINDICE, 4-SIMPRO
         --GRUPOS DE INSUMOS SAVE
         --1 Gases Medicinais
         --4 Taxas Diversas
         --5 Diárias
         --6 Aluguéis
         ( CASE A.GRUPOTISS
             WHEN 1 THEN 1
             WHEN 4 THEN 7
             WHEN 5 THEN 5
             WHEN 6 THEN 7
           END )                                                                                                        AS TIPO_DESPESA
  FROM   INSUMOS A WITH (READPAST)
		INNER JOIN CONVENIOS CONV WITH (READPAST)  
				ON CONV.CONVENIO = A.CONVENIO
         LEFT JOIN TUSS_TAB18 B WITH (READPAST)
                ON B.CODIGO = A.CODIGO_TUSS
         LEFT JOIN (SELECT '18' AS TABELA) C
                ON B.CODIGO IS NOT NULL				
         LEFT JOIN (SELECT '98' AS TABELA) D
                ON B.CODIGO IS NULL
				AND ISNULL(A.PACOTE,0) <> 0
	--WHERE A.INSUMO IS NULL
  UNION ALL
  --MATERIAIS E OPME
  SELECT DISTINCT 
		(CASE 
			WHEN ((PARAMETRO.LAYOUTCONTRATO) = 1 AND CONV.CONVENIO = 39 AND C.CODIGO = 19) THEN CASE WHEN ISNULL(E.TABELA, '00') = '00' THEN '00' ELSE '20' END
			WHEN ISNULL(CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS),'') NOT IN ('','0') AND
			     ISNULL(CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS),'') <> ISNULL(B.CODIGO,'') THEN '00'
			ELSE ISNULL(E.TABELA, '00') 
		END)																											 AS TIPO_TABELA,
         (CASE
			WHEN ((PARAMETRO.LAYOUTCONTRATO) = 1 AND CONV.CONVENIO = 39 AND C.CODIGO = 19) THEN 'MEDICAMENTO'
			ELSE 'MATERIAL'
		  END)																											 AS TIPO_DESC,
         A.PRODUTO                                                                                                       AS COD_SAVE,
		 (CASE WHEN ISNULL(CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS),'') NOT IN ('','0') AND ISNULL(PC.CODIGO_CONVENIO_TISS,'') <> ISNULL(B.CODIGO,'') THEN CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS)
			   WHEN B.CODIGO IS NOT NULL THEN CONVERT(VARCHAR,B.CODIGO)
			   WHEN CONV.TIPOCONVENIO = 2 AND ISNULL(CONVERT(VARCHAR,A.CODIGOUNIMED),'') NOT IN ('','0') THEN CONVERT(VARCHAR,A.CODIGOUNIMED)
			   WHEN BT.CODIGOTISS IS NOT NULL AND (CONV.TIPO = 1 OR SP.CD_SIMPRO IS NULL) THEN CONVERT(VARCHAR,BT.CODIGOTISS)
			   WHEN SP.CD_SIMPRO IS NOT NULL AND  (CONV.TIPO = 2 OR BT.CODIGOTISS IS NULL) THEN CONVERT(VARCHAR,SP.CD_SIMPRO)
			   ELSE CONVERT(VARCHAR, A.PRODUTO)
		 END)																										     AS COD_TUSS,
         --B.CODIGO AS COD_TUSS,
         (CASE 	WHEN ISNULL(PC.DESCRICAOPRODUTOCONVENIO,'') <> '' AND ISNULL(PC.CODIGO_CONVENIO_TISS,'') <> ISNULL(B.CODIGO,'') THEN PC.DESCRICAOPRODUTOCONVENIO
				WHEN ISNULL(B.DESCRICAO,'') <> '' THEN B.DESCRICAO + ISNULL(' REF:' + B.REFERENCIA,'')
			   ELSE A.DESCRICAO END)																					 AS DESC_TUSS,
         ISNULL(B.INICIOVIGENCIA, '1900/01/01')                                                                          AS INICIO_VIGENCIA_TUSS,
         B.FIMVIGENCIA + '23:59:59'                                                                                      AS FIM_VIGENCIA_TUSS,
         ISNULL(PC.INICIO_VIGENCIA,'1900/01/01')                                                                         AS INICIO_VIGENCIA,
         PC.FINAL_VIGENCIA + '23:59:59'                                                                                  AS FIM_VIGENCIA,              
         CONV.CONVENIO                                                                                                   AS CONVENIO,
        (CASE  WHEN ISNULL(CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS),'') NOT IN ('','0') AND ISNULL(PC.CODIGO_CONVENIO_TISS,'') <> ISNULL(B.CODIGO,'') THEN 2
			   WHEN B.CODIGO IS NOT NULL THEN 1		   
			   WHEN CONV.TIPOCONVENIO = 2 AND ISNULL(CONVERT(VARCHAR,A.CODIGOUNIMED),'') NOT IN ('','0') THEN 2
			   WHEN BT.CODIGOTISS IS NOT NULL and (CONV.TIPO = 1 OR SP.CD_SIMPRO IS NULL) THEN 3
			   WHEN SP.CD_SIMPRO IS NOT NULL and  (CONV.TIPO = 2 OR BT.CODIGOTISS IS NULL) THEN 4
			   ELSE 2
		 END)                                                                                                            AS TAB_CONVENIO,--1-CODIGO_TUSS, 2-CODIGO_PROPRIO, 3-BRASINDICE, 4-SIMPRO
         ( CASE
             WHEN ISNULL(D.MATERIALESPECIAL, 0) = 1 THEN 8
			 WHEN ((PARAMETRO.LAYOUTCONTRATO) = 1 AND CONV.CONVENIO = 39 AND C.CODIGO = 19) THEN 2
             ELSE 3
           END )                                                                                                         AS TIPO_DESPESA
  FROM   PRODUTO A WITH (READPAST)
  CROSS JOIN CONVENIOS CONV WITH (READPAST)
  CROSS JOIN PARAMETROS PAR WITH (READPAST)
  CROSS JOIN PARAMETRO PARAMETRO WITH (READPAST)
         INNER JOIN PRODUTOTIPO C WITH (READPAST)
                 ON C.CODIGO = LEFT(RIGHT(REPLICATE('0', 7) + CONVERT(VARCHAR,A.PRODUTO), 7), 2)
                    AND ISNULL(C.TIPOFARMACIA,0) <> 1
				
  		  LEFT JOIN PRODUTOCONVENIO PC WITH (READPAST)
		    	 ON PC.PRODUTO = A.PRODUTO
				AND CONV.CONVENIO = PC.CONVENIO
				AND ISNULL(PC.EXCLUIDO,0) = 0
				
         LEFT JOIN PRODUTOFAMILIA D WITH (READPAST)
                ON A.FAMILIA = D.FAMILIA				
		
		LEFT JOIN IMPORTACAO_BRASINDICETUSS IMP WITH (READPAST)
				ON IMP.EDICAO = ISNULL(PAR.EDICAOBRASINDICE,ISNULL(CONV.EDICAOBRASINDICE,0))
				AND REPLACE(IMP.LABCODIGO,' ','') = REPLACE(ISNULL(PC.CODLABOBRAS,A.CODLABOBRAS),' ','')
				AND	REPLACE(IMP.MEDCODIGO,' ','') = REPLACE(ISNULL(PC.MEDICBRAS,A.MEDICBRAS),' ','')
				AND REPLACE(IMP.APRCODIGO,' ','') = REPLACE(ISNULL(PC.CODAPREBRAS,A.CODAPREBRAS),' ','')
				AND (CONV.TIPOPRECO = 1 OR PARAMETRO.CONVENIO_TIPOCALCULO = 1 ) --[1-BRASINDICE, 2-SIMPRO, 3-ABC FARMA, 4-PROPRIA]
				AND IMP.TIPOPRECO = 'PFB'
		
	     LEFT JOIN BRASINDICETUSS BT WITH (READPAST)
			    ON  BT.LABCODIGO = IMP.LABCODIGO
				AND BT.MEDCODIGO = IMP.MEDCODIGO
				AND BT.APRCODIGO = IMP.APRCODIGO
				AND BT.EDICAOBRAS = IMP.EDICAOBRAS
				AND ISNULL(CONVERT(VARCHAR,BT.CODIGOTISS),'') NOT IN ('','0')
				 
		  LEFT JOIN SIMPRO SP WITH (READPAST)
				 ON CONVERT(BIGINT,SP.CD_SIMPRO) = CONVERT(BIGINT,A.SIMPROCODIGO)
				AND SP.VIGENTE = 1
				--AND CONV.TIPO = 2 --[1-BRASINDICE, 2-SIMPRO, 3-ABC FARMA, 4-PROPRIA]
				AND ISNULL(CONVERT(VARCHAR,SP.CD_SIMPRO),'') NOT IN ('','0')
				
         LEFT JOIN TUSS_TAB19 B WITH (READPAST)
                ON B.CODIGO = (CASE WHEN ISNULL(PC.CODIGOTUSSBRASINDICE,'') NOT IN ('','0') THEN PC.CODIGOTUSSBRASINDICE									
									WHEN ISNULL(BT.CODIGOTUSS,'') NOT IN ('','0') THEN BT.CODIGOTUSS
									WHEN ISNULL(SP.CD_TUSS,'') NOT IN ('','0') THEN SP.CD_TUSS
									WHEN ISNULL(A.CODIGO_TUSS,'') NOT IN ('','0') THEN A.CODIGO_TUSS
									WHEN ISNULL(A.CODIGOTUSSBRASINDICE,'') NOT IN ('','0') THEN A.CODIGOTUSSBRASINDICE
									ELSE A.CODIGOTUSSSIMPRO
								END)
				AND (ISNULL(CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS),'') IN ('0','') 
					 OR  (ISNULL(CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS),'') NOT IN ('0','') 
					      AND ISNULL(CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS),'') = ISNULL(PC.CODIGOTUSSBRASINDICE,''))
					 )
								
         LEFT JOIN (SELECT '19' AS TABELA) E
                ON B.CODIGO IS NOT NULL
	--WHERE A.PRODUTO IS NULL
  UNION ALL
  --MEDICAMENTOS
  SELECT DISTINCT (CASE WHEN ISNULL(CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS),'') NOT IN ('','0') AND 
							 ISNULL(CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS),'') <> ISNULL(B.CODIGO,'') THEN '00'
						ELSE ISNULL(E.TABELA, '00') END)                                                                 AS TIPO_TABELA,
         'MEDICAMENTO'                                                                                                   AS TIPO_DESC,
         A.PRODUTO                                                                                                       AS COD_SAVE,
         (CASE WHEN ISNULL(CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS),'') NOT IN ('','0') AND ISNULL(PC.CODIGO_CONVENIO_TISS,'') <> ISNULL(B.CODIGO,'') THEN CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS)
			   WHEN B.CODIGO IS NOT NULL THEN CONVERT(VARCHAR, B.CODIGO) 
               WHEN CONV.TIPOCONVENIO = 2 AND ISNULL(CONVERT(VARCHAR,A.CODIGOUNIMED),'') NOT IN ('','0') THEN CONVERT(VARCHAR,A.CODIGOUNIMED)
			   WHEN BT.CODIGOTISS IS NOT NULL THEN CONVERT(VARCHAR,BT.CODIGOTISS)
			   ELSE CONVERT(VARCHAR,A.PRODUTO)
		 END)																									 		 AS COD_TUSS,
         --B.CODIGO AS COD_TUSS,
         (CASE WHEN ISNULL(PC.DESCRICAOPRODUTOCONVENIO,'') <> '' AND ISNULL(PC.CODIGO_CONVENIO_TISS,'') <> ISNULL(B.CODIGO,'') THEN PC.DESCRICAOPRODUTOCONVENIO
			   WHEN ISNULL(B.DESCRICAO,'') <> '' THEN B.DESCRICAO + ' ' + B.APRESENTACAO
			   ELSE A.DESCRICAO END)																					 AS DESC_TUSS,		 
         ISNULL(B.INICIOVIGENCIA, '1900/01/01')                                                                          AS INICIO_VIGENCIA_TUSS,
         B.FIMVIGENCIA + '23:59:59'                                                                                      AS FIM_VIGENCIA_TUSS,
         ISNULL(PC.INICIO_VIGENCIA,'1900/01/01')                                                                         AS INICIO_VIGENCIA,
         PC.FINAL_VIGENCIA + '23:59:59'                                                                                  AS FIM_VIGENCIA,              
         CONV.CONVENIO                                                                                                   AS CONVENIO,
         (CASE WHEN ISNULL(CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS),'') NOT IN ('','0') AND ISNULL(PC.CODIGO_CONVENIO_TISS,'') <> ISNULL(B.CODIGO,'') THEN 2
			   WHEN B.CODIGO IS NOT NULL THEN 1
			   WHEN CONV.TIPOCONVENIO = 2 AND ISNULL(CONVERT(VARCHAR,A.CODIGOUNIMED),'') NOT IN ('','0') THEN 2
			   WHEN BT.CODIGOTISS IS NOT NULL THEN 3
			   ELSE 2
		 END)                                                                                                            AS TAB_CONVENIO,--1-CODIGO_TUSS, 2-CODIGO_PROPRIO, 3-BRASINDICE, 4-SIMPRO
         ( CASE
             WHEN D.TIPO = 2 THEN 8
             ELSE 2
           END )                																					     AS TIPO_DESPESA
  FROM   PRODUTO A WITH (READPAST)
  CROSS JOIN CONVENIOS CONV WITH (READPAST)
  CROSS JOIN PARAMETROS PAR WITH (READPAST)
  CROSS JOIN PARAMETRO PARAMETRO WITH (READPAST)
         INNER JOIN PRODUTOTIPO C WITH (READPAST)
                 ON C.CODIGO = LEFT(RIGHT(REPLICATE('0', 7) + CONVERT(VARCHAR,A.PRODUTO), 7), 2)
                    AND ISNULL(C.TIPOFARMACIA,0) = 1
				
 		  LEFT JOIN PRODUTOCONVENIO PC WITH (READPAST) 
		    	 ON PC.PRODUTO = A.PRODUTO 
				AND CONV.CONVENIO = PC.CONVENIO
				AND ISNULL(PC.EXCLUIDO,0) = 0

         LEFT JOIN FARMACIAFAMILIA D WITH (READPAST) 
                ON A.FAMILIA = D.FARMACIAFAMILIA 

		LEFT JOIN IMPORTACAO_BRASINDICETUSS IMP WITH (READPAST)
				ON IMP.EDICAO = ISNULL(PAR.EDICAOBRASINDICE,ISNULL(CONV.EDICAOBRASINDICE,0))
				AND REPLACE(IMP.LABCODIGO,' ','') = REPLACE(ISNULL(PC.CODLABOBRAS,A.CODLABOBRAS),' ','')
				AND	REPLACE(IMP.MEDCODIGO,' ','') = REPLACE(ISNULL(PC.MEDICBRAS,A.MEDICBRAS),' ','')
				AND REPLACE(IMP.APRCODIGO,' ','') = REPLACE(ISNULL(PC.CODAPREBRAS,A.CODAPREBRAS),' ','')				
				AND (CONV.TIPOPRECO = 1 OR PARAMETRO.CONVENIO_TIPOCALCULO = 1 ) --[1-BRASINDICE, 2-SIMPRO, 3-ABC FARMA, 4-PROPRIA]
				AND IMP.TIPOPRECO = 'PFB'
		
	     LEFT JOIN BRASINDICETUSS BT WITH (READPAST)
			    ON  BT.LABCODIGO = IMP.LABCODIGO
				AND BT.MEDCODIGO = IMP.MEDCODIGO
				AND BT.APRCODIGO = IMP.APRCODIGO
				AND BT.EDICAOBRAS = IMP.EDICAOBRAS
				AND ISNULL(CONVERT(VARCHAR,BT.CODIGOTISS),'') NOT IN ('','0')
				
         LEFT JOIN TUSS_TAB20 B WITH (READPAST)
                ON B.CODIGO = (CASE WHEN ISNULL(PC.CODIGOTUSSBRASINDICE,'') NOT IN ('','0') THEN PC.CODIGOTUSSBRASINDICE
									WHEN ISNULL(BT.CODIGOTUSS,'') NOT IN ('','0') THEN BT.CODIGOTUSS
									WHEN ISNULL(A.CODIGO_TUSS,'') NOT IN ('','0') THEN A.CODIGO_TUSS
									WHEN ISNULL(A.CODIGOTUSSBRASINDICE,'') NOT IN ('','0') THEN A.CODIGOTUSSBRASINDICE
									ELSE NULL
								END)
				AND (ISNULL(CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS),'') IN ('0','') 
					 OR  (ISNULL(CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS),'') NOT IN ('0','') 
					 AND ISNULL(CONVERT(VARCHAR,PC.CODIGO_CONVENIO_TISS),'') = ISNULL(PC.CODIGOTUSSBRASINDICE,''))
					 )
				
         LEFT JOIN (SELECT '20' AS TABELA) E
                ON B.CODIGO IS NOT NULL
	--WHERE A.PRODUTO IS NULL
  UNION ALL
  --PROCEDIMENTOS
  SELECT DISTINCT ISNULL(C.TABELA, '00')                                                                                         AS TIPO_TABELA,
         'PROCEDIMENTO'                                                                                                 AS TIPO_DESC,
         A.CODIGO                                                                                                       AS COD_SAVE,
         CONVERT(VARCHAR,ISNULL(B.CODIGO, A.CODIGO)) 																	AS COD_TUSS,
         --B.CODIG0 AS COD_TUSS,
         ISNULL(B.DESCRICAO, A.DESCRICAO)                                                                               AS DESC_TUSS,        
         ISNULL(B.INICIOVIGENCIA, '1900/01/01')                                                                         AS INICIO_VIGENCIA_TUSS,
         B.FIMVIGENCIA + '23:59:59'                                                                                     AS FIM_VIGENCIA_TUSS,
         '1900/01/01'    						                                                                        AS INICIO_VIGENCIA,
         NULL                                                                                                           AS FIM_VIGENCIA,                       
         NULL                                                                                                           AS CONVENIO,
         A.TIPO                                                                                                         AS TAB_PROCEDIMENTO,
         NULL                                                                                                           AS TIPO_DESPESA
  FROM   V_RECUPERATABELAPROCEDIMENTO A
         LEFT JOIN TUSS_TAB22 B (READPAST)
				ON B.CODIGO = (CASE WHEN ISNULL(A.TUSS,'') NOT IN ('','0') THEN A.TUSS ELSE A.CODIGO END)
         LEFT JOIN (SELECT '22' AS TABELA) C
                ON B.CODIGO IS NOT NULL
  --where a.codigo is null
--TAB_CONVENIO
--1  AMB/92
--2  AMB/99
--3  Brasil
--4  Ciefas 1997
--5  SUS
--6  Particular
--7  Ciefas 2000
--8  IAMSPE
--9  Sul América
--10 Bradesco
--11 Caixa Econômica Federal
--12 InterClinica
--13 Cabesp
--14 AMB/90
--15 CBHPM
--16 Sus Unificada
--17 CBHPM 3
--18 CBHPM 4
--19 CBHPM 5
--20 Brasil v2
--21 Brasil v3  

--SELECT TOP 10000 * FROM V_TUSS WHERE TIPO_DESC = 'PROCEDIMENTO'
go

