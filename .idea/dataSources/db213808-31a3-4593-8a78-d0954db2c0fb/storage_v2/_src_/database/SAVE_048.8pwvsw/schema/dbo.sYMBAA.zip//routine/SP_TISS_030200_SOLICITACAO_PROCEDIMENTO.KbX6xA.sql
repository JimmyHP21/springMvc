
--EXEC SP_TISS_030200_SOLICITACAO_PROCEDIMENTO 115461,'URGENCIA'
CREATE PROCEDURE SP_TISS_030200_SOLICITACAO_PROCEDIMENTO  
  @REGISTRO      VARCHAR(MAX) = NULL,
  @TIPOREGISTRO  VARCHAR(MAX) = NULL,
  @GUIAINTERNA  VARCHAR(MAX) = NULL
AS
IF @TIPOREGISTRO = 'EXTERNO'
BEGIN
          SELECT DISTINCT 
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------CHAVES--------------------------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------
          @TIPOREGISTRO                                                     AS TIPO_REGISTRO,
          ATEND.REGISTRO                                                    AS REGISTRO,
		  ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------CABECALHO GUIA - OBRIGATORIO----------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  
          RIGHT(REPLICATE('0',6) + CAST(CONV.REGISTROANS AS VARCHAR(6)),6)  AS cabecalhoGuiaRegistroANS,--Registro ANS  |  String  |  6  |    |  Registro da operadora de plano privado de assist�ncia � sa�de na Ag�ncia Nacional de Sa�de Suplementar (ANS)  |  Obrigat�rio.			
		  (CASE WHEN ISNULL(CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR,'GPRE') = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
		  	    WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
				WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
				WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
				WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
				WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
		   END)																AS cabecalhoGuiaNumeroGuiaPrestador,--N�mero da guia no prestador  |  String  |  20  |    |  N�mero que identifica a guia no prestador de servi�os.  |  "Obrigat�rio. � facultada �s operadoras e prestadores de servi�os a utiliza��o de c�digo de barras, impressos imediatamente abaixo da numera��o. O c�digo de barras deve seguir o padr�o CODE 39 de alta densidade."
		  (CASE WHEN RDT.GUIAPRESTADOR <> RDT.GUIAPRINCIPAL THEN RDT.GUIAPRINCIPAL ELSE NULL END) AS cabecalhoGuiaGuiaPrincipal,--N�mero da guia principal  |  String  |  20  |    |  N�mero da guia principal  |  Condicionado. Deve ser preenchido com o n�mero da guia principal no prestador quando se tratar de solicita��o de SADT em paciente internado ou na cobran�a de honor�rio m�dico em separado para procedimentos ambulatoriais.
		  ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------BENEFICIARIO - OBRIGATORIO------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  					  
          --LEFT(REPLICATE('0',3) + RIGHT(ISNULL(ATEND.UNIDADE,0),3),3) + LEFT(REPLICATE('0',17)+RIGHT(ISNULL(ATEND.CARTEIRINHA,0),17),17) AS numeroCarteira, --N�mero da carteira do benefici�rio  |  String  |  20  |    |  N�mero da carteira do benefici�rio na operadora  |  Obrigat�rio.
          CAST(ISNULL(ATEND.UNIDADE, '') AS VARCHAR(5))
          + CAST(ISNULL(ATEND.CARTEIRINHA, '') AS VARCHAR(20))              AS dadosBeneficiarioNumeroCarteira,--N�mero da carteira do benefici�rio  |  String  |  20  |    |  N�mero da carteira do benefici�rio na operadora  |  Obrigat�rio.
          PRON.NOME                                                         AS dadosBeneficiarioNomeBeneficiario,--Nome do benefici�rio  |  String  |  70  |    |  Nome do benefici�rio  |  Obrigat�rio.
          NULL                                                              AS dadosBeneficiarioIdentificadorBeneficiario,--Identificador biom�trico do benefici�rio  |  Bin�rio  |    |    |  C�digo biom�trico de identifica��o do benefici�rio  |  Opcional.
          PRON.CARTAOSUS                                                    AS dadosBeneficiarioNumeroCNS,--Cart�o Nacional de Sa�de  |  String  |  15  |    |  N�mero do Cart�o Nacional de Sa�de do benefici�rio  |  Condicionado. Deve ser preenchido caso o benefici�rio possua o n�mero do Cart�o Nacional de Sa�de.
          ( CASE
              WHEN LEFT(PRON.NOME, 2) = 'RN' THEN 'S'
              ELSE 'N'
            END )                                                           AS dadosBeneficiarioAtendimentoRN,--Indicador de atendimento ao rec�m-nato  |  String  |  1  |    |  Indica se o paciente � um rec�m-nato que est� sendo atendido no contrato do respons�vel, nos termos do Art. 12, inciso III, al�nea a, da Lei 9.656, de 03 de junho de 1998.  |  Obrigat�rio.  Deve ser informado "S" - sim - caso o atendimento seja do rec�m-nato e o benefici�rio seja o respons�vel e "N" - n�o - quando o atendimento for do pr�prio benefici�rio.			
		  ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------DADOS SOLICITANTE - OBRIGATORIO--------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  					  			
		  PRES.TIPO_PRESTADOR_SOLICITANTE                                   AS dadosSolicitanteContratadoSolicitanteItemTipo,--Campo criado para atender a situa��o do c�digo do Prestador solicitante na operadora			
		  DBO.FN_SONUMERICO(PRES.CODIGO_PRESTADOR_SOLICITANTE)              AS dadosSolicitanteContratadoSolicitanteItem,--C�digo do contratado solicitante na operadora  |  String  |  14  |    |  C�digo identificador do prestador solicitante junto a operadora, conforme contrato estabelecido.  |  Obrigat�rio. Quando n�o informado pelo solicitante, o executante deve preencher  com o campo com ?99999999999999?, exceto se o solicitante e o executante forem o mesmo.
          PRES.NOME_PRESTADOR_SOLICITANTE                    				AS dadosSolicitanteContratadoSolicitanteNomeContratado,--Nome do contratado solicitante  |  String  |  70  |    |  Raz�o Social, nome fantasia ou nome do prestador contratado da operadora que est� solicitando o procedimento  |  Obrigat�rio.
          --PROFISSIONAL SOLICITANTE - OBRIGATORIO
          MSOL.NOME                                                         AS dadosSolicitanteProfissionalSolicitanteNomeProfissional,--Nome do profissional solicitante  |  String  |  70  |    |  Nome do profissional que est� solicitando o procedimento.  |  Condicionado. Deve ser preenchido quando o prestador contratado referido no campo Nome do Contratado for pessoa jur�dica.
          ISNULL(T26.CODIGO,10)                                             AS dadosSolicitanteProfissionalSolicitanteConselhoProfissional,--Conselho profissional do solicitante  |  String  |  2  |    |  C�digo do conselho profissional do solicitante do procedimento ou item assistencial,  conforme tabela de dom�nio n� 26.  |  Obrigat�rio.
          MSOL.CRM                                                          AS dadosSolicitanteProfissionalSolicitanteNumeroConselhoProfissional,--N�mero do solicitante no conselho profissional  |  String  |  15  |    |  N�mero de registro do profissional solicitante no respectivo Conselho Profissional.  |  Obrigat�rio.
          UFSOL.CODIGO_TUSS                                                 AS dadosSolicitanteProfissionalSolicitanteUF,--UF do conselho do profissional solicitante  |  String  |  2  |    |  Sigla da Unidade Federativa do Conselho Profissional do solicitante do procedimento ou item assistencial, conforme tabela de dom�nio n� 59.  |  Obrigat�rio.
          ISNULL(T24.CODIGO,'999999')                                       AS dadosSolicitanteProfissionalSolicitanteCBOS,--C�digo na Classifica��o Brasileira de Ocupa��es do solicitante  |  String  |  6  |    |  C�digo na Classifica��o Brasileira de Ocupa��es do profissional solicitante do procedimento ou item assistencial, conforme tabela de dom�nio n� 24.  |  Obrigat�rio.
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------DADOS DA SOLICITACAO - OBRIGATORIO----------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  					  			          		  
          T23.CODIGO                                                        AS dadosSolicitacaoCaraterAtendimento,--Car�ter do atendimento  |  String  |  1  | |  C�digo do car�ter do atendimento, conforme tabela de dom�nio n� 23.  |  Obrigat�rio.
          ISNULL(DG.DATASOLICITACAO, ISNULL(DG.DATA, ATEND.DATAINTERNACAO)) AS dadosSolicitacaoDataSolicitacao,--Data da solicita��o  |  Date  |  8  |  DDMMAAAA  |  Data em que o profissional solicitando os procedimentos ou itens assistenciais.  |  Condicionado. Deve ser preenchido em caso de autoriza��o pela operadora.
          NULL                                                              AS dadosSolicitacaoIndicacaoClinica,--Indica��o cl�nica  |  String  |  500  |    |  Indica��o cl�nica do profissional embasando a solicita��o.  |  Condicionado. Deve ser preenchido pelo solicitante no caso de pequena cirurgia, terapia, alta complexidade e procedimentos com diretriz de utiliza��o.
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------DADOS DO EXECUTANTE - OBRIGATORIO-----------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  					  			          
		  PREE.TIPO_PRESTADOR_EXECUTANTE                                    AS dadosExecutanteContratadoExecutanteItemTipo,--Campo criado para atender a situa��o do c�digo do Prestador executante na operadora							
		  DBO.FN_SONUMERICO(PREE.CODIGO_PRESTADOR_EXECUTANTE)               AS dadosExecutanteContratadoExecutanteItem,--C�digo do contratado executante na operadora  |  String  |  14  |    |  C�digo identificador do prestador contratado executante junto a operadora, conforme contrato estabelecido.  |  Obrigat�rio.
          PREE.NOME_PRESTADOR_EXECUTANTE			  					    AS dadosExecutanteContratadoExecutanteNomeContratado,--Nome do contratado executante  |  String  |  70  |    |  Raz�o Social, nome fantasia ou nome do prestador contratado da operadora que executou o procedimento.  |  Obrigat�rio.
          PAR.CNES                                                          AS dadosExecutanteCNES,--C�digo no Cadastro Nacional de Estabelecimentos de Sa�de do executante  |  String  |  7  |    |  C�digo do prestador executante no Cadastro Nacional de Estabelecimentos de Sa�de do Minist�rio da Sa�de (CNES/MS)  |  Obrigat�rio. Caso o prestador ainda n�o possua o c�digo do CNES preencher o campo com 9999999.
		  ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------GERAL---------------------------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------
          NULL                                                              AS Observacao--Observa��o / Justificativa  |  String  |  500  |    |  Campo utilizado para adicionar quaisquer observa��es sobre o atendimento ou justificativas que julgue necess�rio  |  Opcional.
		  FROM   V_RECUPERADADOSTISS AS RDT
                 INNER JOIN EXTERNO AS ATEND WITH (READPAST)
                         ON ATEND.REGISTRO = RDT.REGISTRO
                            AND RDT.TIPOREGISTRO = 3
                            AND ISNULL(ATEND.CANCELADO, 0) = 0
                            AND ATEND.REGISTRO IN ( @REGISTRO )					
							AND  (RDT.GUIAINTERNA = @GUIAINTERNA OR @GUIAINTERNA IS NULL)
							
                 INNER JOIN FICHAS AS PRON WITH (READPAST)
                         ON PRON.FICHA = ATEND.FICHA

				 INNER JOIN EXTERNOPROCEDIMENTO MOVIM
						 ON MOVIM.REGISTRO = RDT.REGISTRO
						 AND ISNULL(MOVIM.GUIAINTERNA,0) = RDT.GUIAINTERNA
						 AND MOVIM.AUTORIZACAOPROCEDIMENTO IS NULL
						 
                 CROSS JOIN PARAMETRO AS PAR WITH (READPAST)
				 		 
                 INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                         ON ATEND.CONVENIO = CONV.CONVENIO
	 
                 LEFT JOIN DADOSGUIA AS DG WITH (READPAST)
                        ON DG.REGISTRO = RDT.REGISTRO
                           AND DG.TIPOREGISTRO = RDT.TIPOREGISTRO
						   
				--SOLICITANTE
                 LEFT JOIN MEDICOS AS MSOL WITH (READPAST)
                        ON MSOL.MEDICO = MOVIM.MEDICOSOL
						
				 LEFT JOIN V_TISS_PRESTADOR_SOLICITANTE PRES
						ON PRES.CONVENIO = ATEND.CONVENIO
					   AND PRES.MEDICO = ISNULL(MOVIM.MEDICOSOL,ISNULL(PAR.MEDICOHOSPITAL,0))
					   AND PRES.TIPOREGISTRO = 4
						
                 LEFT JOIN UF AS UFSOL WITH (READPAST)
                        ON UFSOL.ID_UF = MSOL.UFCRM				
						   
                 LEFT JOIN ESPMEDICA ESPSOL WITH (READPAST)
                        ON ESPSOL.ESPECMEDICA = MSOL.ESPECMEDICA						
												
								 LEFT JOIN TUSS_TAB24 AS T24
								    		ON T24.CODIGO = ISNULL(ESPSOL.CBOS030200, ESPSOL.CBO2002)

								 LEFT JOIN TUSS_TAB26 AS T26
												ON T26.CODIGO = (CASE WHEN ISNULL(MSOL.CONSELHOPROFISSIONAL,0) IN(0,7,11,12) THEN 10
																							WHEN MSOL.CONSELHOPROFISSIONAL >= 8 AND MSOL.CONSELHOPROFISSIONAL <= 10 THEN MSOL.CONSELHOPROFISSIONAL -1
																							ELSE MSOL.CONSELHOPROFISSIONAL 
																				END)                   
				 --EXECUTANTE
                 LEFT JOIN MEDICOS AS MEXEC WITH (READPAST)
                        ON MEXEC.MEDICO = NULL
				 LEFT JOIN V_TISS_PRESTADOR_EXECUTANTE PREE
											ON PREE.CONVENIO = ATEND.CONVENIO
											AND PREE.MEDICO = ISNULL(MEXEC.MEDICO,ISNULL(PAR.MEDICOHOSPITAL,0))
											AND PREE.TIPOREGISTRO = 4			
						   
                 LEFT JOIN TUSS_TAB23 AS T23 WITH (READPAST) --CARATER DO ATENDIMENTO [1-ELETIVO, 2-URGENCIA/Emergencia]
                        ON T23.CODIGO = 1
						
END
IF @TIPOREGISTRO = 'AMBULATORIAL' OR  @TIPOREGISTRO = 'URGENCIA'
BEGIN
          SELECT DISTINCT 
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------CHAVES--------------------------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------
          @TIPOREGISTRO                                                     AS TIPO_REGISTRO,
          ATEND.REGISTRO                                                    AS REGISTRO,
		  ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------CABECALHO GUIA - OBRIGATORIO----------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  
          RIGHT(REPLICATE('0',6) + CAST(CONV.REGISTROANS AS VARCHAR(6)),6)  AS cabecalhoGuiaRegistroANS,--Registro ANS  |  String  |  6  |    |  Registro da operadora de plano privado de assist�ncia � sa�de na Ag�ncia Nacional de Sa�de Suplementar (ANS)  |  Obrigat�rio.			
		  (CASE WHEN ISNULL(CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR,'GPRE') = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
		  	    WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
				WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
				WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
				WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
				WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
		   END)																			   		    AS cabecalhoGuiaNumeroGuiaPrestador,--N�mero da guia no prestador  |  String  |  20  |    |  N�mero que identifica a guia no prestador de servi�os.  |  "Obrigat�rio. � facultada �s operadoras e prestadores de servi�os a utiliza��o de c�digo de barras, impressos imediatamente abaixo da numera��o. O c�digo de barras deve seguir o padr�o CODE 39 de alta densidade."
		  (CASE WHEN RDT.GUIAPRESTADOR <> RDT.GUIAPRINCIPAL THEN RDT.GUIAPRINCIPAL ELSE NULL END)	AS cabecalhoGuiaGuiaPrincipal,--N�mero da guia principal  |  String  |  20  |    |  N�mero da guia principal  |  Condicionado. Deve ser preenchido com o n�mero da guia principal no prestador quando se tratar de solicita��o de SADT em paciente internado ou na cobran�a de honor�rio m�dico em separado para procedimentos ambulatoriais.
		  ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------BENEFICIARIO - OBRIGATORIO------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  					  
          --LEFT(REPLICATE('0',3) + RIGHT(ISNULL(ATEND.UNIDADE,0),3),3) + LEFT(REPLICATE('0',17)+RIGHT(ISNULL(ATEND.CARTEIRINHA,0),17),17) AS numeroCarteira, --N�mero da carteira do benefici�rio  |  String  |  20  |    |  N�mero da carteira do benefici�rio na operadora  |  Obrigat�rio.
          CAST(ISNULL(ATEND.UNIDADE, '') AS VARCHAR(5))
          + CAST(ISNULL(ATEND.CARTEIRINHA, '') AS VARCHAR(20))              AS dadosBeneficiarioNumeroCarteira,--N�mero da carteira do benefici�rio  |  String  |  20  |    |  N�mero da carteira do benefici�rio na operadora  |  Obrigat�rio.
          PRON.NOME                                                         AS dadosBeneficiarioNomeBeneficiario,--Nome do benefici�rio  |  String  |  70  |    |  Nome do benefici�rio  |  Obrigat�rio.
          NULL                                                              AS dadosBeneficiarioIdentificadorBeneficiario,--Identificador biom�trico do benefici�rio  |  Bin�rio  |    |    |  C�digo biom�trico de identifica��o do benefici�rio  |  Opcional.
          PRON.CARTAOSUS                                                    AS dadosBeneficiarioNumeroCNS,--Cart�o Nacional de Sa�de  |  String  |  15  |    |  N�mero do Cart�o Nacional de Sa�de do benefici�rio  |  Condicionado. Deve ser preenchido caso o benefici�rio possua o n�mero do Cart�o Nacional de Sa�de.
          ( CASE
              WHEN LEFT(PRON.NOME, 2) = 'RN' THEN 'S'
              ELSE 'N'
            END )                                                           AS dadosBeneficiarioAtendimentoRN,--Indicador de atendimento ao rec�m-nato  |  String  |  1  |    |  Indica se o paciente � um rec�m-nato que est� sendo atendido no contrato do respons�vel, nos termos do Art. 12, inciso III, al�nea a, da Lei 9.656, de 03 de junho de 1998.  |  Obrigat�rio.  Deve ser informado "S" - sim - caso o atendimento seja do rec�m-nato e o benefici�rio seja o respons�vel e "N" - n�o - quando o atendimento for do pr�prio benefici�rio.			
		  ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------DADOS SOLICITANTE - OBRIGATORIO--------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  					  			
		  PRES.TIPO_PRESTADOR_SOLICITANTE                                   AS dadosSolicitanteContratadoSolicitanteItemTipo,--Campo criado para atender a situa��o do c�digo do Prestador solicitante na operadora			
		  DBO.FN_SONUMERICO(PRES.CODIGO_PRESTADOR_SOLICITANTE)              AS dadosSolicitanteContratadoSolicitanteItem,--C�digo do contratado solicitante na operadora  |  String  |  14  |    |  C�digo identificador do prestador solicitante junto a operadora, conforme contrato estabelecido.  |  Obrigat�rio. Quando n�o informado pelo solicitante, o executante deve preencher  com o campo com ?99999999999999?, exceto se o solicitante e o executante forem o mesmo.
          PRES.NOME_PRESTADOR_SOLICITANTE                    				AS dadosSolicitanteContratadoSolicitanteNomeContratado,--Nome do contratado solicitante  |  String  |  70  |    |  Raz�o Social, nome fantasia ou nome do prestador contratado da operadora que est� solicitando o procedimento  |  Obrigat�rio.
          --PROFISSIONAL SOLICITANTE - OBRIGATORIO
          MSOL.NOME                                                         AS dadosSolicitanteProfissionalSolicitanteNomeProfissional,--Nome do profissional solicitante  |  String  |  70  |    |  Nome do profissional que est� solicitando o procedimento.  |  Condicionado. Deve ser preenchido quando o prestador contratado referido no campo Nome do Contratado for pessoa jur�dica.
          ISNULL(T26.CODIGO,10)                                             AS dadosSolicitanteProfissionalSolicitanteConselhoProfissional,--Conselho profissional do solicitante  |  String  |  2  |    |  C�digo do conselho profissional do solicitante do procedimento ou item assistencial,  conforme tabela de dom�nio n� 26.  |  Obrigat�rio.
          MSOL.CRM                                                          AS dadosSolicitanteProfissionalSolicitanteNumeroConselhoProfissional,--N�mero do solicitante no conselho profissional  |  String  |  15  |    |  N�mero de registro do profissional solicitante no respectivo Conselho Profissional.  |  Obrigat�rio.
          UFSOL.CODIGO_TUSS                                                 AS dadosSolicitanteProfissionalSolicitanteUF,--UF do conselho do profissional solicitante  |  String  |  2  |    |  Sigla da Unidade Federativa do Conselho Profissional do solicitante do procedimento ou item assistencial, conforme tabela de dom�nio n� 59.  |  Obrigat�rio.
          ISNULL(T24.CODIGO,'999999')                                       AS dadosSolicitanteProfissionalSolicitanteCBOS,--C�digo na Classifica��o Brasileira de Ocupa��es do solicitante  |  String  |  6  |    |  C�digo na Classifica��o Brasileira de Ocupa��es do profissional solicitante do procedimento ou item assistencial, conforme tabela de dom�nio n� 24.  |  Obrigat�rio.
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------DADOS DA SOLICITACAO - OBRIGATORIO----------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  					  			          		  
          T23.CODIGO                                                        AS dadosSolicitacaoCaraterAtendimento,--Car�ter do atendimento  |  String  |  1  | |  C�digo do car�ter do atendimento, conforme tabela de dom�nio n� 23.  |  Obrigat�rio.
          ISNULL(DG.DATASOLICITACAO, ISNULL(DG.DATA, ATEND.DATAINTERNACAO)) AS dadosSolicitacaoDataSolicitacao,--Data da solicita��o  |  Date  |  8  |  DDMMAAAA  |  Data em que o profissional solicitando os procedimentos ou itens assistenciais.  |  Condicionado. Deve ser preenchido em caso de autoriza��o pela operadora.
          NULL                                                              AS dadosSolicitacaoIndicacaoClinica,--Indica��o cl�nica  |  String  |  500  |    |  Indica��o cl�nica do profissional embasando a solicita��o.  |  Condicionado. Deve ser preenchido pelo solicitante no caso de pequena cirurgia, terapia, alta complexidade e procedimentos com diretriz de utiliza��o.
		  ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------DADOS DO EXECUTANTE - OBRIGATORIO-----------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  					  			          
		  PREE.TIPO_PRESTADOR_EXECUTANTE                                    AS dadosExecutanteContratadoExecutanteItemTipo,--Campo criado para atender a situa��o do c�digo do Prestador executante na operadora							
		  DBO.FN_SONUMERICO(PREE.CODIGO_PRESTADOR_EXECUTANTE)               AS dadosExecutanteContratadoExecutanteItem,--C�digo do contratado executante na operadora  |  String  |  14  |    |  C�digo identificador do prestador contratado executante junto a operadora, conforme contrato estabelecido.  |  Obrigat�rio.
          PREE.NOME_PRESTADOR_EXECUTANTE			  					    AS dadosExecutanteContratadoExecutanteNomeContratado,--Nome do contratado executante  |  String  |  70  |    |  Raz�o Social, nome fantasia ou nome do prestador contratado da operadora que executou o procedimento.  |  Obrigat�rio.
          PAR.CNES                                                          AS dadosExecutanteCNES,--C�digo no Cadastro Nacional de Estabelecimentos de Sa�de do executante  |  String  |  7  |    |  C�digo do prestador executante no Cadastro Nacional de Estabelecimentos de Sa�de do Minist�rio da Sa�de (CNES/MS)  |  Obrigat�rio. Caso o prestador ainda n�o possua o c�digo do CNES preencher o campo com 9999999.
		  ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------GERAL---------------------------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------
          NULL                                                              AS Observacao--Observa��o / Justificativa  |  String  |  500  |    |  Campo utilizado para adicionar quaisquer observa��es sobre o atendimento ou justificativas que julgue necess�rio  |  Opcional.
		  FROM   V_RECUPERADADOSTISS AS RDT
                 INNER JOIN AMBULATORIAL AS ATEND WITH (READPAST)
                         ON ATEND.REGISTRO = RDT.REGISTRO
                            AND RDT.TIPOREGISTRO = 1
                            AND ISNULL(ATEND.CANCELADO, 0) = 0
                            AND ATEND.REGISTRO IN ( @REGISTRO )					
							AND  (RDT.GUIAINTERNA = @GUIAINTERNA OR @GUIAINTERNA IS NULL)
							
                 INNER JOIN FICHAS AS PRON WITH (READPAST)
                         ON PRON.FICHA = ATEND.FICHA
						 
                 INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                         ON ATEND.CONVENIO = CONV.CONVENIO
	 
                 LEFT JOIN DADOSGUIA AS DG WITH (READPAST)
                        ON DG.REGISTRO = RDT.REGISTRO
                           AND DG.TIPOREGISTRO = RDT.TIPOREGISTRO

				 INNER JOIN AMBULATORIALPROCEDIMENTO MOVIM
						 ON MOVIM.REGISTRO = RDT.REGISTRO
						 AND ISNULL(MOVIM.GUIAINTERNA,0) = RDT.GUIAINTERNA
						 AND MOVIM.AUTORIZACAOPROCEDIMENTO IS NULL

                 CROSS JOIN PARAMETRO AS PAR WITH (READPAST)
						  
				 --SOLICITANTE
                 LEFT JOIN MEDICOS AS MSOL WITH (READPAST)
                        ON MSOL.MEDICO = MOVIM.MEDICOSOL
				 LEFT JOIN V_TISS_PRESTADOR_SOLICITANTE PRES
						ON PRES.CONVENIO = ATEND.CONVENIO
					   AND PRES.MEDICO = ISNULL(MOVIM.MEDICOSOL,ISNULL(PAR.MEDICOHOSPITAL,0))
					   AND PRES.TIPOREGISTRO = ( CASE
                                                 WHEN ATEND.AMBUPA = 1 THEN 2
                                                 ELSE 3
                                                END )
						
                 LEFT JOIN UF AS UFSOL WITH (READPAST)
                        ON UFSOL.ID_UF = MSOL.UFCRM				
						   
                 LEFT JOIN ESPMEDICA ESPSOL WITH (READPAST)
                        ON ESPSOL.ESPECMEDICA = MSOL.ESPECMEDICA						
												
								 LEFT JOIN TUSS_TAB24 AS T24
								    		ON T24.CODIGO = ESPSOL.CBOS030200

								 LEFT JOIN TUSS_TAB26 AS T26
												ON T26.CODIGO = (CASE WHEN ISNULL(MSOL.CONSELHOPROFISSIONAL,0) IN(0,7,11,12) THEN 10
																							WHEN MSOL.CONSELHOPROFISSIONAL >= 8 AND MSOL.CONSELHOPROFISSIONAL <= 10 THEN MSOL.CONSELHOPROFISSIONAL -1
																							ELSE MSOL.CONSELHOPROFISSIONAL 
																				END)                   
                 --EXECUTANTE
                 LEFT JOIN MEDICOS AS MEXEC WITH (READPAST)
                        ON MEXEC.MEDICO = NULL
				
				LEFT JOIN V_TISS_PRESTADOR_EXECUTANTE PREE
											ON PREE.CONVENIO = ATEND.CONVENIO
											AND PREE.MEDICO = ISNULL(MEXEC.MEDICO,ISNULL(PAR.MEDICOHOSPITAL,0))
											AND PREE.TIPOREGISTRO = ( CASE
                                                         WHEN ATEND.AMBUPA = 1 THEN 2
                                                         ELSE 3
                                                       END )						
                 LEFT JOIN UF AS UFEXEC WITH (READPAST)
                        ON UFEXEC.ID_UF = MEXEC.UFCRM
						   
                 LEFT JOIN TUSS_TAB23 AS T23 WITH (READPAST) --CARATER DO ATENDIMENTO [1-ELETIVO, 2-URGENCIA/Emergencia]
                        ON T23.CODIGO = (CASE WHEN ISNULL(ATEND.URGENCIA,0) = 1 THEN 2 ELSE ATEND.AMBUPA END)
						
END
IF @TIPOREGISTRO = 'INTERNO'
BEGIN
          SELECT DISTINCT 
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------CHAVES--------------------------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------
          @TIPOREGISTRO                                                     AS TIPO_REGISTRO,
          ATEND.REGISTRO                                                    AS REGISTRO,
		  RIGHT(REPLICATE('0',6) + CAST(CONV.REGISTROANS AS VARCHAR(6)),6)  AS registroANS,--Registro ANS  |  String  |  6  |    |  Registro da operadora de plano privado de assist�ncia � sa�de na Ag�ncia Nacional de Sa�de Suplementar (ANS)  |  Obrigat�rio.			
		  (CASE WHEN ISNULL(CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR,'GPRE') = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
		  	    WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
				WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
				WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
				WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
				WHEN CONV.TISS_SPSADT_TAG_NUMEROGUIAPRESTADOR = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
		   END)																AS numeroGuiaPrestador,--N�mero da guia no prestador  |  String  |  20  |    |  N�mero que identifica a guia no prestador de servi�os.  |  "Obrigat�rio. � facultada �s operadoras e prestadores de servi�os a utiliza��o de c�digo de barras, impressos imediatamente abaixo da numera��o. O c�digo de barras deve seguir o padr�o CODE 39 de alta densidade."
		  (CASE WHEN RDT.GUIAPRESTADOR <> RDT.GUIAPRINCIPAL THEN RDT.GUIAPRINCIPAL ELSE NULL END)	AS cabecalhoGuiaGuiaPrincipal,--N�mero da guia principal  |  String  |  20  |    |  N�mero da guia principal  |  Condicionado. Deve ser preenchido com o n�mero da guia principal no prestador quando se tratar de solicita��o de SADT em paciente internado ou na cobran�a de honor�rio m�dico em separado para procedimentos ambulatoriais.
		  ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------BENEFICIARIO - OBRIGATORIO------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  					  
          --LEFT(REPLICATE('0',3) + RIGHT(ISNULL(ATEND.UNIDADE,0),3),3) + LEFT(REPLICATE('0',17)+RIGHT(ISNULL(ATEND.CARTEIRINHA,0),17),17) AS numeroCarteira, --N�mero da carteira do benefici�rio  |  String  |  20  |    |  N�mero da carteira do benefici�rio na operadora  |  Obrigat�rio.
          CAST(ISNULL(ATEND.UNIDADE, '') AS VARCHAR(5))
          + CAST(ISNULL(ATEND.CARTEIRINHA, '') AS VARCHAR(20))              AS dadosBeneficiarioNumeroCarteira,--N�mero da carteira do benefici�rio  |  String  |  20  |    |  N�mero da carteira do benefici�rio na operadora  |  Obrigat�rio.
          PRON.NOME                                                         AS dadosBeneficiarioNomeBeneficiario,--Nome do benefici�rio  |  String  |  70  |    |  Nome do benefici�rio  |  Obrigat�rio.
          NULL                                                              AS dadosBeneficiarioIdentificadorBeneficiario,--Identificador biom�trico do benefici�rio  |  Bin�rio  |    |    |  C�digo biom�trico de identifica��o do benefici�rio  |  Opcional.
          PRON.CARTAOSUS                                                    AS dadosBeneficiarioNumeroCNS,--Cart�o Nacional de Sa�de  |  String  |  15  |    |  N�mero do Cart�o Nacional de Sa�de do benefici�rio  |  Condicionado. Deve ser preenchido caso o benefici�rio possua o n�mero do Cart�o Nacional de Sa�de.
          ( CASE
              WHEN LEFT(PRON.NOME, 2) = 'RN' THEN 'S'
              ELSE 'N'
            END )                                                           AS dadosBeneficiarioAtendimentoRN,--Indicador de atendimento ao rec�m-nato  |  String  |  1  |    |  Indica se o paciente � um rec�m-nato que est� sendo atendido no contrato do respons�vel, nos termos do Art. 12, inciso III, al�nea a, da Lei 9.656, de 03 de junho de 1998.  |  Obrigat�rio.  Deve ser informado "S" - sim - caso o atendimento seja do rec�m-nato e o benefici�rio seja o respons�vel e "N" - n�o - quando o atendimento for do pr�prio benefici�rio.			
		  ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------DADOS SOLICITANTE - OBRIGATORIO--------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  					  			
		  PRES.TIPO_PRESTADOR_SOLICITANTE                                   AS dadosSolicitanteContratadoSolicitanteItemTipo,--Campo criado para atender a situa��o do c�digo do Prestador solicitante na operadora			
		  DBO.FN_SONUMERICO(PRES.CODIGO_PRESTADOR_SOLICITANTE)              AS dadosSolicitanteContratadoSolicitanteItem,--C�digo do contratado solicitante na operadora  |  String  |  14  |    |  C�digo identificador do prestador solicitante junto a operadora, conforme contrato estabelecido.  |  Obrigat�rio. Quando n�o informado pelo solicitante, o executante deve preencher  com o campo com ?99999999999999?, exceto se o solicitante e o executante forem o mesmo.
          PRES.NOME_PRESTADOR_SOLICITANTE                    				AS dadosSolicitanteContratadoSolicitanteNomeContratado,--Nome do contratado solicitante  |  String  |  70  |    |  Raz�o Social, nome fantasia ou nome do prestador contratado da operadora que est� solicitando o procedimento  |  Obrigat�rio.
          --PROFISSIONAL SOLICITANTE - OBRIGATORIO
          MSOL.NOME                                                         AS dadosSolicitanteProfissionalSolicitanteNomeProfissional,--Nome do profissional solicitante  |  String  |  70  |    |  Nome do profissional que est� solicitando o procedimento.  |  Condicionado. Deve ser preenchido quando o prestador contratado referido no campo Nome do Contratado for pessoa jur�dica.
          ISNULL(T26.CODIGO,10)                                             AS dadosSolicitanteProfissionalSolicitanteConselhoProfissional,--Conselho profissional do solicitante  |  String  |  2  |    |  C�digo do conselho profissional do solicitante do procedimento ou item assistencial,  conforme tabela de dom�nio n� 26.  |  Obrigat�rio.
          MSOL.CRM                                                          AS dadosSolicitanteProfissionalSolicitanteNumeroConselhoProfissional,--N�mero do solicitante no conselho profissional  |  String  |  15  |    |  N�mero de registro do profissional solicitante no respectivo Conselho Profissional.  |  Obrigat�rio.
          UFSOL.CODIGO_TUSS                                                 AS dadosSolicitanteProfissionalSolicitanteUF,--UF do conselho do profissional solicitante  |  String  |  2  |    |  Sigla da Unidade Federativa do Conselho Profissional do solicitante do procedimento ou item assistencial, conforme tabela de dom�nio n� 59.  |  Obrigat�rio.
          ISNULL(T24.CODIGO,'999999')                                       AS dadosSolicitanteProfissionalSolicitanteCBOS,--C�digo na Classifica��o Brasileira de Ocupa��es do solicitante  |  String  |  6  |    |  C�digo na Classifica��o Brasileira de Ocupa��es do profissional solicitante do procedimento ou item assistencial, conforme tabela de dom�nio n� 24.  |  Obrigat�rio.
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------DADOS DA SOLICITACAO - OBRIGATORIO----------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  					  			          		  
          T36.CODIGO                                                        AS dadosAtendimentoIndicacaoAcidente,--Indica��o de acidente ou doen�a relacionada  |  String  |  1  |    |  Indica se o atendimento � devido a acidente ocorrido com o benefici�rio ou doen�a relacionada, conforme tabela de dom�nio n� 36.  |  Obrigat�rio.
          NULL                                                              AS dadosSolicitacaoIndicacaoClinica,--Indica��o cl�nica  |  String  |  500  |    |  Indica��o cl�nica do profissional embasando a solicita��o.  |  Condicionado. Deve ser preenchido pelo solicitante no caso de pequena cirurgia, terapia, alta complexidade e procedimentos com diretriz de utiliza��o.
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------DADOS DO EXECUTANTE - OBRIGATORIO-----------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  					  			          
		  DBO.FN_SONUMERICO(PREE.CODIGO_PRESTADOR_EXECUTANTE)			AS dadosHospitalSolicitadoCodigoIndicadonaOperadora,
		  ISNULL(DG.DATASOLICITACAO, ISNULL(DG.DATA, ATEND.DATAINTERNACAO)) AS dadosHospitalSolicitadodataSugeridaInternacao,--Data da solicita��o  |  Date  |  8  |  DDMMAAAA  |  Data em que o profissional solicitando os procedimentos ou itens assistenciais.  |  Condicionado. Deve ser preenchido em caso de autoriza��o pela operadora.
		  PREE.NOME_PRESTADOR_EXECUTANTE							    AS dadosHospitalSolicitadoNomeContratadoIndicado,
		 
          T23.CODIGO                                           AS dadosInternacaoCaraterAtendimento,
          T57.CODIGO                                           AS dadosInternacaTipoInternacao,
          T41.CODIGO                                           AS dadosInternacaoRegimeInternacao,
		  '' AS indicacaoClinica,
          '' AS qtDiariasSolicitadas,
          '' AS indicadorOPME,
          '' AS indicadorQuimio,
		  ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------GERAL---------------------------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------
		  ISNULL(DG.DATASOLICITACAO, ISNULL(DG.DATA, ATEND.DATAINTERNACAO)) AS dadosSolicitacaoDataSolicitacao,
          NULL                                                              AS Observacao--Observa��o / Justificativa  |  String  |  500  |    |  Campo utilizado para adicionar quaisquer observa��es sobre o atendimento ou justificativas que julgue necess�rio  |  Opcional.
		  FROM   V_RECUPERADADOSTISS AS RDT
                 INNER JOIN INTERNO AS ATEND WITH (READPAST)
                         ON ATEND.REGISTRO = RDT.REGISTRO
                            AND RDT.TIPOREGISTRO = 1
                            AND ISNULL(ATEND.CANCELADO, 0) = 0
                            AND ATEND.REGISTRO IN ( @REGISTRO )					
							AND  (RDT.GUIAINTERNA = @GUIAINTERNA OR @GUIAINTERNA IS NULL)
							
                 INNER JOIN FICHAS AS PRON WITH (READPAST)
                         ON PRON.FICHA = ATEND.FICHA

				 INNER JOIN INTERNOPROCEDIMENTO MOVIM
						 ON MOVIM.REGISTRO = RDT.REGISTRO
						 AND ISNULL(MOVIM.GUIAINTERNA,0) = RDT.GUIAINTERNA
						 AND MOVIM.AUTORIZACAOPROCEDIMENTO IS NULL

                 CROSS JOIN PARAMETRO AS PAR WITH (READPAST)	
				 	 
                 INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                         ON ATEND.CONVENIO = CONV.CONVENIO
	 
                 LEFT JOIN DADOSGUIA AS DG WITH (READPAST)
                        ON DG.REGISTRO = RDT.REGISTRO
                           AND DG.TIPOREGISTRO = RDT.TIPOREGISTRO
						  
				--SOLICITANTE
                 LEFT JOIN MEDICOS AS MSOL WITH (READPAST)
                        ON MSOL.MEDICO = MOVIM.MEDICOSOL
						
				 LEFT JOIN V_TISS_PRESTADOR_SOLICITANTE PRES
						ON PRES.CONVENIO = ATEND.CONVENIO
					   AND PRES.MEDICO = ISNULL(MOVIM.MEDICOSOL,ISNULL(PAR.MEDICOHOSPITAL,0))
					   AND PRES.TIPOREGISTRO = 1
							
                 LEFT JOIN UF AS UFSOL WITH (READPAST)
                        ON UFSOL.ID_UF = MSOL.UFCRM				
							
                 LEFT JOIN ESPMEDICA ESPSOL WITH (READPAST)
                        ON ESPSOL.ESPECMEDICA = MSOL.ESPECMEDICA						
												
								 LEFT JOIN TUSS_TAB24 AS T24
								    		ON T24.CODIGO = ESPSOL.CBOS030200

								 LEFT JOIN TUSS_TAB26 AS T26
												ON T26.CODIGO = (CASE WHEN ISNULL(MSOL.CONSELHOPROFISSIONAL,0) IN(0,7,11,12) THEN 10
																							WHEN MSOL.CONSELHOPROFISSIONAL >= 8 AND MSOL.CONSELHOPROFISSIONAL <= 10 THEN MSOL.CONSELHOPROFISSIONAL -1
																							ELSE MSOL.CONSELHOPROFISSIONAL 
																				END)                   
				 --EXECUTANTE
                 LEFT JOIN MEDICOS AS MEXEC WITH (READPAST)
                        ON MEXEC.MEDICO = NULL
				 LEFT JOIN V_TISS_PRESTADOR_EXECUTANTE PREE
											ON PREE.CONVENIO = ATEND.CONVENIO
											AND PREE.MEDICO = ISNULL(MEXEC.MEDICO,ISNULL(PAR.MEDICOHOSPITAL,0))
											AND PREE.TIPOREGISTRO = 1		
						   
                 LEFT JOIN TUSS_TAB23 AS T23 WITH (READPAST) --CARATER DO ATENDIMENTO [1-ELETIVO, 2-URGENCIA/Emergencia]
                        ON T23.CODIGO = 1
						
                 LEFT JOIN TUSS_TAB36 AS T36 WITH (READPAST) --INDICACAO DE ACIDENTE
                        ON T36.CODIGO = ISNULL(ATEND.INDICACAOACIDENTE, 9)
						
                 LEFT JOIN TUSS_TAB50 AS T50 WITH (READPAST) --TIPO DE ATENDIMENTO [5-Exame Ambulatorial, 4-Consulta, 3-Outras Terapias]
                        ON T50.CODIGO = (CASE WHEN ISNULL(RDT.TIPOTRATAMENTO,0) = 0 THEN 3 ELSE RDT.TIPOTRATAMENTO END)
						
					
				LEFT JOIN TUSS_TAB57 AS T57 WITH (READPAST) --analisar 
                        ON T57.CODIGO = 1
					
				LEFT JOIN TUSS_TAB41 AS T41 WITH (READPAST) --analisar 
                        ON T41.CODIGO = 1				 
END
go

