
create proc spx_del_primary_key 
@schema nvarchar(max) = 'dbo',
@table nvarchar(max),
@read_only bit = 1
as
begin
	declare @crlf nvarchar(6)
	declare @cmd nvarchar(max)		
	set @crlf = char(13)+char(10)
	set @cmd = ''
	select @cmd=@cmd+'alter table ' + @schema + '.' + @table + @crlf +
		   'drop constraint ' + pk.name + ';' + @crlf
	from sys.key_constraints pk
	where pk.type = 'pk'
	and pk.parent_object_id = object_id(@table,'u')
	
	print @cmd;
	if @read_only <> 1 exec(@cmd);
end
go

