 
-- =============================================
-- Author:		M2 TECNOLOGIA
-- Create date:	06/09/2017
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPDel_TUSS_TAB66	@CODIGO int,
	@INICIOVIGENCIA datetime
AS
BEGIN
	SET NOCOUNT ON
	DELETE FROM TUSS_TAB66
	WHERE
		CODIGO = @CODIGO
		AND INICIOVIGENCIA = @INICIOVIGENCIA
END
go

