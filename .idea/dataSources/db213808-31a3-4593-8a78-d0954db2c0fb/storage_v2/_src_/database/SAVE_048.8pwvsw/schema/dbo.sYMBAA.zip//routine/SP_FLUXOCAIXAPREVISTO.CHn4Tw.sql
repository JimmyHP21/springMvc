CREATE PROC [dbo].[SP_FLUXOCAIXAPREVISTO] (
   @DATAINICIAL        AS DATETIME,
   @DATAFINAL          AS DATETIME,
   @SINTETICO          AS INTEGER, 
   @PREVISTOREALIZADO  AS INTEGER,
   @IP                 AS VARCHAR(155),
   @TETOFINANCEIRO     AS INTEGER,
   @EXIBESOPAGAR       AS INTEGER
)
AS
   --SO COLOCA UM BANCO PARA NAUM FICAR LENTO POIS AKI NAUM DEPENDO DO BANCO PQ ESTA TB E TMP
   
   INSERT INTO TMPFLUXOCAIXAANS(BANCO,DIA,TIPOOPERACAO,ITEM,NOMEANALITICO,VALOR,TIPO,TIPOLANCAMENTO,IP,TIPOITEM,LANCAMENTO)    
   
   SELECT 
   0 AS BANCO,
   DAY(B.DATAVENCIMENTO) AS DIA,
   REPLICATE('0',2-LEN(LTRIM(ISNULL(J.TIPOOPERACAO,0)))) + LTRIM(ISNULL(J.TIPOOPERACAO,0)) + ' ' + ISNULL(J.NOME,'') AS TIPOOPERACAO,
   
   (CASE WHEN @SINTETICO=0 THEN 
       REPLICATE('0',2-LEN(LTRIM(ISNULL(J.TIPOOPERACAO,0)))) + LTRIM(ISNULL(J.TIPOOPERACAO,0)) + '.' + 
       REPLICATE('0',2-LEN(LTRIM(ISNULL(I.ITEM,0)))) + LTRIM(ISNULL(I.ITEM,0)) + ' '+
       I.NOME +
       (CASE WHEN @PREVISTOREALIZADO=0 THEN
           ISNULL((CASE    WHEN B.DATAVENCIMENTO<=@DATAINICIAL AND ISNULL(ISNULL(I.FORNECEDOR_VENCER,I.FORNECEDOR_VENCER),0)=1 THEN ' - A VENCER' 
                           WHEN B.DATAVENCIMENTO>@DATAFINAL AND ISNULL(ISNULL(I.FORNECEDOR_VENCIDO,I.FORNECEDOR_VENCIDO),0)=1 THEN ' - VENCIDO' 
               END),'') 
        ELSE '' END)
    ELSE
      ''
    END)
   AS ITEM,
   (CASE WHEN @SINTETICO=0 AND @PREVISTOREALIZADO=0  THEN  
       (CASE WHEN ISNULL(ISNULL(I.EXIBEANALITICO,I.EXIBEANALITICO),0)=1 THEN 
           (CASE   WHEN ISNULL(H.TIPO,0)=0 THEN E.DESCRICAO 
               WHEN ISNULL(H.TIPO,0)=1 THEN C.DESCRICAO
               WHEN ISNULL(H.TIPO,0)=2 THEN D.NOME
               WHEN ISNULL(H.TIPO,0)=4 THEN E.DESCRICAO  + ' - ' + V.DESCRICAO
           END)
       ELSE '' END) 
     ELSE
       '' 
   END) AS NOMEANALITICO,
   
   (CASE WHEN ISNULL(@EXIBESOPAGAR,0)=0 THEN (CASE WHEN  ISNULL(XZ.GRUPOMULTIPLO,0)=1 THEN ISNULL(XX.VALOR,0) + ISNULL(A.VALORJUROS,0) ELSE ISNULL(B.VALORVENCIMENTO,0) + ISNULL(A.VALORJUROS,0) END) ELSE (CASE WHEN  ISNULL(XZ.GRUPOMULTIPLO,0)=1 THEN ISNULL(XX.VALOR,0) + ISNULL(A.VALORJUROS,0) ELSE ISNULL(B.VALORVENCIMENTO,0) + ISNULL(A.VALORJUROS,0) END)- (CASE WHEN  ISNULL(XZ.GRUPOMULTIPLO,0)=1 THEN  ISNULL(XX.VALORPAGAMENTO,0) ELSE  ISNULL(F.VALORPAGAMENTO,0) END) END),
   0,1, @IP,H.TIPO,A.LANCAMENTO
   FROM FILANCAMENTO A         INNER JOIN FILANCAMENTOVENCIMENTO B ON  A.LANCAMENTO = B.LANCAMENTO
                   LEFT JOIN FORNECEDORES C ON A.CREDOR = C.FORNECEDOR AND ISNULL(A.TERCEIROS,0)=0
                   LEFT JOIN FICREDOR D     ON A.CREDOR = D.CREDOR AND ISNULL(A.TERCEIROS,0)=1
                   LEFT JOIN V_RECUPERAVALORSUBGRUPO_VENCIMENTO XX ON A.LANCAMENTO=XX.LANCAMENTO AND B.DATAVENCIMENTO=XX.DATAVENCIMENTO
                   LEFT JOIN GRUPO XZ ON A.GRUPO=XZ.GRUPO
                   LEFT JOIN GRUPO E    ON ((XZ.GRUPO=E.GRUPO AND ISNULL(XZ.GRUPOMULTIPLO,0)=0) OR ( (E.GRUPO=XX.GRUPO AND ISNULL(XZ.GRUPOMULTIPLO,0)=1)  ))
                   
                   LEFT JOIN V_RECUPERAVALORVENCIMENTOPAGAMENTO F ON B.LANCAMENTO = F.LANCAMENTO 
                                                 AND B.DATAVENCIMENTO = F.DATAVENCIMENTO   
                   LEFT JOIN SUBGRUPO V     ON A.SUBGRUPO=V.SUBGRUPO
                   INNER JOIN FIFLUXO_ITEMVINCULO H ON 1=1--B.BANCOPREVISTO=H.BANCO
                                       --FORNECEDOR    
                                      AND (
                                           ((
                                              (  C.FORNECEDOR=H.CODIGO AND H.TIPO=1 )  -- CREDOR
                                           OR (  D.CREDOR=H.CODIGO AND H.TIPO=2  )        
                                           )
                                               AND ((  EXISTS (    SELECT X.CODIGO 
                                                           FROM FIFLUXO_ITEMGRUPOFORNECEDOR X 
                                                           WHERE    1=1 --B.BANCOPREVISTO=X.BANCO 
                                                           AND (      (C.FORNECEDOR=X.CODIGO AND X.TIPO=1) 
                                                                       OR ( D.CREDOR=X.CODIGO AND X.TIPO=2)
                                                               )
                                                           AND   ( (E.GRUPO=X.GRUPO
                                                                   AND   A.SUBGRUPO=X.SUBGRUPO)
                                                                 )
                                                           )
                                                      )
                                                       OR (     (  C.FORNECEDOR=H.CODIGO AND H.TIPO=1 AND ISNULL(C.FLUXOCAIXA_GRUPO,0)<>0)
                                                                       OR (  D.CREDOR=H.CODIGO AND H.TIPO=2 AND ISNULL(D.FLUXOCAIXA_GRUPO,0)<>0)
                                                                     )
                                                   )
                                                   
                                           )
                                      
                                       --GRUPO
                                       OR (  E.GRUPO=H.CODIGO AND H.TIPO=0       
                                           AND not ((  EXISTS (    SELECT X.CODIGO 
                                                           FROM FIFLUXO_ITEMGRUPOFORNECEDOR X 
                                                           WHERE    1=1 --B.BANCOPREVISTO=X.BANCO 
                                                           AND (      (C.FORNECEDOR=X.CODIGO AND X.TIPO=1) 
                                                                       OR ( D.CREDOR=X.CODIGO AND X.TIPO=2)
                                                               )
                                                           AND   ((E.GRUPO=X.GRUPO
                                                                   AND   A.SUBGRUPO=X.SUBGRUPO
                                                                  )
                                                                  
                                                                  )
                           
                                                           )
                                                     )
                                                       OR (
                                                            ( C.FORNECEDOR=H.CODIGO AND H.TIPO=1 AND ISNULL(C.FLUXOCAIXA_GRUPO,0)<>0 ) 
                                                              OR ( D.CREDOR=H.CODIGO AND H.TIPO=2 AND ISNULL(D.FLUXOCAIXA_GRUPO,0)<>0)
                                                           )                                                       
                                                    )
                                           )
                                       
                                   )
                   INNER JOIN FIFLUXO_ITEM I         ON 1=1 --H.BANCO=I.BANCO
                                                    AND H.TIPOOPERACAO=I.TIPOOPERACAO
                                                    AND H.ITEM=I.ITEM
                   INNER JOIN FIFLUXO_TIPOOPERACAO J ON H.TIPOOPERACAO=J.TIPOOPERACAO
                   INNER JOIN TMPFLUXOCAIXABANCO W ON W.IP=@IP AND ISNULL(B.BANCOPREVISTO,0)=W.BANCO
   
   WHERE YEAR(B.DATAVENCIMENTO)=YEAR(@DATAINICIAL)
   AND   MONTH(B.DATAVENCIMENTO)=MONTH(@DATAINICIAL)
   AND ISNULL(A.DOACAO,0)=0
   AND J.TIPOOPERACAO IN(SELECT G.TIPOOPERACAO FROM FIFLUXO_BANCOTIPOOPERACAO G WHERE 1=1 )--H.BANCO=G.BANCO )
   ORDER BY 1,2,4
   --RECEBER
   INSERT INTO TMPFLUXOCAIXAANS(BANCO,DIA,TIPOOPERACAO,ITEM,NOMEANALITICO,VALOR,TIPO,TIPOLANCAMENTO,IP,TIPOITEM,LANCAMENTO)    
   SELECT 0,
       DAY(B.DATAVENCIMENTO) AS DIA,
       REPLICATE('0',2-LEN(LTRIM(ISNULL(J.TIPOOPERACAO,0)))) + LTRIM(ISNULL(J.TIPOOPERACAO,0)) + ' ' + ISNULL(J.NOME,'') AS TIPOOPERACAO,
       (CASE WHEN @SINTETICO=0 THEN 
           REPLICATE('0',2-LEN(LTRIM(ISNULL(J.TIPOOPERACAO,0)))) + LTRIM(ISNULL(J.TIPOOPERACAO,0)) + '.' + 
           REPLICATE('0',2-LEN(LTRIM(ISNULL(I.ITEM,0)))) + LTRIM(ISNULL(I.ITEM,0)) +' '+
           I.NOME + 
           (CASE WHEN @PREVISTOREALIZADO=0 THEN
               ISNULL((CASE    WHEN B.DATAVENCIMENTO<=@DATAINICIAL AND ISNULL(ISNULL(I.FORNECEDOR_VENCER,I.FORNECEDOR_VENCER),0)=1 THEN ' - A VENCER' 
                       WHEN B.DATAVENCIMENTO>@DATAFINAL  AND ISNULL(ISNULL(I.FORNECEDOR_VENCIDO,I.FORNECEDOR_VENCIDO),0)=1 THEN ' - VENCIDO' 
               END),'') 
            ELSE '' END)
        ELSE
         '' 
        END) AS ITEM,
   
       (CASE WHEN @SINTETICO=0 AND @PREVISTOREALIZADO=0 THEN   
           (CASE WHEN ISNULL(ISNULL(I.EXIBEANALITICO,I.EXIBEANALITICO),0)=1 THEN 
               (CASE   WHEN ISNULL(H.TIPO,0)=0 THEN E.DESCRICAO 
                   WHEN ISNULL(H.TIPO,0)=3 THEN C.NOME
                   WHEN ISNULL(H.TIPO,0)=4 THEN E.DESCRICAO  + ' - ' + V.DESCRICAO
                END)
           ELSE '' END) 
        ELSE 
           ''
        END ) AS NOMEANALITICO,
           
       (CASE WHEN ISNULL(@EXIBESOPAGAR,0)=0 THEN 
           (CASE WHEN ISNULL(Z.CONVENIO,0)<>0 AND ISNULL(Z.VALORTETOFINANCEIRO,0)<>0 AND ISNULL(@TETOFINANCEIRO,0)=1 THEN  Z.VALORTETOFINANCEIRO ELSE ISNULL(B.VALORVENCIMENTO,0) END)
         ELSE (CASE WHEN ISNULL(Z.CONVENIO,0)<>0 AND ISNULL(Z.VALORTETOFINANCEIRO,0)<>0 AND ISNULL(@TETOFINANCEIRO,0)=1 THEN  Z.VALORTETOFINANCEIRO ELSE ISNULL(B.VALORVENCIMENTO,0) END)-ISNULL(F.VALORRECEBIMENTO,0) END),
       0,0,@IP,H.TIPO,A.LANCAMEnTO
   FROM FILANCAMENTORECEBIMENTO A  INNER JOIN FILANCAMENTORECEBIMENTOVENCIMENTO B ON A.LANCAMENTO = B.LANCAMENTO
                                   INNER JOIN V_RECUPERATIPORECEBIMENTO C ON A.TIPOPACIENTE = C.TIPOPACIENTE
                                                                      AND A.TIPO         = C.TIPO
                                                                      AND A.CODIGO       = C.CODIGO
                                                                      AND A.LANCAMENTO   = C.LANCAMENTO 

                   LEFT JOIN OUTROS D ON A.CODIGO = D.OUTRO AND C.TIPO=2
                   LEFT JOIN GRUPO E  ON A.GRUPO=E.GRUPO
                   LEFT JOIN SUBGRUPO V     ON A.SUBGRUPO=V.SUBGRUPO
                   LEFT JOIN CONVENIOS Z    ON A.CODIGO=Z.CONVENIO AND A.TIPO=1 -- CONVENIOS
                   
                   LEFT JOIN V_RECUPERAVALORVENCIMENTORECEBIDO F ON B.LANCAMENTO = F.LANCAMENTO 
                                         AND B.DATAVENCIMENTO = F.DATAVENCIMENTO
      

                   INNER JOIN FIFLUXO_ITEMVINCULO H ON 1=1 --B.BANCOPREVISTO=H.BANCO
                                   --OUTROS
                                      AND (
                                           ((
                                              ( D.OUTRO=H.CODIGO AND H.TIPO=3 )         
                                           )
                                               AND ((  EXISTS (    SELECT X.CODIGO 
                                                           FROM FIFLUXO_ITEMGRUPOFORNECEDOR X 
                                                           WHERE    1=1 --B.BANCOPREVISTO=X.BANCO 
                                                           AND (      ( D.OUTRO=X.CODIGO AND X.TIPO=3)
                                                               )
                                                           AND   A.GRUPO=X.GRUPO
                                                           AND   A.SUBGRUPO=X.SUBGRUPO
                                                           )
                                                   )   )
                                           )
                                      
                                       --GRUPO
                                       OR (  E.GRUPO=H.CODIGO AND H.TIPO=0       
                                           AND not ((  EXISTS (    SELECT X.CODIGO 
                                                           FROM FIFLUXO_ITEMGRUPOFORNECEDOR X 
                                                           WHERE    1=1 --B.BANCOPREVISTO=X.BANCO 
                                                           AND (       ( D.OUTRO=X.CODIGO AND X.TIPO=3)
                                                               )
                                                           AND   A.GRUPO=X.GRUPO
                                                           AND   A.SUBGRUPO=X.SUBGRUPO
                                                           )
                                                   )   )
                                           )   
                                       
                                   )



                   INNER JOIN FIFLUXO_ITEM I        ON 1=1 --H.BANCO=I.BANCO
                                   AND H.TIPOOPERACAO=I.TIPOOPERACAO
                               AND H.ITEM=I.ITEM
                   INNER JOIN FIFLUXO_TIPOOPERACAO J ON H.TIPOOPERACAO=J.TIPOOPERACAO
                   INNER JOIN TMPFLUXOCAIXABANCO W ON W.IP=@IP AND ISNULL(B.BANCOPREVISTO,0)=W.BANCO
   WHERE 1 = 1 
   AND B.DATAVENCIMENTO >= @DATAINICIAL
   AND B.DATAVENCIMENTO <= @DATAFINAL
   --AND B.VALORVENCIMENTO>ISNULL(F.VALORRECEBIMENTO,0)
   --EXLUI TUDO Q TIVER LANCAMENTO DE GRUPO POREM JA TEM COMO TERCEIROS
   DELETE FROM TMPFLUXOCAIXAANS
   WHERE EXISTS(SELECT LANCAMENTO FROM TMPFLUXOCAIXAANS A
                WHERE TMPFLUXOCAIXAANS.LANCAMENTO=A.LANCAMENTO
                AND   TMPFLUXOCAIXAANS.TIPO=A.TIPO
                AND   TMPFLUXOCAIXAANS.IP=A.IP
                AND   TMPFLUXOCAIXAANS.DIA=A.DIA
                AND   A.TIPOITEM<>0
               )
   
   AND TMPFLUXOCAIXAANS.TIPOITEM=0
   AND TMPFLUXOCAIXAANS.LANCAMENTO<>0
   AND TMPFLUXOCAIXAANS.IP=@IP

   INSERT INTO TMPFLUXOCAIXAANS(BANCO,DIA,TIPOOPERACAO,ITEM,NOMEANALITICO,VALOR,TIPO,TIPOLANCAMENTO,IP)    
   SELECT  DISTINCT A.BANCO,DAY(B.DATA),A.TIPOOPERACAO,A.ITEM,A.NOMEANALITICO,0,0,0,@IP
   FROM    TMPFLUXOCAIXAANS A CROSS JOIN DIAMES B
   WHERE   YEAR(B.DATA)=YEAR(@DATAINICIAL)
   AND     MONTH(B.DATA)=MONTH(@DATAINICIAL)
   AND     A.TIPOLANCAMENTO=0
   AND A.IP=@IP
   
   INSERT INTO TMPFLUXOCAIXAANS(BANCO,DIA,TIPOOPERACAO,ITEM,NOMEANALITICO,VALOR,TIPO,TIPOLANCAMENTO,IP)    
   SELECT  A.BANCO,DIA,A.TIPOOPERACAO,A.ITEM,A.NOMEANALITICO,SUM(A.VALOR),1,0,@IP
   FROM    TMPFLUXOCAIXAANS A 
   WHERE   A.TIPOLANCAMENTO=0
   AND     A.IP=@IP
   GROUP BY A.BANCO,DIA,A.TIPOOPERACAO,A.ITEM,A.NOMEANALITICO
   
   INSERT INTO TMPFLUXOCAIXAANS(BANCO,DIA,TIPOOPERACAO,ITEM,NOMEANALITICO,VALOR,TIPO,TIPOLANCAMENTO,IP)    
   SELECT  DISTINCT A.BANCO,DAY(B.DATA),A.TIPOOPERACAO,A.ITEM,A.NOMEANALITICO,0,0,1,@IP
   FROM    TMPFLUXOCAIXAANS A CROSS JOIN DIAMES B
   WHERE   YEAR(B.DATA)=YEAR(@DATAINICIAL)
   AND     MONTH(B.DATA)=MONTH(@DATAINICIAL)
   AND     A.TIPOLANCAMENTO=1
   AND A.IP=@IP
   
   INSERT INTO TMPFLUXOCAIXAANS(BANCO,DIA,TIPOOPERACAO,ITEM,NOMEANALITICO,VALOR,TIPO,TIPOLANCAMENTO,IP)    
   SELECT  A.BANCO,DIA,A.TIPOOPERACAO,A.ITEM,A.NOMEANALITICO,SUM(A.VALOR),1,1,@IP
   FROM    TMPFLUXOCAIXAANS A 
   WHERE   A.TIPOLANCAMENTO=1
   AND A.IP=@IP
   GROUP BY A.BANCO,DIA,A.TIPOOPERACAO,A.ITEM,A.NOMEANALITICO
   DELETE FROM TMPFLUXOCAIXAANS 
   WHERE   IP=@IP
   AND     TIPO=0
go

