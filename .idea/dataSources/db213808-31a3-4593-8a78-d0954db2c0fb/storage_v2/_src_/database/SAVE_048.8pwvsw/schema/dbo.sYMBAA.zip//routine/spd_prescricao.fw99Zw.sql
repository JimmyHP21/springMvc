-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spd_prescricao
	@id bigint 
as
begin
	set nocount on
	delete from dbo.prescricao
	where
		id = @id
end
go

