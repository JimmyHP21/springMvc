 
-- =============================================
-- Author:		M2 TECNOLOGIA
-- Create date:	06/09/2017
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPDel_TUSS_TAB64	@TERMINOLOGIA varchar(2),
	@CODIGOTUSS varchar(10),
	@INICIOVIGENCIA datetime
AS
BEGIN
	SET NOCOUNT ON
	DELETE FROM TUSS_TAB64
	WHERE
		TERMINOLOGIA = @TERMINOLOGIA
		AND CODIGOTUSS = @CODIGOTUSS
		AND INICIOVIGENCIA = @INICIOVIGENCIA
END
go

