-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_produto_lote_etiqueta_id
	@sequencia int
as
begin
	set nocount on
	select
	 produto, lote, validadelote, sequencia
	from dbo.produto_lote_etiqueta
	where
		sequencia = @sequencia
end
go

