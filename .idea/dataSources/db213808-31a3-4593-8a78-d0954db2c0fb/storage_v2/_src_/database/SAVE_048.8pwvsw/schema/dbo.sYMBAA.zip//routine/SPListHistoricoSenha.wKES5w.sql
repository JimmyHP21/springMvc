 CREATE PROCEDURE SPListHistoricoSenha @idUsuario integer, @dataAtualizacaoSenha datetime, @senha VARCHAR(15) 
 AS 
 BEGIN 
    SELECT data_inclusao,senha_antiga FROM HISTORICO_SENHA 
    WHERE id_usuario = @idUsuario and senha_antiga = @senha and data_inclusao >= @dataAtualizacaoSenha 
 END
 go

