-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_pres_cad_periodo_id
	@id int 
as
begin
	set nocount on
	select
	 id, descricao, hora_inicio, hora_fim, hora_padrao, cor_rotulo, ordem_exibicao, atualizacao, log
	from dbo.pres_cad_periodo
	where
		id = @id
end
go

