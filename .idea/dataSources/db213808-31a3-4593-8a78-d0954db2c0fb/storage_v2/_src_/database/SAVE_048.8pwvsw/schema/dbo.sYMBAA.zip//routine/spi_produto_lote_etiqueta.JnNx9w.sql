-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spi_produto_lote_etiqueta
	@sequencia int  output,
	@produto int ,
	@lote char(15) ,
	@validadelote datetime 	
as
begin
	set nocount on
	insert into dbo.produto_lote_etiqueta
		(produto,lote,validadelote)
	values
		(@produto,@lote,@validadelote)

	select @sequencia = scope_identity()
end
go

