-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_usuario_id
	@usuario int 
as
begin
	set nocount on
	select
	 usuario, nome, logon, senha, atualizacao, administralicenca, sndi, snda, snde, almoxarifadoi, almoxarifadoa, almoxarifadoe, farmaciai, farmaciaa, farmaciae, estoquei, estoquea, estoquee, emailpadraocotacao, prescricaointerno, prescricaoambulatorial, prescricaourgencia, ccpadraocotacao, observacao, desativado, telamedicoapenasconsulta, alteraguiatelatransferencia, altera_tabela_preco_convenio, prescricaoexterno, medico_apenascbo, medico_cadastroespecialidade, medico_cadastroclassificacao, medico_cadastrohorario, tutorprescricao, medico, administracusto, excluibaixafinanceirocompensado, excluiragendaconsulta, permitereemprimirprescricao, permitealteranome, preparakitmedicamento, permite_alterar_lanc_pagterceiro, naopermitealteraragendamento, naopermitealteracaofinanceiro, referencia, unidadeencaminhamento, permite_apenas_lancar_contasreceber, permite_conferir_laudo, usuariounimed, gerente, naopermitecancelarregistros, permissaopredevolucao, permissaodevolucao, permitedevolucaodireta, medico_cadastrohonorario, relprescsomentedieta, cpf, rg, datanasc, inicializarsenha, data_atualizacao_senha, pres_cad_tutor
	from dbo.usuario
	where
		usuario = @usuario
end
go

