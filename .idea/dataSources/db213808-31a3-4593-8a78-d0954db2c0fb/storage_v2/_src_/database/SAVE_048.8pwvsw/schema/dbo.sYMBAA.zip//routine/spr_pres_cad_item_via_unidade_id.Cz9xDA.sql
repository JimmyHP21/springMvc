-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_pres_cad_item_via_unidade_id
	@id int 
as
begin
	set nocount on
	select
	 id, item, via, unidade, padrao, atualizacao, apresentacao, log
	from dbo.pres_cad_item_via_unidade
	where
		id = @id
end
go

