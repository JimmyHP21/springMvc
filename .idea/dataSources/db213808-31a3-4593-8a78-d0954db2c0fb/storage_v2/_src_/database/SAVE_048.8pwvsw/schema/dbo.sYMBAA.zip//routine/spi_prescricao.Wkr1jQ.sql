-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spi_prescricao
	@id bigint  output,
	@tipoatendimento int  = null,
	@registro int  = null,
	@medico smallint  = null,
	@data datetime  = null,
	@datacriacao datetime  = null,
	@datafinalizacao datetime  = null,
	@usuario int  = null,
	@atualizacao varchar(150)  = null,
	@statusprescricao int  = null,
	@log bigint  = null,
	@urgente int  = null,
	@horario_inicio datetime  = null
as
begin
	set nocount on
	insert into dbo.prescricao
		( tipoatendimento, registro, medico, data, datacriacao, datafinalizacao, usuario, atualizacao, statusprescricao, log, urgente, horario_inicio)
	values
		(@tipoatendimento,@registro,@medico,@data,@datacriacao,@datafinalizacao,@usuario,@atualizacao,@statusprescricao,@log,@urgente,@horario_inicio)

	select @id = scope_identity()
end
go

