 
-- =============================================
-- AUTHOR:		M2 TECNOLOGIA
-- CREATE DATE:	28/06/2016
-- DESCRIPTION:	
-- REVISIONS:	
-- =============================================
CREATE PROCEDURE DBO.SPD_TISS_LOTEGUIA_DETALHE
	@ID BIGINT 
AS
BEGIN
	SET NOCOUNT ON
	DELETE FROM DBO.TISS_LOTEGUIA_DETALHE
	WHERE
		ID = @ID
END
go

