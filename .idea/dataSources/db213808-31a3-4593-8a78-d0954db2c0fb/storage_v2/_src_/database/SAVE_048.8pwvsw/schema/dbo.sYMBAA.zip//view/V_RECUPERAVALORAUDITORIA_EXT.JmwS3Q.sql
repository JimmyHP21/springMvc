 CREATE VIEW V_RECUPERAVALORAUDITORIA_EXT AS 
SELECT Sum (A.quantidade / COALESCE (CASE 
                                       WHEN A.convlanc = 0 THEN 1 
                                       ELSE A.convlanc 
                                     END, 1))                            AS 
       QTDEAUDITADA, 
       Sum (A.quantidade / COALESCE (CASE 
                                       WHEN A.convlanc = 0 THEN 1 
                                       ELSE A.convlanc 
                                     END, 1)) * ( 
       A.valorunitario * Isnull(A.convlanc, 
                         1) ) AS 
       VALORAUDITADA, 
       Sum (Isnull(A.quantidadedispensada, 0) / COALESCE (CASE 
                                                            WHEN A.convlanc = 0 
                                                          THEN 1 
                                                            ELSE A.convlanc 
                                                          END, 1))       AS 
       QTDEDISPENSADA, 
       Sum (Isnull(A.quantidadedispensada, 0) / COALESCE (CASE 
                                                            WHEN A.convlanc = 0 
                                                          THEN 1 
                                                            ELSE A.convlanc 
                                                          END, 1)) * ( 
       A.valorunitario * Isnull(A.convlanc, 1) )                         AS 
       VALORDISPENSADA, 
       ( CASE 
           WHEN Sum (Isnull(A.quantidadedispensada, 0) / 
                     COALESCE (CASE 
                                 WHEN 
                     A.convlanc = 0 
                               THEN 1 
                                 ELSE A.convlanc 
                               END, 1)) > Sum ( 
                A.quantidade / COALESCE (CASE 
                WHEN A.convlanc = 0 THEN 1 
                ELSE A.convlanc 
                END, 1)) THEN Sum (Isnull(A.quantidadedispensada, 0) / 
                                   COALESCE (CASE 
                                               WHEN A.convlanc = 0 THEN 1 
                                               ELSE A.convlanc 
                                             END, 1)) - Sum (A.quantidade / 
                                                             COALESCE (CASE 
                              WHEN A.convlanc = 0 THEN 1 
                              ELSE A.convlanc 
                              END, 1)) 
           ELSE 0 
         END )                                                           AS 
       QUANTIDADEDISPENSADAAMAIS, 
       ( CASE 
           WHEN Sum (Isnull(A.quantidadedispensada, 0) / 
                     COALESCE (CASE 
                                 WHEN 
                     A.convlanc = 0 
                               THEN 1 
                                 ELSE A.convlanc 
                               END, 1)) < Sum ( 
                A.quantidade / COALESCE (CASE 
                WHEN A.convlanc = 0 THEN 1 
                ELSE A.convlanc 
                END, 1)) THEN Sum (A.quantidade / COALESCE (CASE 
                                                              WHEN 
                                                  A.convlanc = 0 THEN 
                                                              1 
                                                              ELSE A.convlanc 
                                                            END, 1)) - 
                              Sum (Isnull(A.quantidadedispensada, 0) / 
                                   COALESCE (CASE 
                                               WHEN A.convlanc = 0 
                                             THEN 1 
                                               ELSE A.convlanc 
                                             END, 1)) 
         END )                                                           AS 
       QUANTIDADEAUDITADAAMAIS, 
       Sum (Isnull(A.quantidadedispensada, 0) / COALESCE (CASE 
                                                            WHEN A.convlanc = 0 
                                                          THEN 1 
                                                            ELSE A.convlanc 
                                                          END, 1)) * ( 
       A.valorunitario * Isnull(A.convlanc, 1) )                         AS 
       VALORUNITARIODISPENSADO, 
       A.valorunitario * Isnull(A.convlanc, 1)                           AS 
       VALOR, 
       A.dataconsumo, 
       A.localconsumo, 
       A.procedimento, 
       A.procedimentonome, 
       A.procedimentofaturado, 
       Sum (A.quantidade_auditoria)                                      AS 
       QUANTIDADEAUDITORIA, 
       A.registro, 
       C.nome                                                            AS 
       NOMEPACIENTE, 
       D.descricao                                                       AS 
       NOMECONVENIO, 
       D.convenio                                                        AS 
       CONVENIO, 
       B.datainternacao, 
       B.dataalta, 
       B.datafaturamento, 
       A.unidadefaturamento, 
       Max (E.descricao)                                                 AS 
       TIPOERRO, 
       F.descricao                                                       AS 
       CENTROCUSTO 
FROM   movim_ext A 
       INNER JOIN externo B 
               ON A.registro = B.registro 
       INNER JOIN fichas C 
               ON B.ficha = C.ficha 
       INNER JOIN convenios D 
               ON B.convenio = D.convenio 
       LEFT JOIN auditoria_tipoerro E 
              ON E.tipo = A.auditoria_tipoerro 
       LEFT JOIN centrocusto F 
              ON A.centrocusto = F.centrocusto 
WHERE  A.tipolancamento = 1 
GROUP  BY A.dataconsumo, 
          A.localconsumo, 
          A.procedimento, 
          A.procedimentonome, 
          A.procedimentofaturado, 
          A.valorunitario, 
          A.convlanc, 
          A.registro, 
          C.nome, 
          D.descricao, 
          D.convenio, 
          B.datainternacao, 
          B.dataalta, 
          B.datafaturamento, 
          A.unidadefaturamento, 
          F.descricao
 go

