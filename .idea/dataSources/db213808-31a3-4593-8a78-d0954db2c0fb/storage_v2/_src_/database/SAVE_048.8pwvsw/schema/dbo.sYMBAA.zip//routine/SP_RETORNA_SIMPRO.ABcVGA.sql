CREATE PROCEDURE [dbo].[SP_RETORNA_SIMPRO] @TIPO		VARCHAR(255),
		@TEXTO		VARCHAR(1000),
		@COMPLETO		VARCHAR(1)
	AS
	
		IF @COMPLETO = 'S'
		BEGIN
			SET @TEXTO = '%'+@TEXTO+'%'
		END
		 
		IF @TIPO = 'Nome Produto'
		BEGIN
			SELECT  
				ID_SIMPRO,	
				CD_USUARIO,  
				CD_FRACAO,  	
				DESCRICAO,  	
				VIGENCIA,  	
				IDENTIF,  	
				PC_EM_FAB,  	
				PC_EM_VEN, 	
				PC_EM_USU,  	
				PC_FR_FAB,  	
				PC_FR_VEN,  	
				PC_FR_USU,  	
				TP_EMBAL,  	
				TP_FRACAO,  	
				QTDE_EMBAL,  
				QTDE_FRAC,  	
				PERC_LUCR,  	
				TIP_ALT,  	
				FABRICA,  	
				CD_SIMPRO,  	
				CD_MERC,  	
				PERC_DESC,  	
				VLR_IPI,  	
				CD_REG_ANV,  
				DT_REG_ANV,  
				CD_BARRA,  	
				LISTA,  		
				HOSPITALAR,  
				FRACIONADO,  
				VERSAO		
		FROM 
				SIMPRO
		WHERE 1=1
			  AND DESCRICAO LIKE  @TEXTO
		END 
		IF @TIPO = 'Listar Todos!'
		BEGIN
				SELECT  
					ID_SIMPRO,	
					CD_USUARIO,  
					CD_FRACAO,  	
					DESCRICAO,  	
					VIGENCIA,  	
					IDENTIF,  	
					PC_EM_FAB,  	
					PC_EM_VEN, 	
					PC_EM_USU,  	
					PC_FR_FAB,  	
					PC_FR_VEN,  	
					PC_FR_USU,  	
					TP_EMBAL,  	
					TP_FRACAO,  	
					QTDE_EMBAL,  
					QTDE_FRAC,  	
					PERC_LUCR,  	
					TIP_ALT,  	
					FABRICA,  	
					CD_SIMPRO,  	
					CD_MERC,  	
					PERC_DESC,  	
					VLR_IPI,  	
					CD_REG_ANV,  
					DT_REG_ANV,  
					CD_BARRA,  	
					LISTA,  		
					HOSPITALAR,  
					FRACIONADO,  
					VERSAO		
				FROM 
						SIMPRO
				WHERE 1=1
		END 
		IF @TIPO = 'Versão'
		BEGIN
			SELECT  
				ID_SIMPRO,	
				CD_USUARIO,  
				CD_FRACAO,  	
				DESCRICAO,  	
				VIGENCIA,  	
				IDENTIF,  	
				PC_EM_FAB,  	
				PC_EM_VEN, 	
				PC_EM_USU,  	
				PC_FR_FAB,  	
				PC_FR_VEN,  	
				PC_FR_USU,  	
				TP_EMBAL,  	
				TP_FRACAO,  	
				QTDE_EMBAL,  
				QTDE_FRAC,  	
				PERC_LUCR,  	
				TIP_ALT,  	
				FABRICA,  	
				CD_SIMPRO,  	
				CD_MERC,  	
				PERC_DESC,  	
				VLR_IPI,  	
				CD_REG_ANV,  
				DT_REG_ANV,  
				CD_BARRA,  	
				LISTA,  		
				HOSPITALAR,  
				FRACIONADO,  
				VERSAO		
			FROM 
					SIMPRO
			WHERE 1=1
				  AND VERSAO = @TEXTO
		END
go

