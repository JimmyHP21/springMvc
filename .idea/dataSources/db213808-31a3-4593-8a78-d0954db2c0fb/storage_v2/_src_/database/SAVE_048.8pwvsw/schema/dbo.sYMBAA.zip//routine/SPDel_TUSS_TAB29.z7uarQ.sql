
-- =============================================
-- Author:		SSRM2 
-- Create date:	25/08/2014
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPDel_TUSS_TAB29	@CODIGO int
AS
BEGIN
	SET NOCOUNT ON
	DELETE FROM TUSS_TAB29
	WHERE
		CODIGO = @CODIGO
END
go

