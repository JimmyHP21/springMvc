CREATE PROCEDURE SP_RETORNA_SIMPRO_VERSOES 
   AS 
 
       SELECT  DISTINCT 
               VERSAO, 
               replace(convert(NVARCHAR, DT_IMPORTACAO, 103), ' ', '/') AS DT_IMPORTACAO, 
               PRECO_ATUALIZADO 
           FROM 
                   SIMPRO 
           WHERE 1=1 
           ORDER BY PRECO_ATUALIZADO,DT_IMPORTACAO,VERSAO
go

