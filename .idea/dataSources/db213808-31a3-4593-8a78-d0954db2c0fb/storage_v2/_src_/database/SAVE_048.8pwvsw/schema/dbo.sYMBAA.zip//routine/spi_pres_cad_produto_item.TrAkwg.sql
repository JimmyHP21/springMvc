-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spi_pres_cad_produto_item
	@id int  output,
	@produto int ,
	@item int ,
	@apresentacao int ,
	@via int ,
	@atualizacao varchar(150)  = null,
	@log bigint  = null
as
begin
	set nocount on
	insert into dbo.pres_cad_produto_item
		( produto, item, apresentacao, via, atualizacao, log)
	values
		(@produto,@item,@apresentacao,@via,@atualizacao,@log)

	select @id = scope_identity()
end
go

