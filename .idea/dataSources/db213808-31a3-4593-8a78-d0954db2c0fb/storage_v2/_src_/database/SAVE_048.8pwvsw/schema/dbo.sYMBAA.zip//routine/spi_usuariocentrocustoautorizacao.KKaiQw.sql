-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spi_usuariocentrocustoautorizacao
	@usuario int  output,
	@atualizacao varchar(150)  = null,
	@movimenta int  = null,
	@relatorio int  = null,
	@responsavel int  = null
as
begin
	set nocount on
	insert into dbo.usuariocentrocustoautorizacao
		( atualizacao, movimenta, relatorio, responsavel)
	values
		(@atualizacao,@movimenta,@relatorio,@responsavel)

	select @usuario = scope_identity()
end
go

