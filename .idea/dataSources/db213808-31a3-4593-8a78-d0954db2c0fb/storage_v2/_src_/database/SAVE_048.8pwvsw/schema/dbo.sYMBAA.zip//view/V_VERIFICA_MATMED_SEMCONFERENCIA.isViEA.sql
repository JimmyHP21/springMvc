CREATE VIEW V_VERIFICA_MATMED_SEMCONFERENCIA
AS
       SELECT 'AMB'AS TIPO, A.NOTA AS PRESCRICAO,A.REGISTRO, A.PROCEDIMENTO
       FROM MOVIM_PRES_AMB A INNER JOIN AMBULATORIAL B ON A.REGISTRO=B.REGISTRO
                             INNER JOIN PRESCRICAOELETRONICAPERIODO_AMB D ON A.REGISTRO = D.REGISTRO
                                                                         AND A.NOTA = D.PRESCRICAO
                                                                         AND ISNULL(D.PRESCRICAOFINALIZADA,0) = 1  
                             INNER JOIN PREELETPROCEDIMENTOENFERMAGEM_AMB C  WITH (NOLOCK) ON A.PROCEDIMENTO = C.PROCEDIMENTO
                                                                                          AND A.REGISTRO = C.REGISTRO
                                                                                          AND A.SEQUENCIA = C.SEQUENCIA
       WHERE 1 = 1 
       AND NOT EXISTS( SELECT C.SEQUENCIA 
                       FROM MOVIM_AMB C    
                       WHERE A.REGISTRO=C.REGISTRO
                       AND A.PROCEDIMENTO=C.PROCEDIMENTO 
                       AND A.SEQUENCIA=C.SEQUENCIA_MOVIM_PRES)
       AND ISNULL(A.SUSPENSO,0)=0
       AND B.DATAALTA IS NULL 
       GROUP BY A.NOTA,A.REGISTRO, A.PROCEDIMENTO
       UNION ALL
       SELECT 'INT' AS TIPO, A.NOTA AS PRESCRICAO,A.REGISTRO, A.PROCEDIMENTO
       FROM MOVIM_PRES_INT A INNER JOIN INTERNO B ON A.REGISTRO=B.REGISTRO
                             INNER JOIN PRESCRICAOELETRONICAPERIODO_INT D ON A.REGISTRO = D.REGISTRO
                                                                         AND A.NOTA = D.PRESCRICAO
                                                                         AND ISNULL(D.PRESCRICAOFINALIZADA,0) = 1  
                             INNER JOIN PREELETPROCEDIMENTOENFERMAGEM_INT C  WITH (NOLOCK) ON A.PROCEDIMENTO = C.PROCEDIMENTO
                                                                                                  AND A.REGISTRO = C.REGISTRO
                                                                                                  AND A.SEQUENCIA = C.SEQUENCIA
       WHERE 1 = 1 
       AND NOT EXISTS( SELECT C.SEQUENCIA 
                       FROM MOVIM_INT C    
                       WHERE A.REGISTRO=C.REGISTRO
                       AND A.PROCEDIMENTO=C.PROCEDIMENTO 
                       AND A.SEQUENCIA=C.SEQUENCIA_MOVIM_PRES)
       AND ISNULL(A.SUSPENSO,0)=0
       AND B.DATAALTA IS NULL 
       GROUP BY A.NOTA,A.REGISTRO, A.PROCEDIMENTO
       UNION ALL
       SELECT 'EXT' AS TIPO, A.NOTA AS PRESCRICAO,A.REGISTRO, A.PROCEDIMENTO
       FROM MOVIM_PRES_EXT A INNER JOIN EXTERNO B ON A.REGISTRO=B.REGISTRO
                             INNER JOIN PRESCRICAOELETRONICAPERIODO_EXT D ON A.REGISTRO = D.REGISTRO
                                                                         AND A.NOTA = D.PRESCRICAO
                                                                         AND ISNULL(D.PRESCRICAOFINALIZADA,0) = 1  
                             INNER JOIN PREELETPROCEDIMENTOENFERMAGEM_EXT C  WITH (NOLOCK) ON A.PROCEDIMENTO = C.PROCEDIMENTO
                                                                                                  AND A.REGISTRO = C.REGISTRO
                                                                                                  AND A.SEQUENCIA = C.SEQUENCIA
       WHERE 1 = 1 
       AND NOT EXISTS( SELECT C.SEQUENCIA 
                       FROM MOVIM_EXT C    
                       WHERE A.REGISTRO=C.REGISTRO
                       AND A.PROCEDIMENTO=C.PROCEDIMENTO 
                       AND A.SEQUENCIA=C.SEQUENCIA)
       AND ISNULL(A.SUSPENSO,0)=0
       AND B.DATAALTA IS NULL 
       GROUP BY A.NOTA,A.REGISTRO, A.PROCEDIMENTO
go

