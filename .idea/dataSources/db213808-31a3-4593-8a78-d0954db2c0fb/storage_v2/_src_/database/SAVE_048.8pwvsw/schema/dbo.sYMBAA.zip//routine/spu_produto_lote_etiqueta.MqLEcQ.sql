-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spu_produto_lote_etiqueta
	@sequencia int,
	@produto int =null,
	@lote char(15) =null,
	@validadelote datetime =null
as
begin
	set nocount on
	update dbo.produto_lote_etiqueta
		set
		produto = @produto,
		lote = @lote,
		validadelote = @validadelote
	where
		sequencia = @sequencia
		
end
go

