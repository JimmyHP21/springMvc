-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spd_centrocusto
	@centrocusto smallint 
as
begin
	set nocount on
	delete from dbo.centrocusto
	where
		centrocusto = @centrocusto
end
go

