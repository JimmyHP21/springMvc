-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_usuariocentrocustoautorizacao_id
	@usuario int ,
	@centrocusto smallint 
as
begin
	set nocount on
	select
	 usuario, centrocusto, atualizacao, movimenta, relatorio, responsavel
	from dbo.usuariocentrocustoautorizacao
	where
		usuario = @usuario
		and centrocusto = @centrocusto
end
go

