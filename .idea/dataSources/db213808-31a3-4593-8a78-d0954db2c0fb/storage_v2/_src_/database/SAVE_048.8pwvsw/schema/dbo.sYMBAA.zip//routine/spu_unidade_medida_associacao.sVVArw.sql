-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spu_unidade_medida_associacao
	@id int ,
	@unidadede int  = null,
	@unidadepara int  = null,
	@fator money  = null,
	@atualizacao varchar(150)  = null,
	@log bigint  = null
as
begin
	set nocount on
	update dbo.unidade_medida_associacao
	set
		unidadede = @unidadede,
		unidadepara = @unidadepara,
		fator = @fator,
		atualizacao = @atualizacao,
		log = @log
	where
		id = @id
end
go

