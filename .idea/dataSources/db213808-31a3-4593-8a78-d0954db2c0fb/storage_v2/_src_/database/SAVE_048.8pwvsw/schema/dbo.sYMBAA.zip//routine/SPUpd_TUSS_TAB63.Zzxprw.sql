 
-- =============================================
-- Author:		M2 TECNOLOGIA
-- Create date:	06/09/2017
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPUpd_TUSS_TAB63	@CODIGO int,
	@INICIOVIGENCIA datetime,
	@GRUPO varchar(1000),
	@FIMVIGENCIA datetime,
	@FIMIMPLANTACAO datetime
AS
BEGIN
	SET NOCOUNT ON
	UPDATE TUSS_TAB63
	SET
		GRUPO = @GRUPO,
		FIMVIGENCIA = @FIMVIGENCIA,
		FIMIMPLANTACAO = @FIMIMPLANTACAO
	WHERE
		CODIGO = @CODIGO
		AND INICIOVIGENCIA = @INICIOVIGENCIA
END
go

