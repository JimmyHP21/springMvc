-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spl_usuariocentrocustoautorizacao

as
begin
	set nocount on
	select
	 usuario, centrocusto, atualizacao, movimenta, relatorio, responsavel
	from dbo.usuariocentrocustoautorizacao
end
go

