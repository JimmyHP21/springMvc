
-- =============================================
-- Author:		SSRM2 
-- Create date:	25/08/2014
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPDel_TUSS_TAB87 @CODIGO float
AS
BEGIN
	SET NOCOUNT ON
	DELETE FROM TUSS_TAB87
	WHERE CODIGO = @CODIGO
END
go

