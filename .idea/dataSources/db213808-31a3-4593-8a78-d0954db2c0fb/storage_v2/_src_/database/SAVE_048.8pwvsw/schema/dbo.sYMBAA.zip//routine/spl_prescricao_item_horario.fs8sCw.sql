-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spl_prescricao_item_horario

as
begin
	set nocount on
	select
	 id, prescricao_item, horario, status, usuario, data, atualizacao, log
	from dbo.prescricao_item_horario
end
go

