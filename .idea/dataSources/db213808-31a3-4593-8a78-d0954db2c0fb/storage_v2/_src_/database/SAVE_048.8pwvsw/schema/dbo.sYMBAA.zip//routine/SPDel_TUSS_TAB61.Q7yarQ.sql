
-- =============================================
-- Author:		SSRM2 
-- Create date:	25/08/2014
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPDel_TUSS_TAB61	@CODIGO int
AS
BEGIN
	SET NOCOUNT ON
	DELETE FROM TUSS_TAB61
	WHERE
		CODIGO = @CODIGO
END
go

