-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_prescricao
	@id bigint = null,
	@tipoatendimento int = null,
	@registro int = null,
	@medico smallint = null,
	@data datetime = null,
	@datacriacao datetime = null,
	@datafinalizacao datetime = null,
	@usuario int = null,
	@atualizacao varchar(150) = null,
	@statusprescricao int = null,
	@log bigint = null,
	@urgente int = null,
	@horario_inicio datetime = null
as
begin
	set nocount on
	select
	 id, tipoatendimento, registro, medico, data, datacriacao, datafinalizacao, usuario, atualizacao, statusprescricao, log, urgente, horario_inicio
	from dbo.prescricao
where (id = @id or @id is null )
 and (tipoatendimento = @tipoatendimento or @tipoatendimento is null )
 and (registro = @registro or @registro is null )
 and (medico = @medico or @medico is null )
 and (data = @data or @data is null )
 and (datacriacao = @datacriacao or @datacriacao is null )
 and (datafinalizacao = @datafinalizacao or @datafinalizacao is null )
 and (usuario = @usuario or @usuario is null )
 and (atualizacao = @atualizacao or @atualizacao is null )
 and (statusprescricao = @statusprescricao or @statusprescricao is null )
 and (log = @log or @log is null )
 and (urgente = @urgente or @urgente is null )
 and (horario_inicio = @horario_inicio or @horario_inicio is null )
end
go

