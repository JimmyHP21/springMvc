

CREATE PROCEDURE SP_TISS_030200_RESUMO_INTERNACAO_DECLARACOES @REGISTRO      VARCHAR(MAX) = NULL,
															  @TIPO_REGISTRO VARCHAR(MAX) = NULL,	   
															  @TIPO_FATURA   VARCHAR(MAX) = 'TOTAL'
AS
BEGIN
    IF @TIPO_REGISTRO = 'INTERNO' AND (@TIPO_FATURA = 'TOTAL' OR @TIPO_FATURA = 'FINAL')
      BEGIN
          SELECT DISTINCT
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------CHAVES--------------------------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------
          'INTERNO'                                            AS TIPO_REGISTRO,
          ATEND.REGISTRO                                       AS REGISTRO,
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------DECLARACOES - OPCIONAL----------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  		  		  
          NULL                                                 AS declaracoesDeclaracaoNascido,--Número da Declaração de Nascido Vivo  |  String  |  11  |    |  Número da declaração de nascido vivo, que é o documento-base do Sistema de Informações sobre Nascidos Vivos do Ministério da Saúde (SINASC/MS)  |  Condicionado. Deve ser preenchido em caso de internação obstétrica onde tenha havido nascido vivo.
          NULL                                                 AS declaracoesDiagnosticoObito,--Diagnóstico de óbito  |  String  |  4  |    |  Código do diagnóstico de óbito do paciente de acordo com a Classificação Internacional de Doenças e de Problemas Relacionados a Saúde - 10ª revisão  |  Opcional.
          DOI.DECLARACAO									   AS declaracoesDeclaracaoObito,--Número da Declaração de Óbito  |  String  |  11  |    |  Número da declaração de óbito, que é o documento-base do Sistema de Informações sobre Mortalidade do Ministério da Saúde (SIM/MS).  |  Condicionado. Deve ser preenchido quando o motivo de encerramento for igual ao código 41 (Óbito com declaração de óbito fornecida pelo médico assistente) ou quando for óbito do RN na guia de internação da mãe.
		  CASE WHEN LEFT(PRON.NOME, 2) = 'RN' 
		  	   THEN 'S' 
		  	   ELSE 'N' 
		  END 												   AS declaracoesIndicadorDORN--Indicador de declaração de óbito de recém-nato.  |  String  |  1  |    |  Indica se a declaração de óbito é do recém-nato durante a internação da mãe.  |  Condicionado. Deve ser preenchido quando o campo Número da Declaração de Óbito for preenchido. Preencher com S - SIM caso a declaração de óbito informada seja do RN e com N - Não caso a declaração de óbito informada seja da mãe.

          --SELECT TOP 1 *
          FROM  INTERNO AS ATEND WITH (READPAST)							
            INNER JOIN FICHAS AS PRON WITH (READPAST)
                     ON PRON.FICHA = ATEND.FICHA
					AND ATEND.REGISTRO = @REGISTRO                         
                    AND ISNULL(ATEND.CANCELADO, 0) = 0		
							
            INNER JOIN INTERNO_DECLARACAO_OBITO AS DOI WITH (READPAST)
                    ON ATEND.REGISTRO = DOI.REGISTRO							
																				  
			UNION ALL				
			
            SELECT DISTINCT
	        ------------------------------------------------------------------------------------------------------------------------------------------------
	        ----------CHAVES--------------------------------------------------------------------------------------------------------------------------------
	        ------------------------------------------------------------------------------------------------------------------------------------------------
	        'INTERNO'                                            AS TIPO_REGISTRO,
	        DNV.REGISTRO                                         AS REGISTRO,
	        ------------------------------------------------------------------------------------------------------------------------------------------------
	        ----------DECLARACOES - OPCIONAL----------------------------------------------------------------------------------------------------------------
	        ------------------------------------------------------------------------------------------------------------------------------------------------		  		  		  
	        DNV.NUMERODECLARACAO,
	        NULL,
	        NULL,
	        NULL
	        --SELECT TOP 1 *
	        FROM INTERNO_NASCIDOS AS DNV WITH (READPAST)
	        WHERE DNV.REGISTRO = @REGISTRO				
      END 
	  ELSE IF @TIPO_REGISTRO = 'INTERNO' AND @TIPO_FATURA = 'PARCIAL'
      BEGIN
          SELECT DISTINCT
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------CHAVES--------------------------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------
          'INTERNO'                                            AS TIPO_REGISTRO,
          ATEND.REGISTRO                                       AS REGISTRO,		  
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------DECLARACOES - OPCIONAL----------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  		  		  
          NULL                                                 AS declaracoesDeclaracaoNascido,--Número da Declaração de Nascido Vivo  |  String  |  11  |    |  Número da declaração de nascido vivo, que é o documento-base do Sistema de Informações sobre Nascidos Vivos do Ministério da Saúde (SINASC/MS)  |  Condicionado. Deve ser preenchido em caso de internação obstétrica onde tenha havido nascido vivo.
          NULL                                                 AS declaracoesDiagnosticoObito,--Diagnóstico de óbito  |  String  |  4  |    |  Código do diagnóstico de óbito do paciente de acordo com a Classificação Internacional de Doenças e de Problemas Relacionados a Saúde - 10ª revisão  |  Opcional.
          DOI.DECLARACAO									   AS declaracoesDeclaracaoObito,--Número da Declaração de Óbito  |  String  |  11  |    |  Número da declaração de óbito, que é o documento-base do Sistema de Informações sobre Mortalidade do Ministério da Saúde (SIM/MS).  |  Condicionado. Deve ser preenchido quando o motivo de encerramento for igual ao código 41 (Óbito com declaração de óbito fornecida pelo médico assistente) ou quando for óbito do RN na guia de internação da mãe.
		  CASE WHEN LEFT(PRON.NOME, 2) = 'RN' 
		  	   THEN 'S' 
		  	   ELSE 'N' 
		  END 												   AS declaracoesIndicadorDORN--Indicador de declaração de óbito de recém-nato.  |  String  |  1  |    |  Indica se a declaração de óbito é do recém-nato durante a internação da mãe.  |  Condicionado. Deve ser preenchido quando o campo Número da Declaração de Óbito for preenchido. Preencher com S - SIM caso a declaração de óbito informada seja do RN e com N - Não caso a declaração de óbito informada seja da mãe.
		  
          --SELECT TOP 1 *
		  FROM EXTERNO AS ATEND WITH (READPAST)                            
                 INNER JOIN INTERNO AS INTER WITH (READPAST)
                         ON INTER.REGISTRO = ATEND.PACIENTE_INTERNO_FATURADO
                        AND ISNULL(ATEND.CANCELADO, 0) = 0
						AND ISNULL(INTER.CANCELADO, 0) = 0
						AND ATEND.REGISTRO = @REGISTRO                            						 							  
	             
	             INNER JOIN FICHAS AS PRON WITH (READPAST)
                         ON PRON.FICHA = ATEND.FICHA
								
				 INNER JOIN INTERNO_DECLARACAO_OBITO AS DOI WITH (READPAST)
								ON DOI.REGISTRO = INTER.REGISTRO						

            SELECT DISTINCT
	        ------------------------------------------------------------------------------------------------------------------------------------------------
	        ----------CHAVES--------------------------------------------------------------------------------------------------------------------------------
	        ------------------------------------------------------------------------------------------------------------------------------------------------
	        'INTERNO'                                            AS TIPO_REGISTRO,
	        DNV.REGISTRO                                         AS REGISTRO,
	        ------------------------------------------------------------------------------------------------------------------------------------------------
	        ----------DECLARACOES - OPCIONAL----------------------------------------------------------------------------------------------------------------
	        ------------------------------------------------------------------------------------------------------------------------------------------------		  		  		  
	        DNV.NUMERODECLARACAO,
	        NULL,
	        NULL,
	        NULL
	        --SELECT TOP 1 *
		    FROM EXTERNO AS ATEND WITH (READPAST)                            
                 INNER JOIN INTERNO AS INTER WITH (READPAST)
                         ON INTER.REGISTRO = ATEND.PACIENTE_INTERNO_FATURADO
                        AND ISNULL(ATEND.CANCELADO, 0) = 0
						AND ISNULL(INTER.CANCELADO, 0) = 0
						AND ATEND.REGISTRO = @REGISTRO   
						
	        	 INNER JOIN INTERNO_NASCIDOS AS DNV WITH (READPAST)
	        	        ON DNV.REGISTRO = INTER.REGISTRO
	        	        
      END	
END
go

