CREATE PROCEDURE [dbo].[SP_TISS_030200_RESUMO_INTERNACAO] @REGISTRO      VARCHAR(MAX) = NULL,
                                                  @TIPO_REGISTRO VARCHAR(MAX) = NULL,
												  @GUIA		  	 VARCHAR(MAX) = NULL,					   
												  @TIPO_FATURA   VARCHAR(MAX) = 'TOTAL',
												  @CABECALHO	  BIT = 0
AS
BEGIN
    IF @TIPO_REGISTRO = 'INTERNO' AND (@TIPO_FATURA = 'TOTAL' OR @TIPO_FATURA = 'FINAL')
		BEGIN
					SELECT DISTINCT
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------CHAVES--------------------------------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					'INTERNO'                                            AS TIPO_REGISTRO,
					ATEND.REGISTRO                                       AS REGISTRO,
					ATEND.FATURACONTA                                    AS FATURA,
					RDT.GUIAINTERNA                                      AS GUIA,
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------LOTE----------------------------------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		  
					ATEND.FATURACONTA                                    AS numeroLote,-- Número do lote  |  String  |  12  |    |  Número atribuído pelo prestador ao enviar um conjunto de guias para a operadora.  |  Obrigatório.
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------CABECALHO GUIA - OBRIGATORIO----------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		  
					RIGHT(REPLICATE('0',6) + CAST(CONV.REGISTROANS AS VARCHAR(6)),6)
															  AS cabecalhoGuiaRegistroANS,-- Registro ANS  |  String  |  6  |    |  Registro da operadora de plano privado de assistência à saúde na Agência Nacional de Saúde Suplementar (ANS)  |  Obrigatório.			
					(CASE WHEN ISNULL(CONV.TISS_INTERNACAO_TAG_NUMEROGUIAPRESTADOR,'GPRE') = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAPRESTADOR = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAPRESTADOR = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAPRESTADOR = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAPRESTADOR = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAPRESTADOR = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
					END)                                                AS cabecalhoGuiaNumeroGuiaPrestador,-- Número da guia no prestador  |  String  |  20  |    |  Número que identifica a guia no prestador de serviços.  |  "Obrigatório. É facultada às operadoras e prestadores de serviços a utilização de código de barras, impressos imediatamente abaixo da numeração. O código de barras deve seguir o padrão CODE 39 de alta densidade."
					CONV.CONVENIO									   AS CONVENIO,
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------DADOS AUTORIZACAO - OPCIONAL----------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		  			
					(CASE WHEN ISNULL(CONV.TISS_INTERNACAO_TAG_NUMEROGUIAOPERADORA,'GOPE') = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAOPERADORA = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAOPERADORA = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAOPERADORA = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAOPERADORA = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAOPERADORA = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
					END)                                                AS dadosAutorizacaoNumeroGuiaOperadora,-- Número da guia atribuído pela operadora  |  String  |  20  |    |  Número que identifica a guia atribuído pela operadora.  |  Condicionado. Deve ser preenchido caso a operadora atribua outro número à guia, independente do número que a identifica no prestador.
					ISNULL(RDT.DATA, ATEND.DATAINTERNACAO)               AS dadosAutorizacaoDataAutorizacao,-- Data da autorização  |  Date  |  8  |  DDMMAAAA  |  Data em que a autorização para realização do atendimento/procedimento foi concedida pela operadora.  |  Obrigatório.
					ISNULL(RDT.SENHA,ATEND.GUIASENHA)                    AS dadosAutorizacaoSenha,-- Senha  |  String  |  20  |    |  Senha de autorização fornecida pela operadora  |  Obrigatório.
					ATEND.VALIDADEGUIA                                   AS dadosAutorizacaoDataValidadeSenha,-- Data de validade da senha  |  Date  |  8  |  DDMMAAAA  |  Data de validade da senha de autorização do procedimento.  |  Condicionado. Deve ser preenchido em caso de autorização pela operadora com emissão de senha com prazo de validade.
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------BENEFICIARIO - OBRIGATORIO------------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		  
					DBO.FN_MASCARA_NUMERO(CAST(ISNULL(ATEND.UNIDADE, '') AS VARCHAR(5))
					+ CAST(ISNULL(ATEND.CARTEIRINHA, '') 
					AS VARCHAR(20)), CONV.TISS_NUMERO_CARTEIRA_MASCARA)  AS dadosBeneficiarioNumeroCarteira,-- Número da carteira do beneficiário  |  String  |  20  |    |  Número da carteira do beneficiário na operadora  |  Obrigatório.
					( CASE
					WHEN LEFT(PRON.NOME, 2) = 'RN' THEN 'S'
					ELSE 'N'
					END )                                              AS dadosBeneficiarioAtendimentoRN,-- Indicador de atendimento ao recém-nato  |  String  |  1  |    |  Indica se o paciente é um recém-nato que está sendo atendido no contrato do responsável, nos termos do Art. 12, inciso III, alínea a, da Lei 9.656, de 03 de junho de 1998.  |  Obrigatório.  Deve ser informado "S" - sim - caso o atendimento seja do recém-nato e o beneficiário seja o responsável e "N" - não - quando o atendimento for do próprio beneficiário.
					PRON.NOME                                            AS dadosBeneficiarioNomeBeneficiario,-- Nome do beneficiário  |  String  |  70  |    |  Nome do beneficiário  |  Obrigatório.
					PRON.CARTAOSUS                                       AS dadosBeneficiarioNumeroCNS,-- Cartão Nacional de Saúde  |  String  |  15  |    |  Número do Cartão Nacional de Saúde do beneficiário  |  Condicionado. Deve ser preenchido caso o beneficiário possua o número do Cartão Nacional de Saúde.
					NULL                                                 AS dadosBeneficiarioIdentificadorBeneficiario,-- Identificador biométrico do beneficiário  |  Binário  |    |    |  Código biométrico de identificação do beneficiário  |  Opcional.
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------DADOS DO EXECUTANTE - OBRIGATORIO-----------------------------------------------------------------------------------------------------
					-- ---------------------------------------------------------------------------------------------------------------------------------------------
					PREE.TIPO_PRESTADOR_EXECUTANTE                       AS dadosExecutanteContratadoExecutanteItemTipo,-- Campo criado para atender a situação do código do Prestador executante na operadora				
					DBO.FN_SONUMERICO(PREE.CODIGO_PRESTADOR_EXECUTANTE)  AS dadosExecutanteContratadoExecutanteItem,-- Código do contratado executante na operadora  |  String  |  14  |    |  Código na operadora ou CNPJ do prestador contratado que executou o procedimento.  |  Obrigatório.
					PREE.NOME_PRESTADOR_EXECUTANTE					   AS dadosExecutanteContratadoExecutanteNomeContratado,-- Nome do contratado executante  |  String  |  70  |    |  Razão Social, nome fantasia ou nome do prestador contratado da operadora que executou o procedimento.  |  Obrigatório.
					PAR.CNES                                             AS dadosExecutanteCNES,-- Código no Cadastro Nacional de Estabelecimentos de Saúde do executante  |  String  |  7  |    |  Código do prestador executante no Cadastro Nacional de Estabelecimentos de Saúde do Ministério da Saúde (CNES/MS)  |  Obrigatório. Caso o prestador ainda não possua o código do CNES preencher o campo com 9999999.
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------DADOS INTERNAÇÃO - OBRIGATORIO--------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		  		  
					T23.CODIGO                                           AS dadosInternacaoCaraterAtendimento,-- Caráter do atendimento  |  String  |  1  |    |  Código do caráter do atendimento, conforme tabela de domínio nº 23.  |  Obrigatório.
					T55.CODIGO                                           AS dadosInternacaoTipoFaturamento,-- Tipo de faturamento  |  String  |  1  |    |  Código do tipo do faturamento apresentado nesta guia, conforme tabela de domínio nº 55.  |  Obrigatório.
					ATEND.DATAINTERNACAO                                 AS dadosInternacaoDataInicioFaturamento,-- Data do início do faturamento  |  Date  |  8  |  DDMMAAAA  |  Data do início do faturamento apresentado nesta guia.  |  Obrigatório. Quando o tipo de faturamento for igual a 3-Complementar, preencher o campo com a data do início do faturamento da guia que está sendo complementada.
					ATEND.HORAINTERNACAO                                 AS dadosInternacaoHoraInicioFaturamento,-- Hora do início do faturamento  |  Time  |  8  |  HH:MM:SS  |  Hora do início do faturamento.  |  Obrigatório. Quando o tipo de faturamento for igual a 3-Complementar, preencher o campo com a data do início do faturamento da guia que está sendo complementada.
					ISNULL(ATEND.DATAALTA,ATEND.DATAFATURAMENTO)		   AS dadosInternacaoDataFinalFaturamento,-- Data do fim do faturamento  |  Date  |  8  |  DDMMAAAA  |  Data final do faturamento apresentado nesta guia.  |  Obrigatório. Quando o tipo de faturamento for igual a 3-Complementar, preencher o campo com a data do início do faturamento da guia que está sendo complementada.
					ISNULL(ATEND.HORAALTA,'23:59:59') 				   AS dadosInternacaoHoraFinalFaturamento,-- Hora do fim do faturamento  |  Time  |  8  |  HH:MM:SS  |  Hora do final do faturamento  |  Obrigatório. Quando o tipo de faturamento for igual a 3-Complementar, preencher o campo com a data do início do faturamento da guia que está sendo complementada.
					T57.CODIGO                                           AS dadosInternacaoTipoInternacao,-- Tipo de internação  |  String  |  1  |    |  Código do tipo de internação, conforme tabela de domínio nº 57.  |  Obrigatório.
					T41.CODIGO                                           AS dadosInternacaoRegimeInternacao,-- Regime de internação  |  String  |  1  |    |  Regime da internação de acordo com tabela de domínio nº 41.  |  Obrigatório.
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------DADOS SAIDA INTERNACAO - OBRIGATORIO--------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		  		  		  			
					-- DG.CID1 AS diagnostico, -- Diagnóstico principal  |  String  |  4  |    |  Código do diagnóstico principal de acordo com a Classificação Internacional de Doenças e de Problemas Relacionados a Saúde - 10ª revisão  |  Opcional.
					DG.CID1                                              AS dadosSaidaInternacaoDiagnostico,-- Diagnóstico principal  |  String  |  4  |    |  Código do diagnóstico principal de acordo com a Classificação Internacional de Doenças e de Problemas Relacionados a Saúde - 10ª revisão  |  Opcional.
					T36.CODIGO                                           AS dadosSaidaInternacaoIndicadorAcidente,-- Indicação de acidente ou doença relacionada  |  String  |  1  |    |  Indica se o atendimento é devido a acidente ocorrido com o beneficiário ou doença relacionada, conforme tabela de domínio nº 36.  |  Obrigatório.
					T39.CODIGO                                           AS dadosSaidaInternacaoMotivoEncerramento,-- Motivo de Encerramento  |  String  |  2  |    |  Código do motivo de encerramento da internação, conforme tabela de domínio nº 39.  |  Obrigatório.         

					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------GERAL---------------------------------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		            		  
					(CASE WHEN ISNULL(CONV.TISS_INTERNACAO_TAG_NUMEROGUIASOLICITACAOINTERNACAO,'GPRI') = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIASOLICITACAOINTERNACAO = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIASOLICITACAOINTERNACAO = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIASOLICITACAOINTERNACAO = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIASOLICITACAOINTERNACAO = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
					WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIASOLICITACAOINTERNACAO = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
					END)                                                AS numeroGuiaSolicitacaoInternacao,-- Número da guia de solicitação de internação  |  String  |  20  |    |  Número da guia de solicitação de Internação  |  Obrigatório.		  
					NULL                                                 AS observacao,-- Observação / Justificativa  |  String  |  500  |    |  Campo utilizado para adicionar quaisquer observação sobre o atendimento ou justificativas que julgue necessário  |  Opcional.
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------ASSINATURA DIGITAL - OPCIONAL---------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		            		  		  
					NULL                                                 AS assinaturaDigital -- Assinatura digital do prestador  |  Binário  |    |    |  Assinatura digital do prestador que está encaminhando a mensagem.  |  Condicionado. Deve ser preenchido quando o prestador assinar digitalmente a mensagem.			
					-- SELECT TOP 1 *
					FROM   V_RECUPERADADOSTISS AS RDT
						   CROSS JOIN PARAMETRO AS PAR WITH (READPAST)
					INNER JOIN INTERNO AS ATEND WITH (READPAST)
						 ON ATEND.REGISTRO = RDT.REGISTRO
							AND RDT.TIPOREGISTRO = 2
							AND ISNULL(ATEND.CANCELADO, 0) = 0							
							AND ATEND.REGISTRO = @REGISTRO
							AND RDT.GUIAINTERNA = @GUIA
							-- AND RDT.GUIAINTERNA = 0

					INNER JOIN FICHAS AS PRON WITH (READPAST)
						 ON PRON.FICHA = ATEND.FICHA

					INNER JOIN CONVENIOS AS CONV WITH (READPAST)
						 ON ATEND.CONVENIO = CONV.CONVENIO

					LEFT JOIN CONVENIODATA_PERIODO AS CDP WITH (READPAST)
						 ON CONV.CONVENIO = CDP.CONVENIO
							AND CDP.FATURA = ATEND.FATURACONTA

					LEFT JOIN V_TISS_REGISTROGUIA MOVIM
						 ON MOVIM.TIPOREGISTRO = RDT.TIPOREGISTRO
						AND MOVIM.REGISTRO = ATEND.REGISTRO
						AND MOVIM.GUIAINTERNA = RDT.GUIAINTERNA
						AND MOVIM.TIPOGUIA = 'H'

					LEFT JOIN DADOSGUIA AS DG WITH (READPAST)
						ON DG.REGISTRO = RDT.REGISTRO
						   AND DG.TIPOREGISTRO = RDT.TIPOREGISTRO				   

					-- EXECUTANTE
					LEFT JOIN V_TISS_PRESTADOR_EXECUTANTE PREE
						ON PREE.CONVENIO = ATEND.CONVENIO
					   AND PREE.MEDICO = ISNULL(PAR.MEDICOHOSPITAL,0)
					   AND PREE.TIPOREGISTRO = 1						

					LEFT JOIN TUSS_TAB23 AS T23 WITH (READPAST)-- CARATER DO ATENDIMENTO [1-Urgência, 2-Emergencia]
						ON T23.CODIGO = ( CASE
											WHEN ATEND.URGENCIA <> 0 THEN 1
											ELSE 2
										  END )
					LEFT JOIN TUSS_TAB36 AS T36 WITH (READPAST)-- INDICACAO DE ACIDENTE
						ON T36.CODIGO = ISNULL(ATEND.INDICACAOACIDENTE, 9)
						
					LEFT JOIN ALTAS AS ALTA WITH (READPAST)
								ON ALTA.REGISTRO = ATEND.REGISTRO
										
					LEFT JOIN TUSS_TAB39 AS T39 WITH (READPAST)-- MOTIVO DE ENCERRAMENTO
						ON T39.CODIGO = (CASE   WHEN ALTA.TIPOALTA = 1 THEN 12
												WHEN ALTA.TIPOALTA = 2 THEN 31
												WHEN ALTA.TIPOALTA = 3 THEN 41
												WHEN ALTA.TIPOALTA = 4 THEN 16
												WHEN ALTA.TIPOALTA = 5 THEN 14 
												WHEN ALTA.TIPOALTA = 6 THEN 51
												WHEN ALTA.TIPOALTA = 8 THEN 12
												ELSE 28
									 END) -- 41-Óbito com declaração de óbito fornecida pelo médico assistente 

					LEFT JOIN TUSS_TAB41 AS T41 WITH (READPAST)
						ON T41.CODIGO = (CASE WHEN DB_NAME() = 'SaveDia' THEN 2 ELSE 1 END)
					LEFT JOIN TUSS_TAB55 AS T55 WITH (READPAST)
						ON T55.CODIGO = (CASE WHEN @TIPO_FATURA = 'TOTAL' THEN 4
											  WHEN @TIPO_FATURA = 'FINAL' THEN 2
										 END) -- [1-parcial, 2-final, 3-complementar, 4-total]
					LEFT JOIN TUSS_TAB57 AS T57 WITH (READPAST)
						ON T57.CODIGO = ( CASE ISNULL(ATEND.TRATAMENTO, 0)
											WHEN 0 THEN 1
											WHEN 1 THEN 2
											WHEN 2 THEN 4
											WHEN 3 THEN 4
											WHEN 4 THEN 3
											WHEN 5 THEN 3
											ELSE 5
										  END )

					WHERE (RDT.GUIAINTERNA = 0 AND MOVIM.REGISTRO IS NOT NULL) OR @CABECALHO = 1
					/*WHERE (CASE WHEN ISNULL(CONV.TISS_RESUMO_EXPORTA_HONORARIO,0) = 0 --[0-Não exporta Honorários, 1-Exporta Honorários]
							  (CASE WHEN RDT.GUIAINTERNA = 0 THEN 1
							  ELSE 1
						)
						THEN 1
						WHEN  THEN
						1) = 1
					*/
				END
	ELSE IF @TIPO_REGISTRO = 'INTERNO' AND @TIPO_FATURA = 'PARCIAL'
		BEGIN
					SELECT DISTINCT
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------CHAVES--------------------------------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					'INTERNO'                                            AS TIPO_REGISTRO,
					ATEND.REGISTRO                                       AS REGISTRO,
					ATEND.FATURACONTA                                    AS FATURA,
					RDT.GUIAINTERNA                                      AS GUIA,
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------LOTE----------------------------------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		  
					ATEND.FATURACONTA                                    AS numeroLote,-- Número do lote  |  String  |  12  |    |  Número atribuído pelo prestador ao enviar um conjunto de guias para a operadora.  |  Obrigatório.
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------CABECALHO GUIA - OBRIGATORIO----------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		  
					RIGHT(REPLICATE('0',6) + CAST(CONV.REGISTROANS AS VARCHAR(6)),6)
																		AS cabecalhoGuiaRegistroANS,-- Registro ANS  |  String  |  6  |    |  Registro da operadora de plano privado de assistência à saúde na Agência Nacional de Saúde Suplementar (ANS)  |  Obrigatório.			
					(CASE WHEN ISNULL(CONV.TISS_INTERNACAO_TAG_NUMEROGUIAPRESTADOR,'GPRE') = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAPRESTADOR = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAPRESTADOR = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAPRESTADOR = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAPRESTADOR = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAPRESTADOR = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
					END)                                                AS cabecalhoGuiaNumeroGuiaPrestador,-- Número da guia no prestador  |  String  |  20  |    |  Número que identifica a guia no prestador de serviços.  |  "Obrigatório. É facultada às operadoras e prestadores de serviços a utilização de código de barras, impressos imediatamente abaixo da numeração. O código de barras deve seguir o padrão CODE 39 de alta densidade."
					CONV.CONVENIO									   AS CONVENIO,
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------DADOS AUTORIZACAO - OPCIONAL----------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		  			
					(CASE WHEN ISNULL(CONV.TISS_INTERNACAO_TAG_NUMEROGUIAOPERADORA,'GOPE') = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAOPERADORA = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAOPERADORA = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAOPERADORA = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAOPERADORA = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIAOPERADORA = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
					END)                                                AS dadosAutorizacaoNumeroGuiaOperadora,-- Número da guia atribuído pela operadora  |  String  |  20  |    |  Número que identifica a guia atribuído pela operadora.  |  Condicionado. Deve ser preenchido caso a operadora atribua outro número à guia, independente do número que a identifica no prestador.
					ISNULL(RDT.DATA, ATEND.DATAINTERNACAO)               AS dadosAutorizacaoDataAutorizacao,-- Data da autorização  |  Date  |  8  |  DDMMAAAA  |  Data em que a autorização para realização do atendimento/procedimento foi concedida pela operadora.  |  Obrigatório.
					ISNULL(RDT.SENHA,ATEND.GUIASENHA)                    AS dadosAutorizacaoSenha,-- Senha  |  String  |  20  |    |  Senha de autorização fornecida pela operadora  |  Obrigatório.
					ATEND.VALIDADEGUIA                                   AS dadosAutorizacaoDataValidadeSenha,-- Data de validade da senha  |  Date  |  8  |  DDMMAAAA  |  Data de validade da senha de autorização do procedimento.  |  Condicionado. Deve ser preenchido em caso de autorização pela operadora com emissão de senha com prazo de validade.
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------BENEFICIARIO - OBRIGATORIO------------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		  
					DBO.FN_MASCARA_NUMERO(CAST(ISNULL(ATEND.UNIDADE, '') AS VARCHAR(5))
					+ CAST(ISNULL(ATEND.CARTEIRINHA, '') 
					AS VARCHAR(20)), CONV.TISS_NUMERO_CARTEIRA_MASCARA) AS dadosBeneficiarioNumeroCarteira,-- Número da carteira do beneficiário  |  String  |  20  |    |  Número da carteira do beneficiário na operadora  |  Obrigatório.
					( CASE
						WHEN LEFT(PRON.NOME, 2) = 'RN' THEN 'S'
						ELSE 'N'
					END )                                              AS dadosBeneficiarioAtendimentoRN,-- Indicador de atendimento ao recém-nato  |  String  |  1  |    |  Indica se o paciente é um recém-nato que está sendo atendido no contrato do responsável, nos termos do Art. 12, inciso III, alínea a, da Lei 9.656, de 03 de junho de 1998.  |  Obrigatório.  Deve ser informado "S" - sim - caso o atendimento seja do recém-nato e o beneficiário seja o responsável e "N" - não - quando o atendimento for do próprio beneficiário.
					PRON.NOME                                            AS dadosBeneficiarioNomeBeneficiario,-- Nome do beneficiário  |  String  |  70  |    |  Nome do beneficiário  |  Obrigatório.
					PRON.CARTAOSUS                                       AS dadosBeneficiarioNumeroCNS,-- Cartão Nacional de Saúde  |  String  |  15  |    |  Número do Cartão Nacional de Saúde do beneficiário  |  Condicionado. Deve ser preenchido caso o beneficiário possua o número do Cartão Nacional de Saúde.
					NULL                                                 AS dadosBeneficiarioIdentificadorBeneficiario,-- Identificador biométrico do beneficiário  |  Binário  |    |    |  Código biométrico de identificação do beneficiário  |  Opcional.
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------DADOS DO EXECUTANTE - OBRIGATORIO-----------------------------------------------------------------------------------------------------
					-- ---------------------------------------------------------------------------------------------------------------------------------------------
					PREE.TIPO_PRESTADOR_EXECUTANTE                       AS dadosExecutanteContratadoExecutanteItemTipo,-- Campo criado para atender a situação do código do Prestador executante na operadora				
					DBO.FN_SONUMERICO(PREE.CODIGO_PRESTADOR_EXECUTANTE)  AS dadosExecutanteContratadoExecutanteItem,-- Código do contratado executante na operadora  |  String  |  14  |    |  Código na operadora ou CNPJ do prestador contratado que executou o procedimento.  |  Obrigatório.
					PREE.NOME_PRESTADOR_EXECUTANTE					   AS dadosExecutanteContratadoExecutanteNomeContratado,-- Nome do contratado executante  |  String  |  70  |    |  Razão Social, nome fantasia ou nome do prestador contratado da operadora que executou o procedimento.  |  Obrigatório.
					PAR.CNES                                             AS dadosExecutanteCNES,-- Código no Cadastro Nacional de Estabelecimentos de Saúde do executante  |  String  |  7  |    |  Código do prestador executante no Cadastro Nacional de Estabelecimentos de Saúde do Ministério da Saúde (CNES/MS)  |  Obrigatório. Caso o prestador ainda não possua o código do CNES preencher o campo com 9999999.
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------DADOS INTERNAÇÃO - OBRIGATORIO--------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		  		  
					T23.CODIGO                                           AS dadosInternacaoCaraterAtendimento,-- Caráter do atendimento  |  String  |  1  |    |  Código do caráter do atendimento, conforme tabela de domínio nº 23.  |  Obrigatório.
					T55.CODIGO                                           AS dadosInternacaoTipoFaturamento,-- Tipo de faturamento  |  String  |  1  |    |  Código do tipo do faturamento apresentado nesta guia, conforme tabela de domínio nº 55.  |  Obrigatório.
					ATEND.DATAINTERNACAO                                 AS dadosInternacaoDataInicioFaturamento,-- Data do início do faturamento  |  Date  |  8  |  DDMMAAAA  |  Data do início do faturamento apresentado nesta guia.  |  Obrigatório. Quando o tipo de faturamento for igual a 3-Complementar, preencher o campo com a data do início do faturamento da guia que está sendo complementada.
					ATEND.HORAINTERNACAO                                 AS dadosInternacaoHoraInicioFaturamento,-- Hora do início do faturamento  |  Time  |  8  |  HH:MM:SS  |  Hora do início do faturamento.  |  Obrigatório. Quando o tipo de faturamento for igual a 3-Complementar, preencher o campo com a data do início do faturamento da guia que está sendo complementada.
					ISNULL(ATEND.DATAALTA,ATEND.DATAFATURAMENTO)		   AS dadosInternacaoDataFinalFaturamento,-- Data do fim do faturamento  |  Date  |  8  |  DDMMAAAA  |  Data final do faturamento apresentado nesta guia.  |  Obrigatório. Quando o tipo de faturamento for igual a 3-Complementar, preencher o campo com a data do início do faturamento da guia que está sendo complementada.
					ISNULL(ATEND.HORAALTA,'23:59:59') 				   AS dadosInternacaoHoraFinalFaturamento,-- Hora do fim do faturamento  |  Time  |  8  |  HH:MM:SS  |  Hora do final do faturamento  |  Obrigatório. Quando o tipo de faturamento for igual a 3-Complementar, preencher o campo com a data do início do faturamento da guia que está sendo complementada.
					T57.CODIGO                                           AS dadosInternacaoTipoInternacao,-- Tipo de internação  |  String  |  1  |    |  Código do tipo de internação, conforme tabela de domínio nº 57.  |  Obrigatório.
					T41.CODIGO                                           AS dadosInternacaoRegimeInternacao,-- Regime de internação  |  String  |  1  |    |  Regime da internação de acordo com tabela de domínio nº 41.  |  Obrigatório.
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------DADOS SAIDA INTERNACAO - OBRIGATORIO--------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		  		  		  			
					-- DG.CID1 AS diagnostico, -- Diagnóstico principal  |  String  |  4  |    |  Código do diagnóstico principal de acordo com a Classificação Internacional de Doenças e de Problemas Relacionados a Saúde - 10ª revisão  |  Opcional.
					DG.CID1                                              AS dadosSaidaInternacaoDiagnostico,-- Diagnóstico principal  |  String  |  4  |    |  Código do diagnóstico principal de acordo com a Classificação Internacional de Doenças e de Problemas Relacionados a Saúde - 10ª revisão  |  Opcional.
					T36.CODIGO                                           AS dadosSaidaInternacaoIndicadorAcidente,-- Indicação de acidente ou doença relacionada  |  String  |  1  |    |  Indica se o atendimento é devido a acidente ocorrido com o beneficiário ou doença relacionada, conforme tabela de domínio nº 36.  |  Obrigatório.
					T39.CODIGO                                           AS dadosSaidaInternacaoMotivoEncerramento,-- Motivo de Encerramento  |  String  |  2  |    |  Código do motivo de encerramento da internação, conforme tabela de domínio nº 39.  |  Obrigatório.         
			  
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------GERAL---------------------------------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		            		  
					(CASE WHEN ISNULL(CONV.TISS_INTERNACAO_TAG_NUMEROGUIASOLICITACAOINTERNACAO,'GPRI') = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIASOLICITACAOINTERNACAO = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIASOLICITACAOINTERNACAO = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIASOLICITACAOINTERNACAO = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIASOLICITACAOINTERNACAO = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
						WHEN CONV.TISS_INTERNACAO_TAG_NUMEROGUIASOLICITACAOINTERNACAO = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
					END)                                                AS numeroGuiaSolicitacaoInternacao,-- Número da guia de solicitação de internação  |  String  |  20  |    |  Número da guia de solicitação de Internação  |  Obrigatório.		  
					NULL                                                 AS observacao,-- Observação / Justificativa  |  String  |  500  |    |  Campo utilizado para adicionar quaisquer observação sobre o atendimento ou justificativas que julgue necessário  |  Opcional.
					-- ----------------------------------------------------------------------------------------------------------------------------------------------
					-- --------ASSINATURA DIGITAL - OPCIONAL---------------------------------------------------------------------------------------------------------
					-- ----------------------------------------------------------------------------------------------------------------------------------------------		            		  		  
					NULL                                                 AS assinaturaDigital -- Assinatura digital do prestador  |  Binário  |    |    |  Assinatura digital do prestador que está encaminhando a mensagem.  |  Condicionado. Deve ser preenchido quando o prestador assinar digitalmente a mensagem.			
					-- SELECT TOP 1 *
					FROM   V_RECUPERADADOSTISS AS RDT
					CROSS JOIN PARAMETRO AS PAR WITH (READPAST)
					INNER JOIN EXTERNO AS ATEND WITH (READPAST)
							ON ATEND.REGISTRO = RDT.REGISTRO
							AND RDT.TIPOREGISTRO = 3
							AND ISNULL(ATEND.CANCELADO, 0) = 0
							AND ATEND.REGISTRO IN ( @REGISTRO )
							AND ATEND.REGISTRO = @REGISTRO
							AND RDT.GUIAINTERNA = @GUIA							
						
					INNER JOIN INTERNO AS INTER WITH (READPAST)
							ON INTER.REGISTRO = ATEND.PACIENTE_INTERNO_FATURADO
							AND ISNULL(INTER.CANCELADO, 0) = 0
						
					INNER JOIN FICHAS AS PRON WITH (READPAST)
							ON PRON.FICHA = ATEND.FICHA
					 
					INNER JOIN CONVENIOS AS CONV WITH (READPAST)
							ON ATEND.CONVENIO = CONV.CONVENIO
					 
					LEFT JOIN CONVENIODATA_PERIODO AS CDP WITH (READPAST)
							ON CONV.CONVENIO = CDP.CONVENIO
							AND CDP.FATURA = ATEND.FATURACONTA

					LEFT JOIN V_TISS_REGISTROGUIA MOVIM
							ON MOVIM.TIPOREGISTRO = RDT.TIPOREGISTRO
						AND MOVIM.REGISTRO = ATEND.REGISTRO
						AND MOVIM.GUIAINTERNA = RDT.GUIAINTERNA
						AND MOVIM.TIPOGUIA = 'H'
						
					LEFT JOIN DADOSGUIA AS DG WITH (READPAST)
						ON DG.REGISTRO = RDT.REGISTRO
							AND DG.TIPOREGISTRO = RDT.TIPOREGISTRO			  
			
					-- EXECUTANTE
					LEFT JOIN V_TISS_PRESTADOR_EXECUTANTE PREE
						ON PREE.CONVENIO = ATEND.CONVENIO
						AND PREE.MEDICO = ISNULL(PAR.MEDICOHOSPITAL,0)
						AND PREE.TIPOREGISTRO = 1				   
					   
					LEFT JOIN TUSS_TAB23 AS T23 WITH (READPAST)-- CARATER DO ATENDIMENTO [1-Urgência, 2-Emergencia]
						ON T23.CODIGO = ( CASE
											WHEN INTER.URGENCIA <> 0 THEN 1
											ELSE 2
											END )
					LEFT JOIN TUSS_TAB36 AS T36 WITH (READPAST)-- INDICACAO DE ACIDENTE
						ON T36.CODIGO = ISNULL(INTER.INDICACAOACIDENTE, 9)					
							
					LEFT JOIN ALTAS AS ALTA WITH (READPAST)
								ON ALTA.REGISTRO = INTER.REGISTRO
											
					LEFT JOIN TUSS_TAB39 AS T39 WITH (READPAST)-- MOTIVO DE ENCERRAMENTO
						ON T39.CODIGO = (CASE   WHEN ALTA.TIPOALTA = 1 THEN 12
												WHEN ALTA.TIPOALTA = 2 THEN 31
												WHEN ALTA.TIPOALTA = 3 THEN 41
												WHEN ALTA.TIPOALTA = 4 THEN 16
												WHEN ALTA.TIPOALTA = 5 THEN 14 
												WHEN ALTA.TIPOALTA = 6 THEN 51
												WHEN ALTA.TIPOALTA = 8 THEN 12
												ELSE 28
										END) -- 41-Óbito com declaração de óbito fornecida pelo médico assistente 
																			 
					LEFT JOIN TUSS_TAB41 AS T41 WITH (READPAST)
						ON T41.CODIGO = (CASE WHEN DB_NAME() = 'SaveDia' THEN 2 ELSE 1 END)
					LEFT JOIN TUSS_TAB55 AS T55 WITH (READPAST)
						ON T55.CODIGO = 1 -- [1-parcial, 2-final, 3-complementar, 4-total]
					LEFT JOIN TUSS_TAB57 AS T57 WITH (READPAST)
						ON T57.CODIGO = ( CASE ISNULL(INTER.TRATAMENTO, 0)
											WHEN 0 THEN 1
											WHEN 1 THEN 2
											WHEN 2 THEN 4
											WHEN 3 THEN 4
											WHEN 4 THEN 3
											WHEN 5 THEN 3
											ELSE 5
											END )

					WHERE (RDT.GUIAINTERNA = 0 AND MOVIM.REGISTRO IS NOT NULL) OR @CABECALHO = 1

					/*WHERE (CASE WHEN ISNULL(CONV.TISS_RESUMO_EXPORTA_HONORARIO,0) = 0 --[0-Não exporta Honorários, 1-Exporta Honorários]
								(CASE WHEN RDT.GUIAINTERNA = 0 THEN 1
								ELSE 1
						)
						THEN 1
						WHEN  THEN
						1) = 1
					*/
				END
				END
go

