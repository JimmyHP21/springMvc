-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spu_pres_cad_produto_item
	@id int ,
	@produto int ,
	@item int ,
	@apresentacao int ,
	@via int ,
	@atualizacao varchar(150)  = null,
	@log bigint  = null
as
begin
	set nocount on
	update dbo.pres_cad_produto_item
	set
		produto = @produto,
		item = @item,
		apresentacao = @apresentacao,
		via = @via,
		atualizacao = @atualizacao,
		log = @log
	where
		id = @id
end
go

