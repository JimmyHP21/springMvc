CREATE VIEW V_EXPORTACAOUNIMED_AMB AS 
 SELECT A.REGISTRO, B.FATURA, B.ANO, B.MES, B.CONVENIO, A.AMBUPA
 FROM   AMBULATORIAL A INNER JOIN CONVENIODATA_PERIODO B ON A.CONVENIO = B.CONVENIO
                                                         AND A.FATURACONTA = B.FATURA
                                                         AND A.DATAFATURAMENTO >= B.DATAINICIAL
                                                         AND A.DATAFATURAMENTO <= B.DATAFINAL
                                                         AND (SUBSTRING(B.TIPOFECHADO, 2, 1) = 1 AND A.AMBUPA = 1
                                                          OR  SUBSTRING(B.TIPOFECHADO, 3, 1) = 1 AND A.AMBUPA = 2)
		  INNER JOIN MOVIM_AMB C ON A.REGISTRO = C.REGISTRO AND C.HONORARIOVIDEO = 1
 GROUP BY A.REGISTRO, B.FATURA, B.ANO, B.MES, B.CONVENIO, A.AMBUPA

go

