-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_pres_cad_periodo
	@id int = null,
	@descricao varchar(255) = null,
	@hora_inicio datetime = null,
	@hora_fim datetime = null,
	@hora_padrao datetime = null,
	@cor_rotulo varchar(15) = null,
	@ordem_exibicao int = null,
	@atualizacao varchar(150) = null,
	@log bigint = null
as
begin
	set nocount on
	select
	 id, descricao, hora_inicio, hora_fim, hora_padrao, cor_rotulo, ordem_exibicao, atualizacao, log
	from dbo.pres_cad_periodo
where (id = @id or @id is null )
 and (descricao = @descricao or @descricao is null )
 and (hora_inicio = @hora_inicio or @hora_inicio is null )
 and (hora_fim = @hora_fim or @hora_fim is null )
 and (hora_padrao = @hora_padrao or @hora_padrao is null )
 and (cor_rotulo = @cor_rotulo or @cor_rotulo is null )
 and (ordem_exibicao = @ordem_exibicao or @ordem_exibicao is null )
 and (atualizacao = @atualizacao or @atualizacao is null )
 and (log = @log or @log is null )
end
go

