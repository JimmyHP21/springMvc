-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spi_pres_cad_periodo
	@id int  output,
	@descricao varchar(255) ,
	@hora_inicio datetime  = null,
	@hora_fim datetime  = null,
	@hora_padrao datetime ,
	@cor_rotulo varchar(15)  = null,
	@ordem_exibicao int  = null,
	@atualizacao varchar(150)  = null,
	@log bigint  = null
as
begin
	set nocount on
	insert into dbo.pres_cad_periodo
		( descricao, hora_inicio, hora_fim, hora_padrao, cor_rotulo, ordem_exibicao, atualizacao, log)
	values
		(@descricao,@hora_inicio,@hora_fim,@hora_padrao,@cor_rotulo,@ordem_exibicao,@atualizacao,@log)

	select @id = scope_identity()
end
go

