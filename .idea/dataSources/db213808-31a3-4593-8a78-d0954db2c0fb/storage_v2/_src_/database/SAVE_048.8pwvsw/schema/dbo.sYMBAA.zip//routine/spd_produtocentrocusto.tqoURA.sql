-- =============================================
-- author:		m2 tecnologia
-- create date:	20/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spd_produtocentrocusto
	@produto int ,
	@centrocusto smallint 
as
begin
	set nocount on
	delete from dbo.produtocentrocusto
	where
		produto = @produto
		and centrocusto = @centrocusto
end
go

