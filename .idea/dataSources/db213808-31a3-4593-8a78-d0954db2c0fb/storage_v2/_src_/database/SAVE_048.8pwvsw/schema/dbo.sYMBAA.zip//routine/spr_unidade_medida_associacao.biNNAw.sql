-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_unidade_medida_associacao
	@id int = null,
	@unidadede int = null,
	@unidadepara int = null,
	@fator money = null,
	@atualizacao varchar(150) = null,
	@log bigint = null
as
begin
	set nocount on
	select
	 id, unidadede, unidadepara, fator, atualizacao, log
	from dbo.unidade_medida_associacao
where (id = @id or @id is null )
 and (unidadede = @unidadede or @unidadede is null )
 and (unidadepara = @unidadepara or @unidadepara is null )
 and (fator = @fator or @fator is null )
 and (atualizacao = @atualizacao or @atualizacao is null )
 and (log = @log or @log is null )
end
go

