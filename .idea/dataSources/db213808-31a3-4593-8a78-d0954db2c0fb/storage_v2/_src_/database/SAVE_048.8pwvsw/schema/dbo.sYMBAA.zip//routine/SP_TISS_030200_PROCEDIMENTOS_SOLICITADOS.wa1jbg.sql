--exec SP_TISS_030200_PROCEDIMENTOS_SOLICITADOS 	277108,'URGENCIA'
CREATE PROCEDURE SP_TISS_030200_PROCEDIMENTOS_SOLICITADOS 	@REGISTRO      BIGINT = NULL,
														    @TIPOREGISTRO VARCHAR(MAX) = NULL,
														    @AUTORIZADO INT = 0,
															@GUIAINTERNA  INT = NULL
AS
      IF @TIPOREGISTRO = 'EXTERNO'
      BEGIN
          SELECT
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------PROCEDIMENTOS--------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  																		       
		  HON.TIPO_TABELA                                                                                          AS codigoTabela,
          HON.COD_TUSS                                                                                             AS codigoProcedimento,
          SUBSTRING(HON.DESC_TUSS,0,150)                                                                           AS descricaoProcedimento,
		  ISNULL(A.QUANTIDADE_AUX,1)																		       AS quantidadeSolicitada,
		  ISNULL(B.QUANTIDADEAUTORIZADA, 0)																	       AS quantidadeAutorizada																		       
          FROM  EXTERNO E WITH (NOLOCK)  
				INNER JOIN EXTERNOPROCEDIMENTO A WITH (NOLOCK) 
						ON  E.REGISTRO=A.REGISTRO 
					   AND  (@GUIAINTERNA IS NULL OR ISNULL(A.GUIAINTERNA,0) = @GUIAINTERNA)
					   
				INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                        ON E.CONVENIO = CONV.CONVENIO 

				INNER JOIN TUSS_PROCEDIMENTO AS HON ON
				 CONV.TABELAHONORARIO  = HON.TAB_CONVENIO
                 AND HON.TIPO_DESC = 'PROCEDIMENTO'
                 AND HON.COD_SAVE = A.PROCEDIMENTO
				 AND E.DATAINTERNACAO BETWEEN INICIO_VIGENCIA AND ISNULL(FIM_VIGENCIA,GETDATE())

				LEFT JOIN AUTORIZACAOPROCEDIMENTOEXTERNO B WITH (NOLOCK) 
						ON A.AUTORIZACAOPROCEDIMENTO = B.AUTORIZACAOPROCEDIMENTO  
						AND B.CANCELADA IS NULL
				 
		 WHERE A.REGISTRO = @REGISTRO
			   AND B.CANCELADA IS NULL
			   AND ISNULL(B.QUANTIDADEAUTORIZADA, 0) = (CASE WHEN @AUTORIZADO = 0 THEN @AUTORIZADO ELSE ISNULL(B.QUANTIDADEAUTORIZADA, 0) END)
      END

	  IF @TIPOREGISTRO = 'AMBULATORIAL'  OR @TIPOREGISTRO = 'URGENCIA'
      BEGIN
          SELECT
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------PROCEDIMENTOS--------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  																		       
		  HON.TIPO_TABELA                                                                                          AS codigoTabela,
          HON.COD_TUSS                                                                                             AS codigoProcedimento,
          SUBSTRING(HON.DESC_TUSS,0,150)                                                                           AS descricaoProcedimento,
		  ISNULL(A.QUANTIDADE_AUX,1)																		       AS quantidadeSolicitada,
		  ISNULL(B.QUANTIDADEAUTORIZADA, 0)																	       AS quantidadeAutorizada																	       
          FROM  AMBULATORIAL E WITH (NOLOCK)  
				INNER JOIN AMBULATORIALPROCEDIMENTO A WITH (NOLOCK) 
						ON   E.REGISTRO=A.REGISTRO 
						AND  (@GUIAINTERNA IS NULL OR ISNULL(A.GUIAINTERNA,0) = @GUIAINTERNA)
						
				INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                        ON E.CONVENIO = CONV.CONVENIO 

				INNER JOIN TUSS_PROCEDIMENTO AS HON ON
						 CONV.TABELAHONORARIO  = HON.TAB_CONVENIO
						 AND HON.TIPO_DESC = 'PROCEDIMENTO'
						 AND HON.COD_SAVE = A.PROCEDIMENTO
						 AND E.DATAINTERNACAO BETWEEN INICIO_VIGENCIA AND ISNULL(FIM_VIGENCIA,GETDATE())
						
				LEFT JOIN AUTORIZACAOPROCEDIMENTOAMBULATORIAL B WITH (NOLOCK) 
						ON A.AUTORIZACAOPROCEDIMENTO = B.AUTORIZACAOPROCEDIMENTO 
				 
		 WHERE A.REGISTRO = @REGISTRO
			   AND B.CANCELADA IS NULL		
			   AND ISNULL(B.QUANTIDADEAUTORIZADA, 0) = (CASE WHEN @AUTORIZADO = 0 THEN @AUTORIZADO ELSE ISNULL(B.QUANTIDADEAUTORIZADA, 0) END)			   
      END  

	  IF @TIPOREGISTRO = 'INTERNO'
      BEGIN
          SELECT DISTINCT
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------PROCEDIMENTOS--------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  																		       
		  HON.TIPO_TABELA                                                                                          AS codigoTabela,
          HON.COD_TUSS                                                                                             AS codigoProcedimento,
          SUBSTRING(HON.DESC_TUSS,0,150)                                                                           AS descricaoProcedimento,
		  ISNULL(A.QUANTIDADE_AUX,1)																		       AS quantidadeSolicitada,
		  ISNULL(B.QUANTIDADEAUTORIZADA, 0)																	       AS quantidadeAutorizada																		       
          FROM  INTERNO E WITH (NOLOCK)  
				INNER JOIN INTERNOPROCEDIMENTO A WITH (NOLOCK) 
						ON   E.REGISTRO=A.REGISTRO 
					   AND  (@GUIAINTERNA IS NULL OR ISNULL(A.GUIAINTERNA,0) = @GUIAINTERNA)
						
				INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                        ON E.CONVENIO = CONV.CONVENIO 
				
				INNER JOIN TUSS_PROCEDIMENTO AS HON ON
						 CONV.TABELAHONORARIO  = HON.TAB_CONVENIO
						 AND HON.TIPO_DESC = 'PROCEDIMENTO'
						 AND HON.COD_SAVE = A.PROCEDIMENTO
						 AND E.DATAINTERNACAO BETWEEN INICIO_VIGENCIA AND ISNULL(FIM_VIGENCIA,GETDATE())				
				
				LEFT JOIN AUTORIZACAOPROCEDIMENTOEXTERNO B WITH (NOLOCK) 
						ON A.AUTORIZACAOPROCEDIMENTO = B.AUTORIZACAOPROCEDIMENTO  
						AND B.CANCELADA IS NULL
				 
		 WHERE A.REGISTRO = @REGISTRO
			   AND B.CANCELADA IS NULL	
			   AND ISNULL(B.QUANTIDADEAUTORIZADA, 0) = (CASE WHEN @AUTORIZADO = 0 THEN @AUTORIZADO ELSE ISNULL(B.QUANTIDADEAUTORIZADA, 0) END)			   
      END
go

