create view [dbo].[v_relatorio_boletiminternacao] 
as 
select 
   --dados do atendimento       
   i.registro as "registro", 
   --dados do paciente  
   f.ficha as "prontuario", 
   f.nome as "paciente", 
   isnull(convert(varchar, f.nascimento, 101), '    /    /        ') as "nascimento", 
   dbo.fn_idade(f.nascimento,i.datainternacao) as "idade", 
   isnull(f.rg, '') as "rg", 
   isnull(f.cpf, '') as "cpf", 
   f.telefone as "telefone", 
   f.endereco as "endereco", 
   i.datainternacao as "internacao", 
   '' as "quarto", 
   --dados do respons?vel 
   r.responsavel as "id_resp", 
   isnull(r.nome, '') as "nome_resp", 
   '' as "endereco_resp", 
   r.parentesco as "parentesco", 
   r.profissao as "profissao_resp", 
   r.rg as "rg_resp", 
   r.cpf as "cpf_resp", 
   r.cep as "cep_resp", 
   r.telefone as "telefone_resp", 
   --dados do conv?nio 
   c.descricao as "id_convenio", 
   '' as "id_plano", 
   isnull(i.carteirinha, '') as "matricula", 
   isnull(convert(varchar, i.validade, 101), '    /    /        ') as "validade", 
   --dados do profissional 
   m.medico as "cd_medico", 
   m.crm as "crm", 
   m.nome as "nome_medico", 
   e.descricao as "especialidade" 
from fichas f 
inner join interno i on f.ficha = i.ficha 
left join responsavel r on i.responsavel = r.responsavel 
left join convenios c on i.convenio = c.convenio 
left join planoconvenio p on p.convenio = i.convenio 
   and p.plano = i.planoconveniotipo 
left join medicos m on i.medico = m.medico 
left join espmedica e on e.especmedica = m.especmedica
go

