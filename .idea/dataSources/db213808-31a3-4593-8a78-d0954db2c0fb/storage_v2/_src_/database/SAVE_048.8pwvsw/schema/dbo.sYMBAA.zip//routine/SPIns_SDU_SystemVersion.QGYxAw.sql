
-- =============================================
-- Author:		Samuel Remoardo
-- Create date:	26/08/2014
-- Description:	
-- Revisions:	
-- =============================================
Create Procedure SPIns_SDU_SystemVersion
	@idVerSystem bigint,
	@idVerSysA int,
	@idVerSysB int,
	@idVerSysC int,
	@idVerSysD int,
	@dthPublish datetime,
	@dthExecution datetime,
	@lifeTime int,
	@tolerance int
AS
Begin
	SET NOCOUNT ON
	insert into SDU_SystemVersion
		( idVerSystem, idVerSysA, idVerSysB, idVerSysC, idVerSysD, dthPublish, dthExecution,lifeTime, tolerance)
	values
		(@idVerSystem,@idVerSysA,@idVerSysB,@idVerSysC,@idVerSysD,@dthPublish,@dthExecution,@lifeTime,@tolerance)

	--select @idVerSystem = SCOPE_IDENTITY()
	select @idVerSystem
End
go

