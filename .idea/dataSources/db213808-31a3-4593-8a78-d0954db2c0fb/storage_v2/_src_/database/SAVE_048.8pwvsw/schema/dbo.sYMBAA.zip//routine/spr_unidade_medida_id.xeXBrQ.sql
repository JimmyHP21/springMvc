-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_unidade_medida_id
	@id int 
as
begin
	set nocount on
	select
	 id, descricao, atualizacao, log
	from dbo.unidade_medida
	where
		id = @id
end
go

