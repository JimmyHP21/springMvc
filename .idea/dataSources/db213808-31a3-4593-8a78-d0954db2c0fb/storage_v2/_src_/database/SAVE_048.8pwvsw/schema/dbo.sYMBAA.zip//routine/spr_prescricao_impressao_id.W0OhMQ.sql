-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_prescricao_impressao_id
	@id bigint 
as
begin
	set nocount on
	select
	 id, data_impressao, prescricao, atualizacao, log, data, usuario
	from dbo.prescricao_impressao
	where
		id = @id
end
go

