CREATE PROCEDURE [dbo].[SP_TISS_030200_HONORARIOS] @REGISTRO      BIGINT = NULL,
                                           @TIPO_REGISTRO VARCHAR(MAX) = NULL,
										   @GUIA		  		 VARCHAR(MAX) = NULL,
                                           @TIPO_FATURA   VARCHAR(MAX) = 'TOTAL',
										   @CABECALHO	  BIT = 0
AS
BEGIN
    IF @TIPO_REGISTRO = 'INTERNO' AND (@TIPO_FATURA = 'TOTAL' OR @TIPO_FATURA = 'FINAL')
      BEGIN
		  SELECT DISTINCT
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------CHAVES--------------------------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          'INTERNO'                                            AS TIPO_REGISTRO,
          ATEND.REGISTRO                                       AS REGISTRO,
          ATEND.FATURACONTA                                    AS FATURA,
          RDT.GUIAINTERNA                                      AS GUIA,

          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------LOTE----------------------------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------		  
          ATEND.FATURACONTA                                    AS numeroLote,-- Número do lote  |  String  |  12  |    |  Número atribuído pelo prestador ao enviar um conjunto de guias para a operadora.  |  Obrigatório.
		  
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------CABECALHO GUIA - OBRIGATORIO----------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          RIGHT(REPLICATE('0',6) + CAST(CONV.REGISTROANS AS VARCHAR(6)),6)
															   AS cabecalhoGuiaRegistroANS,-- Registro ANS  |  String  |  6  |    |  Registro da operadora de plano privado de assistência à saúde na Agência Nacional de Saúde Suplementar (ANS)  |  Obrigatório.			
		  (CASE WHEN ISNULL(CONV.TISS_HONORARIOS_TAG_NUMEROGUIAPRESTADOR,'GPRE') = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
		  	    WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAPRESTADOR = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAPRESTADOR = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAPRESTADOR = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAPRESTADOR = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAPRESTADOR = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
		   END)                                         	   AS cabecalhoGuiaNumeroGuiaPrestador,-- Número da guia no prestador  |  String  |  20  |    |  Número que identifica a guia no prestador de serviços.  |  "Obrigatório. É facultada às operadoras e prestadores de serviços a utilização de código de barras, impressos imediatamente abaixo da numeração. O código de barras deve seguir o padrão CODE 39 de alta densidade."
		   CONV.CONVENIO									   AS CONVENIO,
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------BENEFICIARIO - OBRIGATORIO------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------		  
          DBO.FN_MASCARA_NUMERO(CAST(ISNULL(ATEND.UNIDADE, '') AS VARCHAR(5))
          + CAST(ISNULL(ATEND.CARTEIRINHA, '') 
		  AS VARCHAR(20)), CONV.TISS_NUMERO_CARTEIRA_MASCARA) AS beneficiarioNumeroCarteira,-- Número da carteira do beneficiário  |  String  |  20  |    |  Número da carteira do beneficiário na operadora  |  Obrigatório.
          ( CASE
              WHEN LEFT(PRON.NOME, 2) = 'RN' THEN 'S'
              ELSE 'N'
            END )                                              AS beneficiarioAtendimentoRN,-- Indicador de atendimento ao recém-nato  |  String  |  1  |    |  Indica se o paciente é um recém-nato que está sendo atendido no contrato do responsável, nos termos do Art. 12, inciso III, alínea a, da Lei 9.656, de 03 de junho de 1998.  |  Obrigatório.  Deve ser informado "S" - sim - caso o atendimento seja do recém-nato e o beneficiário seja o responsável e "N" - não - quando o atendimento for do próprio beneficiário.
          PRON.NOME                                            AS beneficiarioNomeBeneficiario,-- Nome do beneficiário  |  String  |  70  |    |  Nome do beneficiário  |  Obrigatório.
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------LOCAL CONTRATADO - OBRIGATORIO--------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------			  
          PRES.TIPO_PRESTADOR_SOLICITANTE                      AS localContratadoCodigoContratadoItemTipo,-- Campo criado para atender a situação do código do Prestador executante na operadora							          
		  DBO.FN_SONUMERICO(PRES.CODIGO_PRESTADOR_SOLICITANTE) AS localContratadoCodigoContratadoItem,-- Código do contratado executante na operadora  |  String  |  14  |    |  Código na operadora ou CNPJ do prestador contratado que executou o procedimento.  |  Obrigatório.			
		  PRES.NOME_PRESTADOR_SOLICITANTE                      AS localContratadoNomeContratado,-- Nome do contratado executante  |  String  |  70  |    |  Razão Social, nome fantasia ou nome do prestador contratado da operadora que executou o procedimento.  |  Obrigatório.
          PAR.CNES                                             AS localContratadoCNES,-- Código no Cadastro Nacional de Estabelecimentos de Saúde do executante  |  String  |  7  |    |  Código do prestador executante no Cadastro Nacional de Estabelecimentos de Saúde do Ministério da Saúde (CNES/MS)  |  Obrigatório. Caso o prestador ainda não possua o código do CNES preencher o campo com 9999999.
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------DADOS DO EXECUTANTE - OBRIGATORIO-----------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------		  
  		  DBO.FN_SONUMERICO(PREE.CODIGO_PRESTADOR_EXECUTANTE)  AS dadosContratadoExecutanteCodigoNaOperadora,-- Código do contratado executante na operadora  |  String  |  14  |    |  Código na operadora ou CNPJ do prestador contratado que executou o procedimento.  |  Obrigatório.
		  PREE.NOME_PRESTADOR_EXECUTANTE                       AS dadosContratadoExecutanteNomeContratadoExecutante,-- Nome do contratado executante  |  String  |  70  |    |  Razão Social, nome fantasia ou nome do prestador contratado da operadora que executou o procedimento.  |  Obrigatório.
          PAR.CNES                                             AS dadosContratadoExecutanteCnesContratadoExecutante,-- Código no Cadastro Nacional de Estabelecimentos de Saúde do executante  |  String  |  7  |    |  Código do prestador executante no Cadastro Nacional de Estabelecimentos de Saúde do Ministério da Saúde (CNES/MS)  |  Obrigatório. Caso o prestador ainda não possua o código do CNES preencher o campo com 9999999.
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------DADOS INTERNACAO----------------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------		  		  
          CONVERT(VARCHAR, ATEND.DATAINTERNACAO, 103)           AS dadosInternacaoDataInicioFaturamento,
          CONVERT(VARCHAR, ATEND.DATAALTA, 103)                 AS dadosInternacaoDataFimFaturamento,
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------PROCEDIMENTOS EXECUTADOS - OPCIONAL---------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------			  		  
          -- --------SP_TISS_030200_PROCEDIMENTO_REALIZADO-------------------------------------------------------------------------------------------------          
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------PROFISSIONAIS-------------------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------			  
          -- --------SP_TISS_030200_PROFISSIONAIS----------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------GERAL---------------------------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------			  		  
		  (CASE WHEN ISNULL(CONV.TISS_HONORARIOS_TAG_GUIASOLICINTERNACAO,'GPRI') = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
				WHEN CONV.TISS_HONORARIOS_TAG_GUIASOLICINTERNACAO = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
				WHEN CONV.TISS_HONORARIOS_TAG_GUIASOLICINTERNACAO = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
				WHEN CONV.TISS_HONORARIOS_TAG_GUIASOLICINTERNACAO = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
				WHEN CONV.TISS_HONORARIOS_TAG_GUIASOLICINTERNACAO = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
				WHEN CONV.TISS_HONORARIOS_TAG_GUIASOLICINTERNACAO = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
		   END)                                                AS guiaSolicInternacao,-- Número da guia de solicitação de internação  |  String  |  20  |    |  Número da guia de solicitação de Internação  |  Obrigatório.         
          ISNULL(RDT.SENHA,ATEND.GUIASENHA)                    AS senha,-- Senha  |  String  |  20  |    |  Senha de autorização fornecida pela operadora  |  Obrigatório.			
		   (CASE WHEN ISNULL(CONV.TISS_HONORARIOS_TAG_NUMEROGUIAOPERADORA,'GOPE') = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAOPERADORA = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAOPERADORA = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAOPERADORA = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAOPERADORA = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAOPERADORA = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
		   END)                                                AS numeroGuiaOperadora,-- Número da guia atribuído pela operadora  |  String  |  20  |    |  Número que identifica a guia atribuído pela operadora.  |  Condicionado. Deve ser preenchido caso a operadora atribua outro número à guia, independente do número que a identifica no prestador.		  
          0                                                    AS valorTotalHonorarios,-- Valor do total geral  |  Numérico  |  8,2  |    |  Somatório de todos os valores totais de procedimentos realizados e itens assistenciais utilizados  |  Obrigatório.
          ISNULL(DG.DATA,ATEND.DATAINTERNACAO)                 AS dataEmissaoGuia,
          NULL                                                 AS observacao,-- Observação / Justificativa  |  String  |  500  |    |  Campo utilizado para adicionar quaisquer observação sobre o atendimento ou justificativas que julgue necessário  |  Opcional.

          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------ASSINATURA DIGITAL - OPCIONAL---------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------		            		  		            
		  NULL                                                 AS assinaturaDigital -- Assinatura digital do prestador  |  Binário  |    |    |  Assinatura digital do prestador que está encaminhando a mensagem.  |  Condicionado. Deve ser preenchido quando o prestador assinar digitalmente a mensagem.			
          -- SELECT TOP 1 *
          FROM   V_RECUPERADADOSTISS AS RDT 
								 CROSS JOIN PARAMETRO AS PAR WITH (READPAST)
                 INNER JOIN INTERNO AS ATEND WITH (READPAST)
                         ON ATEND.REGISTRO = RDT.REGISTRO
                            AND RDT.TIPOREGISTRO = 2
                            AND ISNULL(ATEND.CANCELADO, 0) = 0
                            AND RDT.TIPOGUIA = CASE WHEN @CABECALHO = 0 THEN 1 ELSE 0 END
							AND ATEND.REGISTRO = @REGISTRO
							AND RDT.GUIAINTERNA = @GUIA
							
                 INNER JOIN FICHAS AS PRON WITH (READPAST)
                         ON PRON.FICHA = ATEND.FICHA
						 
                 INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                         ON ATEND.CONVENIO = CONV.CONVENIO
						
                 LEFT JOIN CONVENIODATA_PERIODO AS CDP WITH (READPAST)
                         ON CONV.CONVENIO = CDP.CONVENIO
                            AND CDP.FATURA = ATEND.FATURACONTA

                 LEFT JOIN MOVIM_INT AS MOVIM WITH (READPAST)
                        ON MOVIM.REGISTRO = ATEND.REGISTRO
                           AND (MOVIM.QUANTIDADE) > 0
                           AND MOVIM.TIPOLANCAMENTO = 3
                           AND RDT.GUIAINTERNA = ISNULL(MOVIM.GUIAINTERNA,0)
						   AND MOVIM.TIPOGUIA = ''
						   
				 LEFT JOIN DADOSGUIA AS DG WITH (READPAST)
                        ON DG.REGISTRO = RDT.REGISTRO
                           AND DG.TIPOREGISTRO = RDT.TIPOREGISTRO
						   	   
				 LEFT JOIN V_TISS_PRESTADOR_SOLICITANTE PRES
						ON PRES.CONVENIO = ATEND.CONVENIO
					   AND PRES.MEDICO = ISNULL(PAR.MEDICOHOSPITAL,0)
					   AND PRES.TIPOREGISTRO = 1
						
                 LEFT JOIN MEDICOS AS MEXEC WITH (READPAST)
                        ON MEXEC.MEDICO = RDT.MEDICO
						
				 LEFT JOIN V_TISS_PRESTADOR_EXECUTANTE PREE
						ON PREE.CONVENIO = ATEND.CONVENIO
					   AND PREE.MEDICO = ISNULL(MEXEC.MEDICO,ISNULL(PAR.MEDICOHOSPITAL,0))
					   AND PREE.TIPOREGISTRO = 1						   

                 LEFT JOIN TUSS_TAB23 AS T23 WITH (READPAST)-- CARATER DO ATENDIMENTO [1-Urgência, 2-Emergencia]
                        ON T23.CODIGO = ( CASE
                                            WHEN ATEND.URGENCIA <> 0 THEN 1
                                            ELSE 2
                                          END )
										  
                 LEFT JOIN TUSS_TAB36 AS T36 WITH (READPAST)-- INDICACAO DE ACIDENTE
                        ON T36.CODIGO = ISNULL(ATEND.INDICACAOACIDENTE, 9)
												
								 LEFT JOIN ALTAS AS E WITH (READPAST)
								 				ON E.REGISTRO = ATEND.REGISTRO
												
                 LEFT JOIN TUSS_TAB39 AS T39 WITH (READPAST)-- MOTIVO DE ENCERRAMENTO
                        ON T39.CODIGO = (CASE WHEN E.TIPOALTA = 1 THEN 12
																							WHEN E.TIPOALTA = 2 THEN 31
																							WHEN E.TIPOALTA = 3 THEN 41
																							WHEN E.TIPOALTA = 4 THEN 16
																							WHEN E.TIPOALTA = 5 THEN 14 
																							WHEN E.TIPOALTA = 6 THEN 51
																							WHEN E.TIPOALTA = 8 THEN 12
																							ELSE 28
																				 END) -- 41-Óbito com declaração de óbito fornecida pelo médico assistente 
																				 
                 LEFT JOIN TUSS_TAB41 AS T41 WITH (READPAST)
                        ON T41.CODIGO = 1
                 LEFT JOIN TUSS_TAB55 AS T55 WITH (READPAST)
                        ON T55.CODIGO = 4
                 LEFT JOIN TUSS_TAB57 AS T57 WITH (READPAST)
                        ON T57.CODIGO = ( CASE ISNULL(ATEND.TRATAMENTO, 0)
                                            WHEN 0 THEN 1
                                            WHEN 1 THEN 2
                                            WHEN 2 THEN 4
                                            WHEN 3 THEN 4
                                            WHEN 4 THEN 3
                                            WHEN 5 THEN 3
                                            ELSE 5
                                          END )
                 LEFT JOIN INTERNO_NASCIDOS AS DNV WITH (READPAST)
                        ON ATEND.REGISTRO = DNV.REGISTRO
						
				WHERE MOVIM.SEQUENCIA IS NOT NULL OR @CABECALHO = 1
				
			END
	  ELSE IF @TIPO_REGISTRO = 'INTERNO' AND @TIPO_FATURA = 'PARCIAL'
      BEGIN
          SELECT DISTINCT
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------CHAVES--------------------------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          'INTERNO'                                            AS TIPO_REGISTRO,
          ATEND.REGISTRO                                       AS REGISTRO,
          ATEND.FATURACONTA                                    AS FATURA,
          RDT.GUIAINTERNA                                      AS GUIA,

          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------LOTE----------------------------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------		  
          ATEND.FATURACONTA                                    AS numeroLote,-- Número do lote  |  String  |  12  |    |  Número atribuído pelo prestador ao enviar um conjunto de guias para a operadora.  |  Obrigatório.
		  
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------CABECALHO GUIA - OBRIGATORIO----------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          RIGHT(REPLICATE('0',6) + CAST(CONV.REGISTROANS AS VARCHAR(6)),6)
															   AS cabecalhoGuiaRegistroANS,-- Registro ANS  |  String  |  6  |    |  Registro da operadora de plano privado de assistência à saúde na Agência Nacional de Saúde Suplementar (ANS)  |  Obrigatório.			
		  (CASE WHEN ISNULL(CONV.TISS_HONORARIOS_TAG_NUMEROGUIAPRESTADOR,'GPRE') = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
		  	    WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAPRESTADOR = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAPRESTADOR = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAPRESTADOR = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAPRESTADOR = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAPRESTADOR = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
		   END)                                         	   AS cabecalhoGuiaNumeroGuiaPrestador,-- Número da guia no prestador  |  String  |  20  |    |  Número que identifica a guia no prestador de serviços.  |  "Obrigatório. É facultada às operadoras e prestadores de serviços a utilização de código de barras, impressos imediatamente abaixo da numeração. O código de barras deve seguir o padrão CODE 39 de alta densidade."
		   CONV.CONVENIO									   AS CONVENIO,
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------BENEFICIARIO - OBRIGATORIO------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------		  
          DBO.FN_MASCARA_NUMERO(CAST(ISNULL(ATEND.UNIDADE, '') AS VARCHAR(5))
          + CAST(ISNULL(ATEND.CARTEIRINHA, '') 
		  AS VARCHAR(20)), CONV.TISS_NUMERO_CARTEIRA_MASCARA) AS beneficiarioNumeroCarteira,-- Número da carteira do beneficiário  |  String  |  20  |    |  Número da carteira do beneficiário na operadora  |  Obrigatório.
          ( CASE
              WHEN LEFT(PRON.NOME, 2) = 'RN' THEN 'S'
              ELSE 'N'
            END )                                              AS beneficiarioAtendimentoRN,-- Indicador de atendimento ao recém-nato  |  String  |  1  |    |  Indica se o paciente é um recém-nato que está sendo atendido no contrato do responsável, nos termos do Art. 12, inciso III, alínea a, da Lei 9.656, de 03 de junho de 1998.  |  Obrigatório.  Deve ser informado "S" - sim - caso o atendimento seja do recém-nato e o beneficiário seja o responsável e "N" - não - quando o atendimento for do próprio beneficiário.
          PRON.NOME                                            AS beneficiarioNomeBeneficiario,-- Nome do beneficiário  |  String  |  70  |    |  Nome do beneficiário  |  Obrigatório.
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------LOCAL CONTRATADO - OBRIGATORIO--------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------			  
          PRES.TIPO_PRESTADOR_SOLICITANTE                      AS localContratadoCodigoContratadoItemTipo,-- Campo criado para atender a situação do código do Prestador executante na operadora							          
		  DBO.FN_SONUMERICO(PRES.CODIGO_PRESTADOR_SOLICITANTE) AS localContratadoCodigoContratadoItem,-- Código do contratado executante na operadora  |  String  |  14  |    |  Código na operadora ou CNPJ do prestador contratado que executou o procedimento.  |  Obrigatório.			
		  PRES.NOME_PRESTADOR_SOLICITANTE                      AS localContratadoNomeContratado,--Nome do contratado executante  |  String  |  70  |    |  Razão Social, nome fantasia ou nome do prestador contratado da operadora que executou o procedimento.  |  Obrigatório.                                              AS localContratadoCodigoContratadoItemTipo,-- Campo criado para atender a situação do código do Prestador executante na operadora							          
          PAR.CNES                                             AS localContratadoCNES,-- Código no Cadastro Nacional de Estabelecimentos de Saúde do executante  |  String  |  7  |    |  Código do prestador executante no Cadastro Nacional de Estabelecimentos de Saúde do Ministério da Saúde (CNES/MS)  |  Obrigatório. Caso o prestador ainda não possua o código do CNES preencher o campo com 9999999.
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------DADOS DO EXECUTANTE - OBRIGATORIO-----------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------		  
  		  DBO.FN_SONUMERICO(PREE.CODIGO_PRESTADOR_EXECUTANTE)  AS dadosContratadoExecutanteCodigoNaOperadora,-- Código do contratado executante na operadora  |  String  |  14  |    |  Código na operadora ou CNPJ do prestador contratado que executou o procedimento.  |  Obrigatório.
		  PREE.NOME_PRESTADOR_EXECUTANTE                       AS dadosContratadoExecutanteNomeContratadoExecutante,-- Nome do contratado executante  |  String  |  70  |    |  Razão Social, nome fantasia ou nome do prestador contratado da operadora que executou o procedimento.  | 
          PAR.CNES                                             AS dadosContratadoExecutanteCnesContratadoExecutante,-- Código no Cadastro Nacional de Estabelecimentos de Saúde do executante  |  String  |  7  |    |  Código do prestador executante no Cadastro Nacional de Estabelecimentos de Saúde do Ministério da Saúde (CNES/MS)  |  Obrigatório. Caso o prestador ainda não possua o código do CNES preencher o campo com 9999999.
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------DADOS INTERNACAO----------------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------		  		  
          CONVERT(VARCHAR, ATEND.DATAINTERNACAO, 103)          AS dadosInternacaoDataInicioFaturamento,
          CONVERT(VARCHAR, ATEND.DATAFATURAMENTO, 103)         AS dadosInternacaoDataFimFaturamento,
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------PROCEDIMENTOS EXECUTADOS - OPCIONAL---------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------			  		  
          -- --------SP_TISS_030200_PROCEDIMENTO_REALIZADO-------------------------------------------------------------------------------------------------          
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------PROFISSIONAIS-------------------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------			  
          -- --------SP_TISS_030200_PROFISSIONAIS----------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------GERAL---------------------------------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------			  		  
		  (CASE WHEN ISNULL(CONV.TISS_HONORARIOS_TAG_GUIASOLICINTERNACAO,'GPRI') = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
				WHEN CONV.TISS_HONORARIOS_TAG_GUIASOLICINTERNACAO = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
				WHEN CONV.TISS_HONORARIOS_TAG_GUIASOLICINTERNACAO = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
				WHEN CONV.TISS_HONORARIOS_TAG_GUIASOLICINTERNACAO = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
				WHEN CONV.TISS_HONORARIOS_TAG_GUIASOLICINTERNACAO = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
				WHEN CONV.TISS_HONORARIOS_TAG_GUIASOLICINTERNACAO = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
		   END)                                                AS guiaSolicInternacao,-- Número da guia de solicitação de internação  |  String  |  20  |    |  Número da guia de solicitação de Internação  |  Obrigatório.         
          ISNULL(RDT.SENHA,ATEND.GUIASENHA)                    AS senha,-- Senha  |  String  |  20  |    |  Senha de autorização fornecida pela operadora  |  Obrigatório.			
		   (CASE WHEN ISNULL(CONV.TISS_HONORARIOS_TAG_NUMEROGUIAOPERADORA,'GOPE') = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAOPERADORA = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAOPERADORA = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAOPERADORA = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAOPERADORA = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
				WHEN CONV.TISS_HONORARIOS_TAG_NUMEROGUIAOPERADORA = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
		   END)                                                AS numeroGuiaOperadora,-- Número da guia atribuído pela operadora  |  String  |  20  |    |  Número que identifica a guia atribuído pela operadora.  |  Condicionado. Deve ser preenchido caso a operadora atribua outro número à guia, independente do número que a identifica no prestador.		  
          0                                                    AS valorTotalHonorarios,-- Valor do total geral  |  Numérico  |  8,2  |    |  Somatório de todos os valores totais de procedimentos realizados e itens assistenciais utilizados  |  Obrigatório.
          ISNULL(DG.DATA,INTER.DATAINTERNACAO)                 AS dataEmissaoGuia,
          NULL                                                 AS observacao,-- Observação / Justificativa  |  String  |  500  |    |  Campo utilizado para adicionar quaisquer observação sobre o atendimento ou justificativas que julgue necessário  |  Opcional.

          -- ----------------------------------------------------------------------------------------------------------------------------------------------
          -- --------ASSINATURA DIGITAL - OPCIONAL---------------------------------------------------------------------------------------------------------
          -- ----------------------------------------------------------------------------------------------------------------------------------------------		            		  		            
		  NULL                                                 AS assinaturaDigital -- Assinatura digital do prestador  |  Binário  |    |    |  Assinatura digital do prestador que está encaminhando a mensagem.  |  Condicionado. Deve ser preenchido quando o prestador assinar digitalmente a mensagem.			
          -- SELECT TOP 1 *
          FROM   V_RECUPERADADOSTISS AS RDT
                 CROSS JOIN PARAMETRO AS PAR WITH (READPAST)					
                 INNER JOIN EXTERNO AS ATEND WITH (READPAST)
                         ON ATEND.REGISTRO = RDT.REGISTRO
                            AND RDT.TIPOREGISTRO = 3
                            AND ISNULL(ATEND.CANCELADO, 0) = 0
                            AND RDT.TIPOGUIA = CASE WHEN @CABECALHO = 0 THEN 1 ELSE 0 END
							AND ATEND.REGISTRO = @REGISTRO
							AND RDT.GUIAINTERNA = @GUIA
							
                 INNER JOIN INTERNO AS INTER WITH (READPAST)
                         ON INTER.REGISTRO = ATEND.PACIENTE_INTERNO_FATURADO
                            AND ISNULL(INTER.CANCELADO, 0) = 0
							
                 INNER JOIN FICHAS AS PRON WITH (READPAST)
                         ON PRON.FICHA = ATEND.FICHA
						 
                 INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                         ON ATEND.CONVENIO = CONV.CONVENIO
						
                 LEFT JOIN CONVENIODATA_PERIODO AS CDP WITH (READPAST)
                         ON CONV.CONVENIO = CDP.CONVENIO
                            AND CDP.FATURA = ATEND.FATURACONTA

                 LEFT JOIN MOVIM_EXT AS MOVIM WITH (READPAST)
                        ON MOVIM.REGISTRO = ATEND.REGISTRO
                           AND (MOVIM.QUANTIDADE) > 0
                           AND MOVIM.TIPOLANCAMENTO = 3
                           AND RDT.GUIAINTERNA = ISNULL(MOVIM.GUIAINTERNA,0)	
						   						 AND MOVIM.TIPOGUIA = ''
						   
				 LEFT JOIN DADOSGUIA AS DG WITH (READPAST)
                        ON DG.REGISTRO = RDT.REGISTRO
                           AND DG.TIPOREGISTRO = RDT.TIPOREGISTRO
						   
				 LEFT JOIN V_TISS_PRESTADOR_SOLICITANTE PRES
						ON PRES.CONVENIO = ATEND.CONVENIO
					   AND PRES.MEDICO = ISNULL(PAR.MEDICOHOSPITAL,0)
					   AND PRES.TIPOREGISTRO = 1
						
                 LEFT JOIN MEDICOS AS MEXEC WITH (READPAST)
                        ON MEXEC.MEDICO = RDT.MEDICO
						
				 LEFT JOIN V_TISS_PRESTADOR_EXECUTANTE PREE
						ON PREE.CONVENIO = ATEND.CONVENIO
					   AND PREE.MEDICO = ISNULL(MEXEC.MEDICO,ISNULL(PAR.MEDICOHOSPITAL,0))
					   AND PREE.TIPOREGISTRO = 1	

                 LEFT JOIN TUSS_TAB23 AS T23 WITH (READPAST)-- CARATER DO ATENDIMENTO [1-Urgência, 2-Emergencia]
                        ON T23.CODIGO = ( CASE
                                            WHEN INTER.URGENCIA <> 0 THEN 1
                                            ELSE 2
                                          END )
										  
                 LEFT JOIN TUSS_TAB36 AS T36 WITH (READPAST)-- INDICACAO DE ACIDENTE
                        ON T36.CODIGO = ISNULL(INTER.INDICACAOACIDENTE, 9)
												
								 LEFT JOIN ALTAS AS E WITH (READPAST)
								 				ON E.REGISTRO = INTER.REGISTRO
												
                 LEFT JOIN TUSS_TAB39 AS T39 WITH (READPAST)-- MOTIVO DE ENCERRAMENTO
                        ON T39.CODIGO = (CASE WHEN E.TIPOALTA = 1 THEN 12
																							WHEN E.TIPOALTA = 2 THEN 31
																							WHEN E.TIPOALTA = 3 THEN 41
																							WHEN E.TIPOALTA = 4 THEN 16
																							WHEN E.TIPOALTA = 5 THEN 14 
																							WHEN E.TIPOALTA = 6 THEN 51
																							WHEN E.TIPOALTA = 8 THEN 12
																							ELSE 28
																				 END) -- 41-Óbito com declaração de óbito fornecida pelo médico assistente 
																				 
                 LEFT JOIN TUSS_TAB41 AS T41 WITH (READPAST)
                        ON T41.CODIGO = 1
                 LEFT JOIN TUSS_TAB55 AS T55 WITH (READPAST)
                        ON T55.CODIGO = 4
                 LEFT JOIN TUSS_TAB57 AS T57 WITH (READPAST)
                        ON T57.CODIGO = ( CASE ISNULL(INTER.TRATAMENTO, 0)
                                            WHEN 0 THEN 1
                                            WHEN 1 THEN 2
                                            WHEN 2 THEN 4
                                            WHEN 3 THEN 4
                                            WHEN 4 THEN 3
                                            WHEN 5 THEN 3
                                            ELSE 5
                                          END )
                 LEFT JOIN INTERNO_NASCIDOS AS DNV WITH (READPAST)
                        ON INTER.REGISTRO = DNV.REGISTRO
						
				WHERE MOVIM.SEQUENCIA IS NOT NULL OR @CABECALHO = 1
      END 
END
go

