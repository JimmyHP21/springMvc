CREATE PROCEDURE SP_COPIAR_PRESCRICAO        @REGISTRO_ATENDIMENTO    BIGINT    =  NULL,
                                           @PRESCRICAO              BIGINT    =  NULL,
                                           @USUARIOINCLUSAO         INT       =  NULL,
                                           @CICLOS                  INT       =  NULL,
                                           @CENTROCUSTO_INTERNADO   INT       =  NULL,
                                           @REPETIR_EXAMES          INT       =  1,
                                           @TIPOATENDIMENTO        VARCHAR(3) =  'INT'
AS
DECLARE @PRESCRICAO_NOVA   BIGINT; 
EXEC SP_REPETIR_PRESCRICAO  @REGISTRO_ATENDIMENTO,  @PRESCRICAO, @USUARIOINCLUSAO,@CICLOS,@CENTROCUSTO_INTERNADO, @REPETIR_EXAMES,@TIPOATENDIMENTO,@PRESCRICAO_NOVA  OUTPUT
SELECT @PRESCRICAO_NOVA AS PRESCRICAO_NOVA
go

