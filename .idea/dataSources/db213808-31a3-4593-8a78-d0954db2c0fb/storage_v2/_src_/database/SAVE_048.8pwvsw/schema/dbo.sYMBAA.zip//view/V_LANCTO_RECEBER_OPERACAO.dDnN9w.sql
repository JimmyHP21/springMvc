

 /****** Object:  View [dbo].[V_LANCTO_RECEBER_OPERACAO]    Script Date: 03/03/2016 14:41:09 ******/                                                                                              
 CREATE VIEW [dbo].[V_LANCTO_RECEBER_OPERACAO] AS                                                                                                                                                 
        SELECT
			'CON' AS TIPOPES
			, 'D' AS OPERACAO
            , A.CODIGO                                                                                                                                                                   
            , B.DESCRICAO                                                                                                                                                                
            , A.DATAEMISSAO                                                                                                                                                              
            , A.DATALANCAMENTO                                                                                                                                                           
            , A.LANCAMENTO                                                                                                                                                               
            , A.DOCUMENTO                                                                                                                                                                
            , A.TIPO                                                                                                                                                                     
            , A.VALORTOTAL                                                                                                                                                               
            , C.DATAVENCIMENTO
            , C.VALORVENCIMENTO                                                                                                                                                          
            , NULL AS DATARECEBIMENTO
            , 0 AS VALORRECEBIMENTO
            , 0 AS VALORADIANTAMENTOPACIENTE
        FROM FILANCAMENTORECEBIMENTO A INNER JOIN CONVENIOS                         B ON A.CODIGO = B.CONVENIO
																					  AND A.TIPO = 1
                                       LEFT  JOIN FILANCAMENTORECEBIMENTOVENCIMENTO C ON A.LANCAMENTO     = C.LANCAMENTO

 UNION

         SELECT
			'CON' AS TIPOPES
			, 'C' AS OPERACAO
            , A.CODIGO                                                                                                                                                                   
            , B.DESCRICAO                                                                                                                                                                
            , A.DATAEMISSAO                                                                                                                                                              
            , A.DATALANCAMENTO                                                                                                                                                           
            , A.LANCAMENTO                                                                                                                                                               
            , A.DOCUMENTO                                                                                                                                                                
            , A.TIPO                                                                                                                                                                     
            , A.VALORTOTAL                                                                                                                                                               
            , C.DATAVENCIMENTO
            , 0 AS VALORVENCIMENTO
            , D.DATARECEBIMENTO
            , D.VALORRECEBIMENTO
            , D.VALORADIANTAMENTOPACIENTE
        FROM FILANCAMENTORECEBIMENTO A INNER JOIN CONVENIOS                         B ON A.CODIGO = B.CONVENIO
																					  AND A.TIPO = 1
                                       LEFT  JOIN FILANCAMENTORECEBIMENTOVENCIMENTO C ON A.LANCAMENTO     = C.LANCAMENTO
                                       LEFT  JOIN FILANCAMENTORECEBIMENTORECEBIDO   D ON A.LANCAMENTO     = D.LANCAMENTO
                                                                                     AND C.DATAVENCIMENTO = D.DATAVENCIMENTO
                                                                                                                                                                                         
                                                                                                                                                                                         
 UNION                                                                                                                                                                                   
        SELECT
			'AMB' AS TIPOPES
			, 'D' AS OPERACAO
            , A.CODIGO                                                                                                                                                                   
            , F.NOME DESCRICAO                                                                                                                                                           
            , A.DATAEMISSAO                                                                                                                                                              
            , A.DATALANCAMENTO                                                                                                                                                           
            , A.LANCAMENTO                                                                                                                                                               
            , A.DOCUMENTO                                                                                                                                                                
            , A.TIPO                                                                                                                                                                     
            , A.VALORTOTAL                                                                                                                                                               
            , C.DATAVENCIMENTO                                                                                                                                                           
            , C.VALORVENCIMENTO                                                                                                                                                          
            , NULL AS DATARECEBIMENTO
            , 0	AS VALORRECEBIMENTO
            , 0	AS VALORADIANTAMENTOPACIENTE
        FROM FILANCAMENTORECEBIMENTO A          INNER JOIN AMBULATORIAL                      B ON A.CODIGO = B.REGISTRO
																								AND A.TIPO = 0
																								AND AMBUPA = 1
                                                INNER JOIN FICHAS                            F ON B.FICHA = F.FICHA
                                                LEFT  JOIN FILANCAMENTORECEBIMENTOVENCIMENTO C ON A.LANCAMENTO     = C.LANCAMENTO

 UNION                                                                                                                                                                                   
        SELECT
			'AMB' AS TIPOPES
			, 'C' AS OPERACAO
            , A.CODIGO                                                                                                                                                                   
            , F.NOME DESCRICAO                                                                                                                                                           
            , A.DATAEMISSAO                                                                                                                                                              
            , A.DATALANCAMENTO                                                                                                                                                           
            , A.LANCAMENTO                                                                                                                                                               
            , A.DOCUMENTO                                                                                                                                                                
            , A.TIPO                                                                                                                                                                     
            , A.VALORTOTAL                                                                                                                                                               
            , C.DATAVENCIMENTO
            , 0	AS VALORVENCIMENTO
            , D.DATARECEBIMENTO                                                                                                                                                          
            , D.VALORRECEBIMENTO                                                                                                                                                         
            , D.VALORADIANTAMENTOPACIENTE                                                                                                                                                
        FROM FILANCAMENTORECEBIMENTO A          INNER JOIN AMBULATORIAL                      B ON A.CODIGO = B.REGISTRO
																								AND A.TIPO = 0
																								AND AMBUPA = 1
                                                INNER JOIN FICHAS                            F ON B.FICHA = F.FICHA
                                                LEFT  JOIN FILANCAMENTORECEBIMENTOVENCIMENTO C ON A.LANCAMENTO     = C.LANCAMENTO
                                                LEFT  JOIN FILANCAMENTORECEBIMENTORECEBIDO   D ON A.LANCAMENTO     = D.LANCAMENTO
                                                                                              AND C.DATAVENCIMENTO = D.DATAVENCIMENTO

 UNION
        SELECT
			'URG' AS TIPOPES
			, 'D' AS OPERACAO
            , A.CODIGO                                                                                                                                                                   
            , F.NOME DESCRICAO                                                                                                                                                           
            , A.DATAEMISSAO                                                                                                                                                              
            , A.DATALANCAMENTO                                                                                                                                                           
            , A.LANCAMENTO                                                                                                                                                               
            , A.DOCUMENTO                                                                                                                                                                
            , A.TIPO                                                                                                                                                                     
            , A.VALORTOTAL                                                                                                                                                               
            , C.DATAVENCIMENTO                                                                                                                                                           
            , C.VALORVENCIMENTO                                                                                                                                                          
            , NULL AS DATARECEBIMENTO
            , 0 AS VALORRECEBIMENTO
            , 0 AS VALORADIANTAMENTOPACIENTE
        FROM FILANCAMENTORECEBIMENTO A          INNER JOIN AMBULATORIAL                      B ON A.CODIGO = B.REGISTRO
																								AND A.TIPO = 0
																								AND B.AMBUPA = 2
                                                INNER JOIN FICHAS                            F ON B.FICHA = F.FICHA
                                                LEFT  JOIN FILANCAMENTORECEBIMENTOVENCIMENTO C ON A.LANCAMENTO     = C.LANCAMENTO

 UNION
        SELECT
			'URG' AS TIPOPES
			, 'C' AS OPERACAO
            , A.CODIGO                                                                                                                                                                   
            , F.NOME DESCRICAO                                                                                                                                                           
            , A.DATAEMISSAO                                                                                                                                                              
            , A.DATALANCAMENTO                                                                                                                                                           
            , A.LANCAMENTO                                                                                                                                                               
            , A.DOCUMENTO                                                                                                                                                                
            , A.TIPO                                                                                                                                                                     
            , A.VALORTOTAL                                                                                                                                                               
            , C.DATAVENCIMENTO
            , 0	AS VALORVENCIMENTO
            , D.DATARECEBIMENTO                                                                                                                                                          
            , D.VALORRECEBIMENTO                                                                                                                                                         
            , D.VALORADIANTAMENTOPACIENTE                                                                                                                                                
        FROM FILANCAMENTORECEBIMENTO A          INNER JOIN AMBULATORIAL                      B ON A.CODIGO = B.REGISTRO
																								AND A.TIPO = 0
																								AND B.AMBUPA = 2
                                                INNER JOIN FICHAS                            F ON B.FICHA = F.FICHA
                                                LEFT  JOIN FILANCAMENTORECEBIMENTOVENCIMENTO C ON A.LANCAMENTO     = C.LANCAMENTO
                                                LEFT  JOIN FILANCAMENTORECEBIMENTORECEBIDO   D ON A.LANCAMENTO     = D.LANCAMENTO
                                                                                              AND C.DATAVENCIMENTO = D.DATAVENCIMENTO
 UNION                                                                                                                                                                                   
        SELECT
			'INT' AS TIPOPES
			, 'D' AS OPERACAO
            , A.CODIGO                                                                                                                                                                   
            , F.NOME DESCRICAO                                                                                                                                                           
            , A.DATAEMISSAO                                                                                                                                                              
            , A.DATALANCAMENTO                                                                                                                                                           
            , A.LANCAMENTO                                                                                                                                                               
            , A.DOCUMENTO                                                                                                                                                                
            , A.TIPO                                                                                                                                                                     
            , A.VALORTOTAL                                                                                                                                                               
            , C.DATAVENCIMENTO                                                                                                                                                           
            , C.VALORVENCIMENTO                                                                                                                                                          
            , NULL AS DATARECEBIMENTO
            , 0	AS VALORRECEBIMENTO
            , 0	AS VALORADIANTAMENTOPACIENTE
        FROM FILANCAMENTORECEBIMENTO A          INNER JOIN INTERNO                           B ON A.CODIGO = B.REGISTRO
																								AND A.TIPO = 0
                                                INNER JOIN FICHAS                            F ON B.FICHA = F.FICHA
                                                LEFT  JOIN FILANCAMENTORECEBIMENTOVENCIMENTO C ON A.LANCAMENTO     = C.LANCAMENTO
 UNION                                                                                                                                                                                   
        SELECT
			'INT' AS TIPOPES
			, 'C' AS OPERACAO
            , A.CODIGO                                                                                                                                                                   
            , F.NOME DESCRICAO                                                                                                                                                           
            , A.DATAEMISSAO                                                                                                                                                              
            , A.DATALANCAMENTO                                                                                                                                                           
            , A.LANCAMENTO                                                                                                                                                               
            , A.DOCUMENTO                                                                                                                                                                
            , A.TIPO                                                                                                                                                                     
            , A.VALORTOTAL                                                                                                                                                               
            , C.DATAVENCIMENTO
            , 0	AS VALORVENCIMENTO
            , D.DATARECEBIMENTO                                                                                                                                                          
            , D.VALORRECEBIMENTO                                                                                                                                                         
            , D.VALORADIANTAMENTOPACIENTE                                                                                                                                                
        FROM FILANCAMENTORECEBIMENTO A          INNER JOIN INTERNO                           B ON A.CODIGO = B.REGISTRO
																								AND A.TIPO = 0
                                                INNER JOIN FICHAS                            F ON B.FICHA = F.FICHA
                                                LEFT  JOIN FILANCAMENTORECEBIMENTOVENCIMENTO C ON A.LANCAMENTO     = C.LANCAMENTO
                                                LEFT  JOIN FILANCAMENTORECEBIMENTORECEBIDO   D ON A.LANCAMENTO     = D.LANCAMENTO
                                                                                              AND C.DATAVENCIMENTO = D.DATAVENCIMENTO
 UNION                                                                                                                                                                                   
        SELECT
			'EXT' AS TIPOPES
			, 'D' AS OPERACAO
            , A.CODIGO                                                                                                                                                                   
            , F.NOME DESCRICAO                                                                                                                                                           
            , A.DATAEMISSAO                                                                                                                                                              
            , A.DATALANCAMENTO                                                                                                                                                           
            , A.LANCAMENTO                                                                                                                                                               
            , A.DOCUMENTO                                                                                                                                                                
            , A.TIPO                                                                                                                                                                     
            , A.VALORTOTAL                                                                                                                                                               
            , C.DATAVENCIMENTO                                                                                                                                                           
            , C.VALORVENCIMENTO                                                                                                                                                          
            , NULL AS DATARECEBIMENTO
            , 0	AS VALORRECEBIMENTO
            , 0	AS VALORADIANTAMENTOPACIENTE
        FROM FILANCAMENTORECEBIMENTO A          INNER JOIN EXTERNO                           B ON A.CODIGO = B.REGISTRO
																								AND A.TIPO = 0
                                                INNER JOIN FICHAS                            F ON B.FICHA = F.FICHA
                                                LEFT  JOIN FILANCAMENTORECEBIMENTOVENCIMENTO C ON A.LANCAMENTO     = C.LANCAMENTO
 UNION                                                                                                                                                                                   
        SELECT
			'EXT' AS TIPOPES
			, 'C' AS OPERACAO
            , A.CODIGO                                                                                                                                                                   
            , F.NOME DESCRICAO                                                                                                                                                           
            , A.DATAEMISSAO                                                                                                                                                              
            , A.DATALANCAMENTO                                                                                                                                                           
            , A.LANCAMENTO                                                                                                                                                               
            , A.DOCUMENTO                                                                                                                                                                
            , A.TIPO                                                                                                                                                                     
            , A.VALORTOTAL                                                                                                                                                               
            , C.DATAVENCIMENTO
            , 0 AS VALORVENCIMENTO
            , D.DATARECEBIMENTO                                                                                                                                                          
            , D.VALORRECEBIMENTO                                                                                                                                                         
            , D.VALORADIANTAMENTOPACIENTE                                                                                                                                                
        FROM FILANCAMENTORECEBIMENTO A          INNER JOIN EXTERNO                           B ON A.CODIGO = B.REGISTRO
																								AND A.TIPO = 0
                                                INNER JOIN FICHAS                            F ON B.FICHA = F.FICHA
                                                LEFT  JOIN FILANCAMENTORECEBIMENTOVENCIMENTO C ON A.LANCAMENTO     = C.LANCAMENTO
                                                LEFT  JOIN FILANCAMENTORECEBIMENTORECEBIDO   D ON A.LANCAMENTO     = D.LANCAMENTO
                                                                                              AND C.DATAVENCIMENTO = D.DATAVENCIMENTO
 UNION                                                                                                                                                                                   
        SELECT
			'OUT' AS TIPOPES
			, 'D' AS OPERACAO
            , A.CODIGO                                                                                                                                                                   
            , B.DESCRICAO                                                                                                                                                           
            , A.DATAEMISSAO                                                                                                                                                              
            , A.DATALANCAMENTO                                                                                                                                                           
            , A.LANCAMENTO                                                                                                                                                               
            , A.DOCUMENTO                                                                                                                                                                
            , A.TIPO                                                                                                                                                                     
            , A.VALORTOTAL                                                                                                                                                               
            , C.DATAVENCIMENTO
            , C.VALORVENCIMENTO
            , NULL AS DATARECEBIMENTO
            , 0	AS VALORRECEBIMENTO
            , 0	AS VALORADIANTAMENTOPACIENTE
        FROM FILANCAMENTORECEBIMENTO A          INNER JOIN OUTROS                           B ON A.CODIGO = B.OUTRO
																								AND A.TIPO = 2
                                                LEFT  JOIN FILANCAMENTORECEBIMENTOVENCIMENTO C ON A.LANCAMENTO     = C.LANCAMENTO
 UNION                                                                                                                                                                                   
        SELECT
			'OUT' AS TIPOPES
			, 'C' AS OPERACAO
            , A.CODIGO                                                                                                                                                                   
            , B.DESCRICAO                                                                                                                                                           
            , A.DATAEMISSAO                                                                                                                                                              
            , A.DATALANCAMENTO                                                                                                                                                           
            , A.LANCAMENTO                                                                                                                                                               
            , A.DOCUMENTO                                                                                                                                                                
            , A.TIPO                                                                                                                                                                     
            , A.VALORTOTAL                                                                                                                                                               
            , C.DATAVENCIMENTO
            , 0	AS VALORVENCIMENTO
            , D.DATARECEBIMENTO                                                                                                                                                          
            , D.VALORRECEBIMENTO                                                                                                                                                         
            , D.VALORADIANTAMENTOPACIENTE                                                                                                                                                
        FROM FILANCAMENTORECEBIMENTO A          INNER JOIN OUTROS                           B ON A.CODIGO = B.OUTRO
																								AND A.TIPO = 2
                                                LEFT  JOIN FILANCAMENTORECEBIMENTOVENCIMENTO C ON A.LANCAMENTO     = C.LANCAMENTO
                                                LEFT  JOIN FILANCAMENTORECEBIMENTORECEBIDO   D ON A.LANCAMENTO     = D.LANCAMENTO
                                                                                              AND C.DATAVENCIMENTO = D.DATAVENCIMENTO

 go

