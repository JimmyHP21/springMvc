-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_usuariocentrocustoautorizacao
	@usuario int = null,
	@centrocusto smallint = null,
	@atualizacao varchar(150) = null,
	@movimenta int = null,
	@relatorio int = null,
	@responsavel int = null
as
begin
	set nocount on
	select
	 usuario, centrocusto, atualizacao, movimenta, relatorio, responsavel
	from dbo.usuariocentrocustoautorizacao
where (usuario = @usuario or @usuario is null )
 and (centrocusto = @centrocusto or @centrocusto is null )
 and (atualizacao = @atualizacao or @atualizacao is null )
 and (movimenta = @movimenta or @movimenta is null )
 and (relatorio = @relatorio or @relatorio is null )
 and (responsavel = @responsavel or @responsavel is null )
end
go

