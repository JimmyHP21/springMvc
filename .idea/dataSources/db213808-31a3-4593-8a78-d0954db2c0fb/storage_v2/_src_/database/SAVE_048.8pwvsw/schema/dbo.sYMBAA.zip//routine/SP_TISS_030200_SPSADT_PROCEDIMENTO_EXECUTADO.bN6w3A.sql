

CREATE PROCEDURE SP_TISS_030200_SPSADT_PROCEDIMENTO_EXECUTADO 	@REGISTRO      BIGINT = NULL,
																@TIPO_REGISTRO VARCHAR(MAX) = NULL,
																@GUIA          VARCHAR(MAX) = NULL,
																@TIPO_FATURA   VARCHAR(MAX)= 'TOTAL'
AS

    IF @TIPO_REGISTRO = 'AMBULATORIAL'
        OR @TIPO_REGISTRO = 'URGENCIA'		
      BEGIN
          SELECT
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------CHAVES--------------------------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------
          MOVIM.PROCEDIMENTO                                                                                        AS PROCEDIMENTO,
		  MOVIM.SEQUENCIA                                                                                           AS SEQUENCIAL,		  
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------PROCEDIMENTOS EXECUTADOS--------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  
          COALESCE(/* CI.DATA, */ MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO)                                          AS procedimentoExecutadoDataExecucao,--Data de realização  |  Date  |  8  |  DDMMAAAA  |  Data em que o atendimento/procedimento foi realizado  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          COALESCE(MOVIM.HORACONSUMO, ATEND.HORAINTERNACAO)                                         				AS procedimentoExecutadoHoraInicial,--Hora inicial da realização do procedimento  |  Time  |  8  |  HH:MM:SS  |  Horário inicial da realização do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de atendimento de urgência ou emergência.
          COALESCE(MOVIM.HORACONSUMO, ATEND.HORAINTERNACAO)                                         				AS procedimentoExecutadoHoraFinal,--Hora final da realização do procedimento  |  Time  |  8  |  HH:MM:SS  |  Horário final da realização do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de atendimento de urgência ou emergência.
          HON.TIPO_TABELA                                                                                           AS procedimentoExecutadoProcedimentoCodigoTabela,--Tabela de referência do procedimento ou item assistencial realizado  |  String  |  2  |    |  Código da tabela utilizada para identificar os procedimentos realizados ou itens assistenciais utilizados, conforme tabela de domínio nº 87.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          CASE WHEN HON.TIPO_TABELA = '00' 
		  THEN  DBO.FN_MASCARA_NUMERO(CONVERT(VARCHAR,HON.COD_TUSS),CONV.TISS_CODIGO_PROCEDIMENTO_PROPRIO_MASCARA)
		  ELSE HON.COD_TUSS END                                                                                     AS procedimentoExecutadoProcedimentoCodigoProcedimento,--Código do procedimento realizado  |  String  |  10  |    |  Código identificador do procedimento realizado pelo prestador, conforme tabela de domínio.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          HON.DESC_TUSS                                                                                             AS procedimentoExecutadoProcedimentoDescricaoProcedimento,--Descrição do procedimento realizado  |  String  |  150  |    |  Descrição do procedimento realizado  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
		  (CASE WHEN CAST( ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) > 0 THEN CAST(ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) ELSE 1 END)        AS procedimentoExecutadoQuantidadeExecutada,--Quantidade de procedimentos realizados  |  Integer  |  3  |    |  Quantidade realizada do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          T61.CODIGO                                                                                                AS procedimentoExecutadoViaAcesso,--Via de acesso  |  String  |  1  |    |  Código da via de acesso utilizada para realização do procedimento, conforme tabela de domínio nº 61.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de procedimento cirúrgico.
          T48.CODIGO                                                                                                AS procedimentoExecutadoTecnicaUtilizada,--Técnica utilizada para realização do procedimento  |  String  |  1  |    |  Código da técnica utilizada para realização do procedimento, conforme tabela de domínio nº 48.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de procedimento cirúrgico.
          (CASE WHEN ISNULL(MOVIM.FATORREDUTOR,0) = 0 THEN 1 ELSE MOVIM.FATORREDUTOR END)                           AS procedimentoExecutadoReducaoAcrescimo,--Fator de redução ou acréscimo  |  Numérico  |  1,2  |    |  Fator de redução ou acréscimo sobre o valor do procedimento realizado ou item assistencial utilizado.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado. Caso não haja redução ou acréscimo sobre o valor do procedimento o fator é igual a 1,00.
          (ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO) * ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE)) / (CASE WHEN CAST( ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) > 0 
														   THEN CAST(ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) ELSE 1 END)
																													AS procedimentoExecutadoValorUnitario,--Valor unitário do procedimento realizado  |  Numérico  |  6,2  |    |  Valor unitário do procedimento realizado.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado. Nos casos em que esse valor não possa ser definido previamente por força contratual, o campo deve ser preenchido com zero.			
		  ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO) * ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE)                    										        AS procedimentoExecutadoValorTotal --Valor total dos dos procedimentos realizados  |  Numérico  |  6,2  |    |  Valor total dos itens assistenciais utilizados, considerando a quantidade do item assistencial, o valor unitário e o fator de redução ou acréscimo.  |  Obrigatório.			
          FROM   V_RECUPERADADOSTISS AS RDT
                 INNER JOIN AMBULATORIAL AS ATEND WITH (NOLOCK)
                         ON ATEND.REGISTRO = RDT.REGISTRO
                            AND RDT.TIPOREGISTRO = 1
                            AND ISNULL(ATEND.CANCELADO, 0) = 0
                            AND RDT.GUIAINTERNA = @GUIA
                            AND ATEND.REGISTRO IN ( @REGISTRO )

                 INNER JOIN CONVENIOS AS CONV WITH (NOLOCK)
                         ON ATEND.CONVENIO = CONV.CONVENIO
                 INNER JOIN MOVIM_AMB AS MOVIM WITH (NOLOCK)
                         ON MOVIM.REGISTRO = ATEND.REGISTRO
							AND ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) > 0
                            AND MOVIM.TIPOLANCAMENTO IN ( 2, 3 )
                            AND ISNULL(MOVIM.GUIAINTERNA, 0) = RDT.GUIAINTERNA

                 LEFT JOIN TUSS_PROCEDIMENTO AS HON
                        ON HON.TIPO_DESC = 'PROCEDIMENTO'
					   AND HON.COD_SAVE = MOVIM.PROCEDIMENTO
					   AND MOVIM.TIPOLANCAMENTO IN ( 2, 3 )	
					   AND ( CASE
								 WHEN MOVIM.TIPOLANCAMENTO = 2 THEN CONV.TABELA
								 ELSE CONV.TABELAHONORARIO
							END ) = HON.TAB_CONVENIO
					   AND ISNULL(MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO) BETWEEN HON.INICIO_VIGENCIA AND ISNULL(HON.FIM_VIGENCIA, GETDATE())
				 
/* 				 LEFT JOIN CIRURGIA CI WITH (NOLOCK)
						 ON CI.REGISTRO = MOVIM.REGISTRO
						AND CI.TIPOREGISTRO = 2
						
				 LEFT JOIN CIRURGIAPROCEDIMENTO CP WITH (NOLOCK)
						ON CP.REGISTRO = CI.REGISTRO
					   AND CP.TIPOREGISTRO = CI.TIPOREGISTRO
					   AND CP.DOCUMENTO = CI.DOCUMENTO
					   AND CP.PROCEDIMENTO = MOVIM.PROCEDIMENTO */
					   
                 LEFT JOIN TUSS_TAB61 AS T61 WITH (NOLOCK)
                        ON T61.CODIGO = (CASE WHEN ISNULL(MOVIM.VIAACESSO,3) = 0 THEN 1
											  WHEN ISNULL(MOVIM.VIAACESSO,3) = 1 THEN 2
											  WHEN ISNULL(MOVIM.VIAACESSO,3) = 2 THEN 3
											  ELSE NULL END)
											  
                 LEFT JOIN TUSS_TAB48 AS T48 WITH (NOLOCK)
                        ON T48.CODIGO = NULL--(CASE WHEN CI.REGISTRO IS NOT NULL AND HON.DESC_TUSS LIKE '%VIDEO%' THEN 2 ELSE 1 END)
						
			ORDER BY ISNULL(MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO)					
      END 
	  ELSE IF @TIPO_REGISTRO = 'INTERNO' AND (@TIPO_FATURA = 'TOTAL' OR @TIPO_FATURA = 'FINAL')
      BEGIN
          SELECT
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------CHAVES--------------------------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------
          MOVIM.PROCEDIMENTO                                                                                        AS PROCEDIMENTO,
		  MOVIM.SEQUENCIA                                                                                           AS SEQUENCIAL,		  
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------PROCEDIMENTOS EXECUTADOS--------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  
          COALESCE(/* CI.DATA, */ MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO)                                          AS procedimentoExecutadoDataExecucao,--Data de realização  |  Date  |  8  |  DDMMAAAA  |  Data em que o atendimento/procedimento foi realizado  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          COALESCE(MOVIM.HORACONSUMO, ATEND.HORAINTERNACAO)	                                                        AS procedimentoExecutadoHoraInicial,--Hora inicial da realização do procedimento  |  Time  |  8  |  HH:MM:SS  |  Horário inicial da realização do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de atendimento de urgência ou emergência.
          COALESCE(MOVIM.HORACONSUMO, ATEND.HORAINTERNACAO)                                                         AS procedimentoExecutadoHoraFinal,--Hora final da realização do procedimento  |  Time  |  8  |  HH:MM:SS  |  Horário final da realização do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de atendimento de urgência ou emergência.
          HON.TIPO_TABELA                                                                                           AS procedimentoExecutadoProcedimentoCodigoTabela,--Tabela de referência do procedimento ou item assistencial realizado  |  String  |  2  |    |  Código da tabela utilizada para identificar os procedimentos realizados ou itens assistenciais utilizados, conforme tabela de domínio nº 87.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          CASE WHEN HON.TIPO_TABELA = '00' 
		  THEN  DBO.FN_MASCARA_NUMERO(CONVERT(VARCHAR,HON.COD_TUSS),CONV.TISS_CODIGO_PROCEDIMENTO_PROPRIO_MASCARA)
		  ELSE HON.COD_TUSS END                                                                                     AS procedimentoExecutadoProcedimentoCodigoProcedimento,--Código do procedimento realizado  |  String  |  10  |    |  Código identificador do procedimento realizado pelo prestador, conforme tabela de domínio.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          HON.DESC_TUSS                                                                                             AS procedimentoExecutadoProcedimentoDescricaoProcedimento,--Descrição do procedimento realizado  |  String  |  150  |    |  Descrição do procedimento realizado  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
		  (CASE WHEN CAST( ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) > 0 THEN CAST(ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) ELSE 1 END)        AS procedimentoExecutadoQuantidadeExecutada,--Quantidade de procedimentos realizados  |  Integer  |  3  |    |  Quantidade realizada do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          T61.CODIGO                                                                                                AS procedimentoExecutadoViaAcesso,--Via de acesso  |  String  |  1  |    |  Código da via de acesso utilizada para realização do procedimento, conforme tabela de domínio nº 61.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de procedimento cirúrgico.
          T48.CODIGO                                                                                                AS procedimentoExecutadoTecnicaUtilizada,--Técnica utilizada para realização do procedimento  |  String  |  1  |    |  Código da técnica utilizada para realização do procedimento, conforme tabela de domínio nº 48.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de procedimento cirúrgico.
          (CASE WHEN ISNULL(MOVIM.FATORREDUTOR,0) = 0 THEN 1 ELSE MOVIM.FATORREDUTOR END)                           AS procedimentoExecutadoReducaoAcrescimo,--Fator de redução ou acréscimo  |  Numérico  |  1,2  |    |  Fator de redução ou acréscimo sobre o valor do procedimento realizado ou item assistencial utilizado.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado. Caso não haja redução ou acréscimo sobre o valor do procedimento o fator é igual a 1,00.
          (ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO) * ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE)) / (CASE WHEN CAST( ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) > 0 
														   THEN CAST(ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) ELSE 1 END)
																													AS procedimentoExecutadoValorUnitario,--Valor unitário do procedimento realizado  |  Numérico  |  6,2  |    |  Valor unitário do procedimento realizado.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado. Nos casos em que esse valor não possa ser definido previamente por força contratual, o campo deve ser preenchido com zero.			
		  ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO) * ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE)                    										        AS procedimentoExecutadoValorTotal --Valor total dos dos procedimentos realizados  |  Numérico  |  6,2  |    |  Valor total dos itens assistenciais utilizados, considerando a quantidade do item assistencial, o valor unitário e o fator de redução ou acréscimo.  |  Obrigatório.			
          FROM   V_RECUPERADADOSTISS AS RDT
                 INNER JOIN INTERNO AS ATEND WITH (NOLOCK)
                         ON ATEND.REGISTRO = RDT.REGISTRO
                            AND RDT.TIPOREGISTRO = 2
                            AND ISNULL(ATEND.CANCELADO, 0) = 0
                            AND RDT.GUIAINTERNA = @GUIA
                            AND ATEND.REGISTRO IN ( @REGISTRO )

                 INNER JOIN CONVENIOS AS CONV WITH (NOLOCK)
                         ON ATEND.CONVENIO = CONV.CONVENIO
                 INNER JOIN MOVIM_INT AS MOVIM WITH (NOLOCK)
                         ON MOVIM.REGISTRO = ATEND.REGISTRO
							AND ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) > 0
                            AND MOVIM.TIPOLANCAMENTO = 2
                            AND ISNULL(MOVIM.GUIAINTERNA, 0) = RDT.GUIAINTERNA
							AND MOVIM.TIPOGUIA = ''

                 LEFT JOIN TUSS_PROCEDIMENTO AS HON
                        ON HON.TIPO_DESC = 'PROCEDIMENTO'
					   AND HON.COD_SAVE = MOVIM.PROCEDIMENTO
					   AND MOVIM.TIPOLANCAMENTO = 2
					   AND ( CASE
								 WHEN MOVIM.TIPOLANCAMENTO = 2 THEN CONV.TABELA
								 ELSE CONV.TABELAHONORARIO
							 END ) = HON.TAB_CONVENIO				 
					   AND ISNULL(MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO) BETWEEN HON.INICIO_VIGENCIA AND ISNULL(HON.FIM_VIGENCIA, GETDATE())
				 
/* 				 LEFT JOIN CIRURGIA CI WITH (NOLOCK)
						 ON CI.REGISTRO = MOVIM.REGISTRO
						AND CI.TIPOREGISTRO = 1
						
				 LEFT JOIN CIRURGIAPROCEDIMENTO CP WITH (NOLOCK)
						ON CP.REGISTRO = CI.REGISTRO
					   AND CP.TIPOREGISTRO = CI.TIPOREGISTRO
					   AND CP.DOCUMENTO = CI.DOCUMENTO
					   AND CP.PROCEDIMENTO = MOVIM.PROCEDIMENTO */
					   
                 LEFT JOIN TUSS_TAB61 AS T61 WITH (NOLOCK)
                        ON T61.CODIGO = (CASE WHEN ISNULL(MOVIM.VIAACESSO,3) = 0 THEN 1
											  WHEN ISNULL(MOVIM.VIAACESSO,3) = 1 THEN 2
											  WHEN ISNULL(MOVIM.VIAACESSO,3) = 2 THEN 3
											  ELSE NULL END)
											  
                 LEFT JOIN TUSS_TAB48 AS T48 WITH (NOLOCK)
                        ON T48.CODIGO = NULL--(CASE WHEN CI.REGISTRO IS NOT NULL AND HON.DESC_TUSS LIKE '%VIDEO%' THEN 2 ELSE 1 END)
						
			ORDER BY ISNULL(MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO)										
      END 	  
	  ELSE IF @TIPO_REGISTRO = 'INTERNO' AND @TIPO_FATURA = 'PARCIAL'
      BEGIN
          SELECT
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------CHAVES--------------------------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------
          MOVIM.PROCEDIMENTO                                                                                        AS PROCEDIMENTO,
		  MOVIM.SEQUENCIA                                                                                           AS SEQUENCIAL,		  
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------PROCEDIMENTOS EXECUTADOS--------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  
          COALESCE(/* CI.DATA, */ MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO)                                          AS procedimentoExecutadoDataExecucao,--Data de realização  |  Date  |  8  |  DDMMAAAA  |  Data em que o atendimento/procedimento foi realizado  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          COALESCE(MOVIM.HORACONSUMO, ATEND.HORAINTERNACAO)                                                         AS procedimentoExecutadoHoraInicial,--Hora inicial da realização do procedimento  |  Time  |  8  |  HH:MM:SS  |  Horário inicial da realização do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de atendimento de urgência ou emergência.
          COALESCE(MOVIM.HORACONSUMO, ATEND.HORAINTERNACAO)                                                         AS procedimentoExecutadoHoraFinal,--Hora final da realização do procedimento  |  Time  |  8  |  HH:MM:SS  |  Horário final da realização do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de atendimento de urgência ou emergência.
          HON.TIPO_TABELA                                                                                           AS procedimentoExecutadoProcedimentoCodigoTabela,--Tabela de referência do procedimento ou item assistencial realizado  |  String  |  2  |    |  Código da tabela utilizada para identificar os procedimentos realizados ou itens assistenciais utilizados, conforme tabela de domínio nº 87.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          CASE WHEN HON.TIPO_TABELA = '00' 
		  THEN  DBO.FN_MASCARA_NUMERO(CONVERT(VARCHAR,HON.COD_TUSS),CONV.TISS_CODIGO_PROCEDIMENTO_PROPRIO_MASCARA)
		  ELSE HON.COD_TUSS END                                                                                     AS procedimentoExecutadoProcedimentoCodigoProcedimento,--Código do procedimento realizado  |  String  |  10  |    |  Código identificador do procedimento realizado pelo prestador, conforme tabela de domínio.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          HON.DESC_TUSS                                                                                             AS procedimentoExecutadoProcedimentoDescricaoProcedimento,--Descrição do procedimento realizado  |  String  |  150  |    |  Descrição do procedimento realizado  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
		  (CASE WHEN CAST( ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) > 0 THEN CAST(ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) ELSE 1 END)        AS procedimentoExecutadoQuantidadeExecutada,--Quantidade de procedimentos realizados  |  Integer  |  3  |    |  Quantidade realizada do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          T61.CODIGO                                                                                                AS procedimentoExecutadoViaAcesso,--Via de acesso  |  String  |  1  |    |  Código da via de acesso utilizada para realização do procedimento, conforme tabela de domínio nº 61.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de procedimento cirúrgico.
          T48.CODIGO                                                                                                AS procedimentoExecutadoTecnicaUtilizada,--Técnica utilizada para realização do procedimento  |  String  |  1  |    |  Código da técnica utilizada para realização do procedimento, conforme tabela de domínio nº 48.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de procedimento cirúrgico.
          (CASE WHEN ISNULL(MOVIM.FATORREDUTOR,0) = 0 THEN 1 ELSE MOVIM.FATORREDUTOR END)                           AS procedimentoExecutadoReducaoAcrescimo,--Fator de redução ou acréscimo  |  Numérico  |  1,2  |    |  Fator de redução ou acréscimo sobre o valor do procedimento realizado ou item assistencial utilizado.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado. Caso não haja redução ou acréscimo sobre o valor do procedimento o fator é igual a 1,00.
          (ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO) * ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE)) / (CASE WHEN CAST( ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) > 0 
														   THEN CAST(ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) ELSE 1 END)
																													AS procedimentoExecutadoValorUnitario,--Valor unitário do procedimento realizado  |  Numérico  |  6,2  |    |  Valor unitário do procedimento realizado.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado. Nos casos em que esse valor não possa ser definido previamente por força contratual, o campo deve ser preenchido com zero.			
		  ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO) * ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE)                    										        AS procedimentoExecutadoValorTotal --Valor total dos dos procedimentos realizados  |  Numérico  |  6,2  |    |  Valor total dos itens assistenciais utilizados, considerando a quantidade do item assistencial, o valor unitário e o fator de redução ou acréscimo.  |  Obrigatório.			
		  FROM   V_RECUPERADADOSTISS AS RDT
                INNER JOIN EXTERNO AS ATEND WITH (NOLOCK)
                         ON ATEND.REGISTRO = RDT.REGISTRO
                            AND RDT.TIPOREGISTRO = 3
                            AND ISNULL(ATEND.CANCELADO, 0) = 0
                            AND RDT.GUIAINTERNA = @GUIA
                            AND ATEND.REGISTRO IN ( @REGISTRO )
							AND ISNULL(ATEND.PACIENTE_INTERNO_FATURADO, 0) <> 0	

                 INNER JOIN CONVENIOS AS CONV WITH (NOLOCK)
                         ON ATEND.CONVENIO = CONV.CONVENIO

                 INNER JOIN INTERNO AS INTER WITH (NOLOCK)
                         ON INTER.REGISTRO = ATEND.PACIENTE_INTERNO_FATURADO
                            AND ISNULL(INTER.CANCELADO, 0) = 0

                 INNER JOIN MOVIM_EXT AS MOVIM WITH (NOLOCK)
                         ON MOVIM.REGISTRO = ATEND.REGISTRO
							AND ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) > 0
                            AND MOVIM.TIPOLANCAMENTO = 2
                            AND ISNULL(MOVIM.GUIAINTERNA, 0) = RDT.GUIAINTERNA
							AND MOVIM.TIPOGUIA = ''

                 LEFT JOIN TUSS_PROCEDIMENTO AS HON
                        ON HON.TIPO_DESC = 'PROCEDIMENTO'
					   AND HON.COD_SAVE = MOVIM.PROCEDIMENTO
					   AND MOVIM.TIPOLANCAMENTO = 2
					   AND ( CASE
								WHEN MOVIM.TIPOLANCAMENTO = 2 THEN CONV.TABELA
								ELSE CONV.TABELAHONORARIO
					         END ) = HON.TAB_CONVENIO				 
					   AND ISNULL(MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO) BETWEEN HON.INICIO_VIGENCIA AND ISNULL(HON.FIM_VIGENCIA, GETDATE())
				 
/* 				 LEFT JOIN CIRURGIA CI WITH (NOLOCK)
						 ON CI.REGISTRO = MOVIM.REGISTRO
						AND CI.TIPOREGISTRO = 3
						
				 LEFT JOIN CIRURGIAPROCEDIMENTO CP WITH (NOLOCK)
						ON CP.REGISTRO = CI.REGISTRO
					   AND CP.TIPOREGISTRO = CI.TIPOREGISTRO
					   AND CP.DOCUMENTO = CI.DOCUMENTO
					   AND CP.PROCEDIMENTO = MOVIM.PROCEDIMENTO */
					   
                 LEFT JOIN TUSS_TAB61 AS T61 WITH (NOLOCK)
                        ON T61.CODIGO = (CASE WHEN ISNULL(MOVIM.VIAACESSO,3) = 0 THEN 1
											  WHEN ISNULL(MOVIM.VIAACESSO,3) = 1 THEN 2
											  WHEN ISNULL(MOVIM.VIAACESSO,3) = 2 THEN 3
											  ELSE NULL END)
											  
                 LEFT JOIN TUSS_TAB48 AS T48 WITH (NOLOCK)
                        ON T48.CODIGO = NULL--(CASE WHEN CI.REGISTRO IS NOT NULL AND HON.DESC_TUSS LIKE '%VIDEO%' THEN 2 ELSE 1 END)
						
			ORDER BY ISNULL(MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO)										
      END 	
      IF @TIPO_REGISTRO = 'EXTERNO'
      BEGIN
          SELECT
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------CHAVES--------------------------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------
          MOVIM.PROCEDIMENTO                                                                                        AS PROCEDIMENTO,
		  MOVIM.SEQUENCIA                                                                                           AS SEQUENCIAL,		  
          ------------------------------------------------------------------------------------------------------------------------------------------------
          ----------PROCEDIMENTOS EXECUTADOS--------------------------------------------------------------------------------------------------------------
          ------------------------------------------------------------------------------------------------------------------------------------------------		  
          COALESCE(/* CI.DATA, */ MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO)                                          AS procedimentoExecutadoDataExecucao,--Data de realização  |  Date  |  8  |  DDMMAAAA  |  Data em que o atendimento/procedimento foi realizado  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          COALESCE(MOVIM.HORACONSUMO, ATEND.HORAINTERNACAO)		                                                    AS procedimentoExecutadoHoraInicial,--Hora inicial da realização do procedimento  |  Time  |  8  |  HH:MM:SS  |  Horário inicial da realização do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de atendimento de urgência ou emergência.
          COALESCE(MOVIM.HORACONSUMO, ATEND.HORAINTERNACAO)		                                                    AS procedimentoExecutadoHoraFinal,--Hora final da realização do procedimento  |  Time  |  8  |  HH:MM:SS  |  Horário final da realização do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de atendimento de urgência ou emergência.
          HON.TIPO_TABELA                                                                                           AS procedimentoExecutadoProcedimentoCodigoTabela,--Tabela de referência do procedimento ou item assistencial realizado  |  String  |  2  |    |  Código da tabela utilizada para identificar os procedimentos realizados ou itens assistenciais utilizados, conforme tabela de domínio nº 87.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          CASE WHEN HON.TIPO_TABELA = '00' 
		  THEN  DBO.FN_MASCARA_NUMERO(CONVERT(VARCHAR,HON.COD_TUSS),CONV.TISS_CODIGO_PROCEDIMENTO_PROPRIO_MASCARA)
		  ELSE HON.COD_TUSS END                                                                                     AS procedimentoExecutadoProcedimentoCodigoProcedimento,--Código do procedimento realizado  |  String  |  10  |    |  Código identificador do procedimento realizado pelo prestador, conforme tabela de domínio.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          HON.DESC_TUSS                                                                                             AS procedimentoExecutadoProcedimentoDescricaoProcedimento,--Descrição do procedimento realizado  |  String  |  150  |    |  Descrição do procedimento realizado  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
		  (CASE WHEN CAST( ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) > 0 THEN CAST(ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) ELSE 1 END)        AS procedimentoExecutadoQuantidadeExecutada,--Quantidade de procedimentos realizados  |  Integer  |  3  |    |  Quantidade realizada do procedimento  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          T61.CODIGO                                                                                                AS procedimentoExecutadoViaAcesso,--Via de acesso  |  String  |  1  |    |  Código da via de acesso utilizada para realização do procedimento, conforme tabela de domínio nº 61.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de procedimento cirúrgico.
          T48.CODIGO                                                                                                AS procedimentoExecutadoTecnicaUtilizada,--Técnica utilizada para realização do procedimento  |  String  |  1  |    |  Código da técnica utilizada para realização do procedimento, conforme tabela de domínio nº 48.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado e tratar-se de procedimento cirúrgico.
          (CASE WHEN ISNULL(MOVIM.FATORREDUTOR,0) = 0 THEN 1 ELSE MOVIM.FATORREDUTOR END)                           AS procedimentoExecutadoReducaoAcrescimo,--Fator de redução ou acréscimo  |  Numérico  |  1,2  |    |  Fator de redução ou acréscimo sobre o valor do procedimento realizado ou item assistencial utilizado.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado. Caso não haja redução ou acréscimo sobre o valor do procedimento o fator é igual a 1,00.
          (ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO) * ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE)) / (CASE WHEN CAST( ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) > 0 
														   THEN CAST(ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) AS BIGINT) ELSE 1 END)
																													AS procedimentoExecutadoValorUnitario,--Valor unitário do procedimento realizado  |  Numérico  |  6,2  |    |  Valor unitário do procedimento realizado.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado. Nos casos em que esse valor não possa ser definido previamente por força contratual, o campo deve ser preenchido com zero.			
		  ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO) * ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE)                    										        AS procedimentoExecutadoValorTotal --Valor total dos dos procedimentos realizados  |  Numérico  |  6,2  |    |  Valor total dos itens assistenciais utilizados, considerando a quantidade do item assistencial, o valor unitário e o fator de redução ou acréscimo.  |  Obrigatório.			
          FROM   V_RECUPERADADOSTISS AS RDT
                 INNER JOIN EXTERNO AS ATEND WITH (NOLOCK)
                         ON ATEND.REGISTRO = RDT.REGISTRO
                            AND RDT.TIPOREGISTRO = 3
                            AND ISNULL(ATEND.CANCELADO, 0) = 0
                            AND RDT.GUIAINTERNA = @GUIA
                            AND ATEND.REGISTRO IN ( @REGISTRO )
							AND ISNULL(ATEND.PACIENTE_INTERNO_FATURADO, 0) = 0	

                 INNER JOIN CONVENIOS AS CONV WITH (NOLOCK)
                         ON ATEND.CONVENIO = CONV.CONVENIO

                 INNER JOIN MOVIM_EXT AS MOVIM WITH (NOLOCK)
                         ON MOVIM.REGISTRO = ATEND.REGISTRO
							AND ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) > 0
                            AND MOVIM.TIPOLANCAMENTO IN ( 2, 3 )
                            AND ISNULL(MOVIM.GUIAINTERNA, 0) = RDT.GUIAINTERNA

                 LEFT JOIN TUSS_PROCEDIMENTO AS HON
                        ON HON.TIPO_DESC = 'PROCEDIMENTO'
					   AND HON.COD_SAVE = MOVIM.PROCEDIMENTO
					   AND MOVIM.TIPOLANCAMENTO IN ( 2, 3 )
					   AND ( CASE
								 WHEN MOVIM.TIPOLANCAMENTO = 2 THEN CONV.TABELA
								 ELSE CONV.TABELAHONORARIO
							 END ) = HON.TAB_CONVENIO				 
					   AND ISNULL(MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO) BETWEEN HON.INICIO_VIGENCIA AND ISNULL(HON.FIM_VIGENCIA, GETDATE())
				 
/* 				 LEFT JOIN CIRURGIA CI WITH (NOLOCK)
						 ON CI.REGISTRO = MOVIM.REGISTRO
						AND CI.TIPOREGISTRO = 3
						
				 LEFT JOIN CIRURGIAPROCEDIMENTO CP WITH (NOLOCK)
						ON CP.REGISTRO = CI.REGISTRO
					   AND CP.TIPOREGISTRO = CI.TIPOREGISTRO
					   AND CP.DOCUMENTO = CI.DOCUMENTO
					   AND CP.PROCEDIMENTO = MOVIM.PROCEDIMENTO */
					   
                 LEFT JOIN TUSS_TAB61 AS T61 WITH (NOLOCK)
                        ON T61.CODIGO = (CASE WHEN ISNULL(MOVIM.VIAACESSO,3) = 0 THEN 1
											  WHEN ISNULL(MOVIM.VIAACESSO,3) = 1 THEN 2
											  WHEN ISNULL(MOVIM.VIAACESSO,3) = 2 THEN 3
											  ELSE NULL END)
											  
                 LEFT JOIN TUSS_TAB48 AS T48 WITH (NOLOCK)
                        ON T48.CODIGO = NULL--(CASE WHEN CI.REGISTRO IS NOT NULL AND HON.DESC_TUSS LIKE '%VIDEO%' THEN 2 ELSE 1 END)
						
			ORDER BY ISNULL(MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO)										
      END
go

