-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_prescricao_item_dispensacao
	@id bigint = null,
	@prescricao_item int = null,
	@item_horario bigint = null,
	@produto int = null,
	@lote varchar(20) = null,
	@validade datetime = null,
	@etiqueta int = null,
	@quantidade money = null,
	@centrocusto_dispensacao smallint = null,
	@centrocusto_paciente smallint = null,
	@usuario int = null,
	@data datetime = null,
	@atualizacao varchar(150) = null,
	@log bigint = null
as
begin
	set nocount on
	select
	 id, prescricao_item, item_horario, produto, lote, validade, etiqueta, quantidade, centrocusto_dispensacao, centrocusto_paciente, usuario, data, atualizacao, log
	from dbo.prescricao_item_dispensacao
where (id = @id or @id is null )
 and (prescricao_item = @prescricao_item or @prescricao_item is null )
 and (item_horario = @item_horario or @item_horario is null )
 and (produto = @produto or @produto is null )
 and (lote = @lote or @lote is null )
 and (validade = @validade or @validade is null )
 and (etiqueta = @etiqueta or @etiqueta is null )
 and (quantidade = @quantidade or @quantidade is null )
 and (centrocusto_dispensacao = @centrocusto_dispensacao or @centrocusto_dispensacao is null )
 and (centrocusto_paciente = @centrocusto_paciente or @centrocusto_paciente is null )
 and (usuario = @usuario or @usuario is null )
 and (data = @data or @data is null )
 and (atualizacao = @atualizacao or @atualizacao is null )
 and (log = @log or @log is null )
end
go

