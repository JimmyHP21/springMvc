create function [dbo].[fn_idade] ( 
   --add the parameters for the function here 
   @datanascimento datetime, 
   @dataatual datetime = null 
   ) 
returns varchar(10) 
as 
begin 
   --declare the return variable here 
   declare @result varchar(10); 
   declare @ano as int; 
   declare @mes as int 
   declare @dia as int 
 
   select @dataatual = isnull(@dataatual, getdate()); 
 
   if @datanascimento > @dataatual 
       return '' 
 
   --add the t-sql statements to compute the return value here 
   select @ano = floor(cast(@dataatual - cast(@datanascimento as datetime) as numeric(18, 5)) / 365.25), 
       --anos 
       @mes = floor(floor(cast(@dataatual - cast(@datanascimento as datetime) as numeric(18, 5)) / 30.4375) - (floor(cast(@dataatual - cast(@datanascimento as datetime) as int) / 365.25) * 365.25) / 30.4375), 
       --meses 
       @dia = cast(floor(cast(@dataatual - cast(@datanascimento as datetime) as numeric(18, 5)) - (floor(cast(@dataatual - cast(@datanascimento as datetime) as int) / 30.4375) * 30.4375)) as int)  
--dias 
 
   --return the result of the function 
   set @result = case 
           when @ano = 0 
               then '' 
           else cast(@ano as varchar(3)) + 'a' 
           end 
   set @result = @result + case 
           when @mes = 0 
               then '' 
           else cast(@mes as varchar(2)) + 'm' 
           end 
   set @result = @result + cast(@dia as varchar(2)) + 'd' 
 
   return @result 
end
go

