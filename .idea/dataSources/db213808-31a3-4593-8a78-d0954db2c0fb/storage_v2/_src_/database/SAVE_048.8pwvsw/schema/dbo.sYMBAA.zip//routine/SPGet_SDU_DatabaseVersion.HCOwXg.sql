
-- =============================================
-- Author:		Samuel Remoardo
-- Create date:	26/08/2014
-- Description:	
-- Revisions:	
-- =============================================
Create Procedure SPGet_SDU_DatabaseVersion
	@idVerDatabase bigint
AS
Begin
	SET NOCOUNT ON
	select
	 idVerDatabase,idReqVerSysA,idReqVerSysB,idReqVerSysC,idReqVerSysD,dthBegin, dthEnd, idUser, nameUser, idSession, hostname, ipAddress, macAddress, logExecution
	from SDU_DatabaseVersion
	where
		idVerDatabase = @idVerDatabase
End

go

