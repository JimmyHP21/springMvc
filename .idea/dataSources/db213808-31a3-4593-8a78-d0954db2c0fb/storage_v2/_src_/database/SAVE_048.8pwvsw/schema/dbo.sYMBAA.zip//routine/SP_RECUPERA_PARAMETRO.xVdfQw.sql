 CREATE PROCEDURE  [dbo].[SP_RECUPERA_PARAMETRO]                                                                                                 
                    @NOMECAMPO AS VARCHAR(150) = NULL                                                                                            
 AS                                                                                                                                              
 BEGIN                                                                                                                                           
    DECLARE @QUERY VARCHAR(MAX)                                                                                                                  
                                                                                                                                                 
                                                                                                                                                 
       IF EXISTS( SELECT * FROM INFORMATION_SCHEMA.COLUMNS                                                                                       
                   WHERE TABLE_NAME = 'PARAMETRO'                                                                                                
           AND  COLUMN_NAME = @NOMECAMPO)                                                                                                        
       BEGIN                                                                                                                                     
           SET @QUERY = 'SELECT ' + @NOMECAMPO + ' AS VALOR_CAMPO_RECUPERADO FROM PARAMETRO '                                                    
           EXECUTE(@QUERY)                                                                                                                       
       END                                                                                                                                       
       ELSE                                                                                                                                      
           BEGIN                                                                                                                                 
               SELECT VALOR_PARAMETRO AS VALOR_CAMPO_RECUPERADO FROM PARAMETROS_SISTEMA WHERE PARAMETRO = @NOMECAMPO                             
           END                                                                                                                                   
                                                                                                                                                 
 END

 go

