 
-- =============================================
-- Author:		M2 TECNOLOGIA
-- Create date:	06/09/2017
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPList_TUSS_TAB65
AS
BEGIN
	SET NOCOUNT ON

	SELECT
	 CODIGO, 
	 DESCRICAO, 
	 INICIOVIGENCIA, 
	 FIMVIGENCIA, 
	 FIMIMPLANTACAO
	FROM TUSS_TAB65
END
go

