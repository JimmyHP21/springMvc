-- =============================================
-- author:		m2 tecnologia
-- create date:	27/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spd_pres_cad_tipo_item
	@id int 
as
begin
	set nocount on
	delete from dbo.pres_cad_tipo_item
	where
		id = @id
end
go

