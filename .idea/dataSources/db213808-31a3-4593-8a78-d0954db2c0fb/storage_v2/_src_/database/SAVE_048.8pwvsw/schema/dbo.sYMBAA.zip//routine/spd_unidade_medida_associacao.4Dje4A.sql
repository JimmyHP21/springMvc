-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spd_unidade_medida_associacao
	@id int 
as
begin
	set nocount on
	delete from dbo.unidade_medida_associacao
	where
		id = @id
end
go

