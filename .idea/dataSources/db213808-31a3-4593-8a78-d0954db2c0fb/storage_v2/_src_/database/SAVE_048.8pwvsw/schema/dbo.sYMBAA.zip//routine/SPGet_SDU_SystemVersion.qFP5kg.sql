
-- =============================================
-- Author:		Samuel Remoardo
-- Create date:	26/08/2014
-- Description:	
-- Revisions:	
-- =============================================
Create Procedure SPGet_SDU_SystemVersion
	@idVerSystem bigint
AS
Begin
	SET NOCOUNT ON
	select
	 idVerSystem, idVerSysA, idVerSysB, idVerSysC, idVerSysD, dthPublish, dthExecution, lifeTime, tolerance
	from SDU_SystemVersion
	where
		idVerSystem = @idVerSystem
End
go

