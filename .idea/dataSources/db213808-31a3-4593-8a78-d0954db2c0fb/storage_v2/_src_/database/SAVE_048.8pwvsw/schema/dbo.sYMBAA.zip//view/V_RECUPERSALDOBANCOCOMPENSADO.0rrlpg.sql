CREATE VIEW V_RECUPERSALDOBANCOCOMPENSADO
AS
SELECT (
       CASE 
           WHEN ISNULL(F.NUMEROCHEQUE, '0') = '0'
               THEN E.DATACOMPENSADO
           ELSE F.DATACOMPENSADO
           END
       ) AS DATA
   , E.BANCO
   , MONTH((
           CASE 
               WHEN ISNULL(F.NUMEROCHEQUE, '0') = '0'
                   THEN E.DATACOMPENSADO
               ELSE F.DATACOMPENSADO
               END
           )) AS MES
   , YEAR((
           CASE 
               WHEN ISNULL(F.NUMEROCHEQUE, '0') = '0'
                   THEN E.DATACOMPENSADO
               ELSE F.DATACOMPENSADO
               END
           )) AS ANO
   , 0 AS RECEBIMENTO
   , (
       CASE 
           WHEN ISNULL(F.NUMEROCHEQUE, '0') = '0'
               THEN ((E.VALORPAGAMENTO + ISNULL(E.JUROS, 0) + ISNULL(E.MULTA, 0) + ISNULL(E.DESPESABANCARIA, 0)) 
                     - (CASE WHEN ISNULL(E.BAIXA_VALOR_LIQUIDO,0) = 0 THEN ISNULL(E.DESCONTO, 0) ELSE 0 END ))
           ELSE F.VALOR - ISNULL(E.VALORADIANTAMENTO, 0)
           END
       ) AS PAGAMENTO
 FROM FILANCAMENTO AS A
 LEFT JOIN FICREDOR AS B
   ON A.CREDOR = B.CREDOR
       AND A.TERCEIROS = 1
 LEFT JOIN Fornecedores AS C
   ON A.CREDOR = C.Fornecedor
       AND ISNULL(A.TERCEIROS, 0) = 0
 INNER JOIN FILANCAMENTOVENCIMENTO AS D
   ON A.LANCAMENTO = D.LANCAMENTO
 INNER JOIN FILANCAMENTOPAGAMENTO AS E
   ON D.LANCAMENTO = E.LANCAMENTO
       AND D.DATAVENCIMENTO = E.DATAVENCIMENTO
 LEFT JOIN FILANCAMENTOPAGAMENTOCHEQUE AS F
   ON D.LANCAMENTO = F.LANCAMENTO
       AND D.DATAVENCIMENTO = F.DATAVENCIMENTO
       AND E.DATAPAGAMENTO = F.DATAPAGAMENTO
       AND E.BANCO = F.BANCO
 WHERE (1 = 1)
   AND (
       ISNULL((
               CASE 
                   WHEN ISNULL(F.NUMEROCHEQUE, '0') = '0'
                       THEN E.COMPENSADO
                   ELSE F.COMPENSADO
                   END
               ), 0) = 1
       )
   AND (
       (
           CASE 
               WHEN ISNULL(F.NUMEROCHEQUE, '0') = '0'
                   THEN ((E.VALORPAGAMENTO + ISNULL(E.JUROS, 0) + ISNULL(E.MULTA, 0) + ISNULL(E.DESPESABANCARIA, 0)) 
                       - (CASE WHEN ISNULL(E.BAIXA_VALOR_LIQUIDO,0) = 0 THEN ISNULL(E.DESCONTO, 0) ELSE 0 END ))
               ELSE F.VALOR
               END
           ) > 0
       )
 UNION ALL
 SELECT A.DATACOMPENSADO AS DATA
   , A.BANCO
   , MONTH(A.DATACOMPENSADO) AS MES
   , YEAR(A.DATACOMPENSADO) AS ANO
   , 0 AS Expr1
   , A.VALOR
 FROM FIADIANTAMENTO AS A
 LEFT JOIN FICREDOR AS B
   ON A.FORNECEDOR = B.CREDOR
       AND A.TERCEIROS = 1
 LEFT JOIN Fornecedores AS C
   ON A.FORNECEDOR = C.Fornecedor
       AND ISNULL(A.TERCEIROS, 0) = 0
 WHERE (1 = 1)
   AND (ISNULL(A.COMPENSADO, 0) = 1)
   AND (A.VALOR > 0)
 UNION ALL
 SELECT C.DATACOMPENSADO AS DATA
   , C.BANCO
   , MONTH(C.DATACOMPENSADO) AS MES
   , YEAR(C.DATACOMPENSADO) AS ANO
   , (C.VALORRECEBIMENTO + ((ISNULL(C.JUROS, 0) + ISNULL(C.MULTA, 0) + ISNULL(C.VALORDIFERENCATABELA, 0)) 
   - (ISNULL(C.DESCONTO, 0) + ISNULL(C.GLOSA, 0) - ISNULL(C.VALORADIANTAMENTOPACIENTE, 0) + ISNULL(C.GLOSAPROFISSIONAL, 0)))) AS RECEBIMENTO
   , 0 AS PAGAMENTO
-- C.VALORRECEBIMENTO + ISNULL(C.JUROS, 0) 
--                   + ISNULL(C.MULTA, 0) - ISNULL(C.DESCONTO, 0) AS RECEBIMENTO, 0 AS PAGAMENTO
 FROM FILANCAMENTORECEBIMENTO AS A
 INNER JOIN FILANCAMENTORECEBIMENTOVENCIMENTO AS B
   ON A.LANCAMENTO = B.LANCAMENTO
 INNER JOIN FILANCAMENTORECEBIMENTORECEBIDO AS C
   ON B.LANCAMENTO = C.LANCAMENTO
       AND B.DATAVENCIMENTO = C.DATAVENCIMENTO
 INNER JOIN V_RECUPERATIPORECEBIMENTO AS D
   ON A.TIPOPACIENTE = D.TIPOPACIENTE
       AND A.TIPO = D.TIPO
       AND A.CODIGO = D.CODIGO
       AND A.LANCAMENTO = D.LANCAMENTO
 WHERE (1 = 1)
   AND (C.VALORRECEBIMENTO + ISNULL(C.JUROS, 0) + ISNULL(C.MULTA, 0) - ISNULL(C.DESCONTO, 0) > 0)
   AND (ISNULL(C.COMPENSADO, 0) = 1)
 UNION ALL
 SELECT A.DATACOMPENSADO AS DATA
   , A.BANCO
   , MONTH(A.DATACOMPENSADO) AS MES
   , YEAR(A.DATACOMPENSADO) AS ANO
   , A.VALOR
   , 0 AS PAGAMENTO
 FROM FIADIANTAMENTORECEBIMENTO A
 WHERE (1 = 1)
   AND (ISNULL(A.COMPENSADO, 0) = 1)
   AND (A.VALOR > 0)
 UNION ALL
 --RECUPERA VALOR DE INICIALIZAÇÃO DE SALDO DO BANCO CASO AJA SEM TER UMA COMPENSAÇÃO REALIZADA NO MESMO DIA. 
 SELECT 
     '1900-01-01 00:00:00.000' AS DATA 
   , F1.BANCO
   , 1 AS MES
   , 1900 AS ANO
   , F1.RECEBIMENTOCOMPENSADO AS RECEBIMENTO
   , F1.PAGAMENTOCOMPENSADO AS PAGAMENTO
 FROM FISALDOREALIZADO F1 INNER JOIN  (SELECT  MIN(DATA) AS DATA, BANCO
                                           FROM FISALDOREALIZADO 
                                           WHERE RECEBIMENTOCOMPENSADO >0 OR PAGAMENTOCOMPENSADO > 0
                                           GROUP BY BANCO) F2 ON F1.DATA =F2.DATA AND F1.BANCO = F2.BANCO 
       LEFT JOIN 
               (SELECT MIN(DATA) AS DATA, BANCO FROM 
                       (SELECT (
                               CASE 
                                   WHEN ISNULL(F.NUMEROCHEQUE, '0') = '0'
                                       THEN E.DATACOMPENSADO
                                   ELSE F.DATACOMPENSADO
                                   END
                               ) AS DATA
                           , E.BANCO
                       FROM FILANCAMENTO AS A
                       LEFT JOIN FICREDOR AS B
                           ON A.CREDOR = B.CREDOR
                               AND A.TERCEIROS = 1
                       LEFT JOIN Fornecedores AS C
                           ON A.CREDOR = C.Fornecedor
                               AND ISNULL(A.TERCEIROS, 0) = 0
                       INNER JOIN FILANCAMENTOVENCIMENTO AS D
                           ON A.LANCAMENTO = D.LANCAMENTO
                       INNER JOIN FILANCAMENTOPAGAMENTO AS E
                           ON D.LANCAMENTO = E.LANCAMENTO
                               AND D.DATAVENCIMENTO = E.DATAVENCIMENTO
                       LEFT JOIN FILANCAMENTOPAGAMENTOCHEQUE AS F
                           ON D.LANCAMENTO = F.LANCAMENTO
                               AND D.DATAVENCIMENTO = F.DATAVENCIMENTO
                               AND E.DATAPAGAMENTO = F.DATAPAGAMENTO
                               AND E.BANCO = F.BANCO
                       WHERE (1 = 1)
                           AND (
                               ISNULL((
                                       CASE 
                                           WHEN ISNULL(F.NUMEROCHEQUE, '0') = '0'
                                               THEN E.COMPENSADO
                                           ELSE F.COMPENSADO
                                           END
                                       ), 0) = 1
                               )
                           AND (
                               (
                                   CASE 
                                       WHEN ISNULL(F.NUMEROCHEQUE, '0') = '0'
                                           THEN ((E.VALORPAGAMENTO + ISNULL(E.JUROS, 0) + ISNULL(E.MULTA, 0) + ISNULL(E.DESPESABANCARIA, 0)) 
                                               - (CASE WHEN ISNULL(E.BAIXA_VALOR_LIQUIDO,0) = 0 THEN ISNULL(E.DESCONTO, 0) ELSE 0 END ))
                                       ELSE F.VALOR
                                       END
                                   ) > 0
                               )
                       UNION ALL
                       SELECT A.DATACOMPENSADO AS DATA
                           , A.BANCO
                       FROM FIADIANTAMENTO AS A
                       LEFT JOIN FICREDOR AS B
                           ON A.FORNECEDOR = B.CREDOR
                               AND A.TERCEIROS = 1
                       LEFT JOIN Fornecedores AS C
                           ON A.FORNECEDOR = C.Fornecedor
                               AND ISNULL(A.TERCEIROS, 0) = 0
                       WHERE (1 = 1)
                           AND (ISNULL(A.COMPENSADO, 0) = 1)
                           AND (A.VALOR > 0)
                       UNION ALL
                       SELECT C.DATACOMPENSADO AS DATA
                           , C.BANCO
                       FROM FILANCAMENTORECEBIMENTO AS A
                       INNER JOIN FILANCAMENTORECEBIMENTOVENCIMENTO AS B
                           ON A.LANCAMENTO = B.LANCAMENTO
                       INNER JOIN FILANCAMENTORECEBIMENTORECEBIDO AS C
                           ON B.LANCAMENTO = C.LANCAMENTO
                               AND B.DATAVENCIMENTO = C.DATAVENCIMENTO
                       INNER JOIN V_RECUPERATIPORECEBIMENTO AS D
                           ON A.TIPOPACIENTE = D.TIPOPACIENTE
                               AND A.TIPO = D.TIPO
                               AND A.CODIGO = D.CODIGO
                               AND A.LANCAMENTO = D.LANCAMENTO
                       WHERE (1 = 1)
                           AND (C.VALORRECEBIMENTO + ISNULL(C.JUROS, 0) + ISNULL(C.MULTA, 0) - ISNULL(C.DESCONTO, 0) > 0)
                           AND (ISNULL(C.COMPENSADO, 0) = 1)
                       UNION ALL
                       SELECT A.DATACOMPENSADO AS DATA
                           , A.BANCO
                       FROM FIADIANTAMENTORECEBIMENTO A
                       WHERE (1 = 1)
                           AND (ISNULL(A.COMPENSADO, 0) = 1)
                           AND (A.VALOR > 0)) AS T1
                           GROUP BY BANCO) F3 ON  F1.BANCO = F3.BANCO
   WHERE (F1.DATA < F3.DATA) OR F3.DATA IS NULL
go

