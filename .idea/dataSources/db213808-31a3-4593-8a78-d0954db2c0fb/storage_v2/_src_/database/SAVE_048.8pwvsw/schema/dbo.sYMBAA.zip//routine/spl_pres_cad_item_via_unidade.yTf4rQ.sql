-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spl_pres_cad_item_via_unidade

as
begin
	set nocount on
	select
	 id, item, via, unidade, padrao, atualizacao, apresentacao, log
	from dbo.pres_cad_item_via_unidade
end
go

