CREATE PROCEDURE [dbo].[SP_INS_PORTE_CBHPM] 
                       @ID_VIGENCIA            AS INTEGER       = NULL, 
                       @ID_PORTE_CBHPM         AS INTEGER       = NULL, 
                       @VALOR                  AS DECIMAL(10,2) = 0 
AS 
   BEGIN 
       SET NOCOUNT ON 
       INSERT INTO PORTE_CBHPM ( ID_VIGENCIA 
                               , ID_PORTE_CBHPM 
                               , VALOR ) 
               VALUES 
                               (  @ID_VIGENCIA 
                                 ,@ID_PORTE_CBHPM 
                                 ,@VALOR ) 
   END
go

