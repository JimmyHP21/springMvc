-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spl_unidade_medida

as
begin
	set nocount on
	select
	 id, descricao, atualizacao, log
	from dbo.unidade_medida
end
go

