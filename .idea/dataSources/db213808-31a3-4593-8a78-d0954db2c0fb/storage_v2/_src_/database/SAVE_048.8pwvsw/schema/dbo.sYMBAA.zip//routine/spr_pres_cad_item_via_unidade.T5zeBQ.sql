-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_pres_cad_item_via_unidade
	@id int = null,
	@item int = null,
	@via int = null,
	@unidade int = null,
	@padrao int = null,
	@atualizacao varchar(150) = null,
	@apresentacao int = null,
	@log bigint = null
as
begin
	set nocount on
	select
	 id, item, via, unidade, padrao, atualizacao, apresentacao, log
	from dbo.pres_cad_item_via_unidade
where (id = @id or @id is null )
 and (item = @item or @item is null )
 and (via = @via or @via is null )
 and (unidade = @unidade or @unidade is null )
 and (padrao = @padrao or @padrao is null )
 and (atualizacao = @atualizacao or @atualizacao is null )
 and (apresentacao = @apresentacao or @apresentacao is null )
 and (log = @log or @log is null )
end
go

