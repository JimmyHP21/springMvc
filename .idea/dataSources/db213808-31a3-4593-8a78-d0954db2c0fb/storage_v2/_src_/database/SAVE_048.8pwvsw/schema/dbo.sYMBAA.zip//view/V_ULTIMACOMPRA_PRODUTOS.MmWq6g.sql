 CREATE VIEW V_ULTIMACOMPRA_PRODUTOS AS SELECT  p.PRODUTO,         DESCRICAO,         pc.CONVENIO,         isnull(CONVERT(char,ULTENTRA,103),'') as ultentra,         case when isnull(CONVERT(char,ultentra,103),'') ='' then '' else isnull(ultimovalorcompra,'') end as ULTIMACOMPRA,         case when isnull(CONVERT(char,ultentra,103),'') ='' then '' else isnull(ultimaquantidadecompra,'') end as ULTIMAQUANTIDADECOMPRA,         CODIGOUNIMED,         pc.valor as VALORUNIMED FROM produto p inner join produtoconvenio pc on p.produto=pc.produto
 go

