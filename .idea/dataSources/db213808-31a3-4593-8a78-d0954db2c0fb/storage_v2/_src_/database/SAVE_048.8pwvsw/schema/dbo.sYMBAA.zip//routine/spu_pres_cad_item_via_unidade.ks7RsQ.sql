-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spu_pres_cad_item_via_unidade
	@id int ,
	@item int  = null,
	@via int  = null,
	@unidade int  = null,
	@padrao int  = null,
	@atualizacao varchar(150)  = null,
	@apresentacao int  = null,
	@log bigint  = null
as
begin
	set nocount on
	update dbo.pres_cad_item_via_unidade
	set
		item = @item,
		via = @via,
		unidade = @unidade,
		padrao = @padrao,
		atualizacao = @atualizacao,
		apresentacao = @apresentacao,
		log = @log
	where
		id = @id
end
go

