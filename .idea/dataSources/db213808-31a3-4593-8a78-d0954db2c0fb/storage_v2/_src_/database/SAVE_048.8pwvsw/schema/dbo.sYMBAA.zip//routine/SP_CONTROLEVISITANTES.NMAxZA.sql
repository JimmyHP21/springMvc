CREATE PROCEDURE [dbo].[SP_CONTROLEVISITANTES]                                           
           @PERIODOINICIAL DATETIME,                                                      
           @PERIODOFINAL DATETIME,                                                      
           @PACIENTE INT = 0
                                                                   
 AS                                                                                       
 BEGIN   
    IF   @PACIENTE  = 0 
    BEGIN                                                                              
         SELECT A.REGISTRO,                                                               
                C.NOME AS NOMEPACIENTE,                                                   
                B.LEITO,                                                                  
                D.DESCRICAO AS CONVENIO,                                                  
                A.DATA,                                                                   
                A.HORA AS HORAENTRADA,                                                    
                A.NOME AS NOMEVISITANTE,                                                  
                A.TIPOACOMPANHANTE,                                                       
                A.DATASAIDA,                                                              
                A.HORASAIDA,
               A.ENDERECO,
               A.NUMERO,
               A.BAIRRO,
               E.DESCRICAO AS CIDADE, 
               A.TELEFONE, 
               A.NUMEROCRACHA,                                                           
                A.rg                                                                      
         FROM CONTROLEVISITA A                                                            
              INNER JOIN INTERNO   B ON A.REGISTRO     = B.REGISTRO                       
              INNER JOIN FICHAS    C ON B.FICHA        = C.FICHA                          
              INNER JOIN CONVENIOS D ON B.CONVENIO     = D.CONVENIO                    
                   AND A.DATA BETWEEN @PERIODOINICIAL AND @PERIODOFINAL   
             INNER JOIN CIDADES E   ON A.CIDADE       = E.CIDADE                            
    END 
    IF   @PACIENTE  <> 0 
    BEGIN                                                                              
         SELECT A.REGISTRO,                                                               
                C.NOME AS NOMEPACIENTE,                                                   
                B.LEITO,                                                                  
                D.DESCRICAO AS CONVENIO,                                                  
                A.DATA,                                                                   
                A.HORA AS HORAENTRADA,                                                    
                A.NOME AS NOMEVISITANTE,                                                  
                A.TIPOACOMPANHANTE,                                                       
                A.DATASAIDA,                                                              
                A.HORASAIDA,
               A.ENDERECO,
               A.NUMERO,
               A.BAIRRO,
               E.DESCRICAO AS CIDADE, 
               A.TELEFONE, 
               A.NUMEROCRACHA,                                                           
                A.rg                                                                      
         FROM CONTROLEVISITA A                                                            
              INNER JOIN INTERNO   B ON A.REGISTRO     = B.REGISTRO
                           AND    A.REGISTRO = @PACIENTE                       
              INNER JOIN FICHAS    C ON B.FICHA        = C.FICHA                       
              INNER JOIN CONVENIOS D ON B.CONVENIO     = D.CONVENIO                    
                           AND A.DATA BETWEEN @PERIODOINICIAL AND @PERIODOFINAL   
             INNER JOIN CIDADES E   ON A.CIDADE       = E.CIDADE                            
   END 
 END
go

