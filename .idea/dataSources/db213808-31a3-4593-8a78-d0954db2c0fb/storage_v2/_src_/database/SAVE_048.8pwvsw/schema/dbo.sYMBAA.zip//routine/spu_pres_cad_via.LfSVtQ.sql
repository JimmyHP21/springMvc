-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spu_pres_cad_via
	@via int ,
	@descricao varchar(50)  = null,
	@atualizacao varchar(150)  = null
as
begin
	set nocount on
	update dbo.pres_cad_via
	set
		descricao = @descricao,
		atualizacao = @atualizacao
	where
		via = @via
end
go

