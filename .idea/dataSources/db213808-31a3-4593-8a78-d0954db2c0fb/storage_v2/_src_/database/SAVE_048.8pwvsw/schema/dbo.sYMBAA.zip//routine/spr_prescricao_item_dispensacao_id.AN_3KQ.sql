-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_prescricao_item_dispensacao_id
	@id bigint 
as
begin
	set nocount on
	select
	 id, prescricao_item, item_horario, produto, lote, validade, etiqueta, quantidade, centrocusto_dispensacao, centrocusto_paciente, usuario, data, atualizacao, log
	from dbo.prescricao_item_dispensacao
	where
		id = @id
end
go

