
-- =============================================
-- Author:		SSRM2 
-- Create date:	25/08/2014
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPList_TUSS_TAB44
AS
BEGIN
	SET NOCOUNT ON

	SELECT
	 CODIGO, 
	 DESCRICAO, 
	 INICIOVIGENCIA, 
	 FIMVIGENCIA, 
	 FIMIMPLANTACAO
	FROM TUSS_TAB44
END
go

