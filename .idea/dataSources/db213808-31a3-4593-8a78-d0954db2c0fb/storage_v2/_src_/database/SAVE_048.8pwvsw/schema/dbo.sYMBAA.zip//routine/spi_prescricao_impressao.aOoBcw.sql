-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spi_prescricao_impressao
	@id bigint  output,
	@data_impressao datetime ,
	@prescricao bigint ,
	@atualizacao varchar(150)  = null,
	@log bigint  = null,
	@data datetime  = null,
	@usuario int  = null
as
begin
	set nocount on
	insert into dbo.prescricao_impressao
		( data_impressao, prescricao, atualizacao, log, data, usuario)
	values
		(@data_impressao,@prescricao,@atualizacao,@log,@data,@usuario)

	select @id = scope_identity()
end
go

