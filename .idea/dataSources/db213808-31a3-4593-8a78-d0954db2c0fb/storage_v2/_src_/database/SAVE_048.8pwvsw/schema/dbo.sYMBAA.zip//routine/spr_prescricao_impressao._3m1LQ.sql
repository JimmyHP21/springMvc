-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_prescricao_impressao
	@id bigint = null,
	@data_impressao datetime = null,
	@prescricao bigint = null,
	@atualizacao varchar(150) = null,
	@log bigint = null,
	@data datetime = null,
	@usuario int = null
as
begin
	set nocount on
	select
	 id, data_impressao, prescricao, atualizacao, log, data, usuario
	from dbo.prescricao_impressao
where (id = @id or @id is null )
 and (data_impressao = @data_impressao or @data_impressao is null )
 and (prescricao = @prescricao or @prescricao is null )
 and (atualizacao = @atualizacao or @atualizacao is null )
 and (log = @log or @log is null )
 and (data = @data or @data is null )
 and (usuario = @usuario or @usuario is null )
end
go

