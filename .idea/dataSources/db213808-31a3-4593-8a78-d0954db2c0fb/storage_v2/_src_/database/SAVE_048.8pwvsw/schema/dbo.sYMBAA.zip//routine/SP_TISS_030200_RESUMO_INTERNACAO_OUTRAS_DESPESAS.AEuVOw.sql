CREATE PROCEDURE [dbo].[SP_TISS_030200_RESUMO_INTERNACAO_OUTRAS_DESPESAS]   @REGISTRO      BIGINT = NULL, 
                                                                   @TIPO_REGISTRO VARCHAR(MAX) = NULL, 
                                                                   @GUIA          VARCHAR(MAX) = NULL, 
                                                                   @TIPO_FATURA   VARCHAR(MAX) = 'TOTAL' 
AS 
  BEGIN 
   
      IF @TIPO_REGISTRO = 'INTERNO' AND (@TIPO_FATURA = 'TOTAL' OR @TIPO_FATURA = 'FINAL') 
        BEGIN 
            SELECT 
           ------------------------------------------------------------------------------------------------------------------------------------------------ 
           ----------CHAVES-------------------------------------------------------------------------------------------------------------------------------- 
           ------------------------------------------------------------------------------------------------------------------------------------------------ 
           MOVIM.PROCEDIMENTO                                                                                        AS PROCEDIMENTO, 
            ------------------------------------------------------------------------------------------------------------------------------------------------ 
            ----------OUTRAS DESPESAS----------------------------------------------------------------------------------------------------------------------- 
            ------------------------------------------------------------------------------------------------------------------------------------------------          
            OD.TIPO_DESPESA                                                                                               AS outraDespesaCodigoDespesa, 
--Código da despesa  |  String  |  2  |    |  Código da natureza da despesa, conforme tabela de domínio nº 25.  |  Obrigatório. 
            COALESCE(MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO)                                                            AS outraDespesaServicosExecutadosDataExecucao, 
--Data de realização  |  Date  |  8  |  DDMMAAAA  |  Data de realização da despesa  |  Obrigatório. 
            MIN(ISNULL(MOVIM.HORACONSUMO, ATEND.HORAINTERNACAO))                                                         AS outraDespesaServicosExecutadosHoraFinal, 
--Hora final da realização do procedimento  |  Time  |  8  |  HH:MM:SS  |  Horário final da realização da despesa  |  Condicionado. Deve ser preenchido quando o item de despesa admitir cobrança mensurável em horas. 
            MIN(ISNULL(MOVIM.HORACONSUMO, ATEND.HORAINTERNACAO))                                                         AS outraDespesaServicosExecutadosHoraInicial, 
--Hora inicial da realização do procedimento  |  Time  |  8  |  HH:MM:SS  |  Horário inicial da realização da despesa  |  Condicionado. Deve ser preenchido quando o item de despesa admitir cobrança mensurável em horas. 
            OD.TIPO_TABELA                                                                                                AS outraDespesaServicosExecutadosCodigoTabela, 
--Tabela de referência do procedimento ou item assistencial realizado  |  String  |  2  |    |  Código da tabela utilizada para identificar os procedimentos realizados ou itens assistenciais utilizados, conforme tabela de domínio nº 87.  |  Obrigatório. 
           OD.COD_TUSS                                                                                                   AS outraDespesaServicosExecutadosCodigoProcedimento, 
--Código do item assistencial utilizado  |  String  |  10  |    |  Código do item assistencial das despesas realizadas, conforme tabela utilizada  |  Obrigatório. 
           SUM((ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) / ISNULL(MOVIM.CONVLANC,ISNULL(PROD.CONVLANC,1))) * 
                (CASE WHEN ISNULL(PRODCONV.FATOR_CONVERSOR_XML,0) = 0 THEN 1 ELSE PRODCONV.FATOR_CONVERSOR_XML END))     AS outraDespesaServicosExecutadosQuantidadeExecutada, 
--Quantidade do item assistencial utilizado  |  Numérico  |  3,4  |    |  Quantidade realizada da despesa apresentada  |  Obrigatório. 
            T60.CODIGO                                                                                                    AS outraDespesaServicosExecutadosUnidadeMedida, 
--Unidade de Medida  |  String  |  3  |    |  Código da unidade de medida, conforme tabela de domínio nº 60.  |  Condicionado. Deve ser preenchido quando o item cobrado possuir unidade de medida. 
            (CASE WHEN ISNULL(MOVIM.FATORREDUTOR,0) = 0 THEN 1 ELSE MOVIM.FATORREDUTOR END)                               AS outraDespesaServicosExecutadosReducaoAcrescimo, 
--Fator de redução ou acréscimo  |  Numérico  |  1,2  |    |  Fator de redução ou acréscimo sobre o valor do procedimento realizado ou item assistencial utilizado.  |  Obrigatório. Caso não haja acréscimo ou redução no valor do procedimento, preencher o campo com 1,00. 
           ((ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO)/ 
           (CASE WHEN ISNULL(MOVIM.FATORREDUTOR,0) = 0 THEN 1 ELSE MOVIM.FATORREDUTOR END)) * 
           ISNULL(MOVIM.CONVLANC,ISNULL(PROD.CONVLANC,1))) / 
           (CASE WHEN ISNULL(PRODCONV.FATOR_CONVERSOR_XML,0) = 0 THEN 1 ELSE PRODCONV.FATOR_CONVERSOR_XML END)           AS outraDespesaServicosExecutadosValorUnitario, 
--Valor unitário do procedimento realizado ou item assistencial utilizado  |  Numérico  |  6,2  |    |  Valor unitário do item assistencial realizado  |  Obrigatório. Nos casos em que esse valor não possa ser definido previamente por força contratual, o campo será preenchido com zero. 
           SUM(ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) * ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO))            AS outraDespesaServicosExecutadosValorTotal, 
--Valor total dos itens assistenciais utilizados  |  Numérico  |  6,2  |    |  Valor total dos itens assistenciais utilizados, considerando a quantidade do item assistencial, o valor unitário e o fator de redução ou acréscimo.  |  Obrigatório. 
            OD.DESC_TUSS                                                                                                  AS outraDespesaServicosExecutadosDescricaoProcedimento, 
--Descrição do item assistencial utilizado  |  String  |  150  |    |  Descrição do item assistencial utilizado  |  Obrigatório. 
            NULL                                                                                                          AS outraDespesaServicosExecutadosRegistroANVISA, 
--Registro ANVISA do material  |  String  |  15  |    |  Número de registro do material na ANVISA  |  Condicionado. Deve ser preenchido em caso de cobrança de órteses, próteses e materiais especiais,  quando for utilizado código de material ainda não cadastrado na TUSS. 
            NULL                                                                                                          AS outraDespesaServicosExecutadosCodigoRefFabricante, 
--Código de referência do material no fabricante  |  String  |  60  |    |  Código de referência do material no fabricante  |  Condicionado. Deve ser preenchido quando se tratar de órteses, próteses e materiais especiais, quando for utilizado código de material ainda não cadastrado na TUSS. 
            NULL                                                                                                          AS outraDespesaServicosExecutadosAutorizacaoFuncionamento  
--Número da autorização de funcionamento da empresa da qual o material está sendo comprado.  |  String  |  30  |    |  Número da autorização de funcionamento da empresa da qual o material está sendo comprado.  |  Condicionado. Deve ser preenchido em caso de cobrança de órteses,  próteses e materiais especiais que foram adquiridos pelo prestador solicitante. 
            --SELECT TOP 1 * 
            FROM   V_RECUPERADADOSTISS AS RDT 
                   INNER JOIN INTERNO AS ATEND WITH (READPAST) 
                           ON ATEND.REGISTRO = RDT.REGISTRO 
                              AND RDT.TIPOREGISTRO = 2 
                              AND RDT.GUIAINTERNA = @GUIA 
                              AND ISNULL(ATEND.CANCELADO, 0) = 0 
                              AND ATEND.REGISTRO IN ( @REGISTRO ) 
                             AND RDT.GUIAINTERNA = 0 
                   
                  INNER JOIN CONVENIOS CONV WITH (READPAST) 
                          ON CONV.CONVENIO = ATEND.CONVENIO 
                   
                   INNER JOIN MOVIM_INT AS MOVIM WITH (READPAST) 
                           ON MOVIM.REGISTRO = ATEND.REGISTRO 
                              AND (ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) * ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO)) > 0 
                              AND MOVIM.TIPOLANCAMENTO IN ( 1, 4 ) 
                              AND ISNULL(MOVIM.GUIAINTERNA, 0) = RDT.GUIAINTERNA 
                   
                  LEFT JOIN PRODUTO PROD WITH (READPAST) 
                         ON PROD.PRODUTO = MOVIM.PROCEDIMENTO 
                         AND MOVIM.TIPOLANCAMENTO = 1 
                   
                  LEFT JOIN INSUMOS INSU WITH (READPAST) 
                         ON INSU.INSUMO = MOVIM.PROCEDIMENTO 
                         AND INSU.CONVENIO = ATEND.CONVENIO 
                         AND MOVIM.TIPOLANCAMENTO = 4 
                         AND INSU.PACOTE < 2  
--CASO O INSUMO SEJA PACOTE ASSISTENCIAL OU NÃO SEJA PACOTE 
 
                  LEFT JOIN PRODUTOCONVENIO PRODCONV WITH (READPAST) 
                         ON  PRODCONV.PRODUTO = MOVIM.PROCEDIMENTO 
                         AND PRODCONV.CONVENIO = ATEND.CONVENIO 
                         AND CONVERT(DATETIME,DBO.FN_TIPO_DATA_CONVENIO(PRODCONV.CONVENIO,@TIPO_REGISTRO,MOVIM.REGISTRO,MOVIM.SEQUENCIA,DEFAULT)) BETWEEN PRODCONV.INICIO_VIGENCIA AND CONVERT(DATETIME, ISNULL(PRODCONV.FINAL_VIGENCIA, GETDATE())) 
                         AND ISNULL(PRODCONV.EXCLUIDO,0) = 0 
                         AND MOVIM.TIPOLANCAMENTO=1 
 
                   LEFT JOIN TUSS_DESPESA AS OD WITH (NOLOCK) 
                             ON  MOVIM.TIPOLANCAMENTO IN ( 1, 4 ) 
                             AND ( (  
--OD.TIPO_TABELA = 18 
                                   OD.TIPO_DESC = 'INSUMO' 
                                   AND OD.COD_SAVE = MOVIM.PROCEDIMENTO 
                                   AND OD.CONVENIO = ATEND.CONVENIO ) 
                                    OR (  
--OD.TIPO_TABELA = 19 
                                       OD.TIPO_DESC = 'MATERIAL' 
                                       AND OD.COD_SAVE = MOVIM.PROCEDIMENTO ) 
                                    OR (  
--OD.TIPO_TABELA = 20 
                                       OD.TIPO_DESC = 'MEDICAMENTO' 
                                       AND OD.COD_SAVE = MOVIM.PROCEDIMENTO ) ) 
                            AND ATEND.CONVENIO = ISNULL(OD.CONVENIO, ATEND.CONVENIO) 
                             AND CONVERT(DATETIME,DBO.FN_TIPO_DATA_CONVENIO(ATEND.CONVENIO,@TIPO_REGISTRO,MOVIM.REGISTRO,MOVIM.SEQUENCIA,DEFAULT)) BETWEEN OD.INICIO_VIGENCIA AND CONVERT(DATETIME, ISNULL(OD.FIM_VIGENCIA, GETDATE())) 
                             
                   LEFT JOIN TUSS_TAB60 AS T60 WITH (READPAST) 
                          ON T60.CODIGO = ISNULL(DBO.FC_RETORNA_DEPARA('PRODUTO','UNIDADEFATURAMENTO', (CASE WHEN ISNULL(PRODCONV.UNIDADE_FATURAMENTO_XML,'') NOT IN ('','0') THEN PRODCONV.UNIDADE_FATURAMENTO_XML ELSE MOVIM.UNIDADEFATURAMENTO END),GETDATE(),''), 36) 
           WHERE (MOVIM.TIPOLANCAMENTO = 1 AND ISNULL(PROD.DESPESA,0)=0 AND ISNULL(PRODCONV.AUTORIZADO, 0) = 0) 
           OR (MOVIM.TIPOLANCAMENTO = 4 AND INSU.INSUMO IS NOT NULL) 
            GROUP  BY ATEND.REGISTRO, 
                      ATEND.FATURACONTA, 
                      RDT.GUIAPRINCIPAL, 
                      RDT.GUIAINTERNA, 
                      RDT.REGISTRO, 
                      RDT.DATA, 
                      RDT.SENHA, 
                      ATEND.VALIDADEGUIA, 
                      RDT.GUIATISS, 
                      ATEND.UNIDADE, 
                      ATEND.CARTEIRINHA, 
                      ATEND.DATAINTERNACAO, 
                      MOVIM.DATACONSUMO, 
                      OD.TIPO_TABELA, 
                      OD.TIPO_DESPESA, 
                      OD.COD_TUSS, 
                      OD.DESC_TUSS, 
                     OD.TIPO_DESC, 
                     INSU.UNIDADEFATURAMENTO, 
                     PROD.CODIGOUNIMED, 
                     CONV.TIPOCONVENIO, 
                     MOVIM.PROCEDIMENTO, 
                      MOVIM.FATORREDUTOR, 
                      MOVIM.VALORUNITARIO, 
                      MOVIM.TIPOGUIA, 
                      MOVIM.TIPOLANCAMENTO, 
                      MOVIM.VALORGLOSA, 
                      PRODCONV.FATOR_CONVERSOR_XML, 
                      T60.CODIGO, 
                     ISNULL(MOVIM.CONVLANC,ISNULL(PROD.CONVLANC,1)) 
           ORDER BY ISNULL(MOVIM.DATACONSUMO,ATEND.DATAINTERNACAO) ASC, OD.DESC_TUSS 
        END 
       ELSE IF @TIPO_REGISTRO = 'INTERNO' AND @TIPO_FATURA = 'PARCIAL' 
        BEGIN 
           SET @TIPO_REGISTRO = 'EXTERNO' 
            SELECT 
           ------------------------------------------------------------------------------------------------------------------------------------------------ 
           ----------CHAVES-------------------------------------------------------------------------------------------------------------------------------- 
           ------------------------------------------------------------------------------------------------------------------------------------------------ 
           MOVIM.PROCEDIMENTO                                                                                        AS PROCEDIMENTO, 
            ------------------------------------------------------------------------------------------------------------------------------------------------ 
            ----------OUTRAS DESPESAS----------------------------------------------------------------------------------------------------------------------- 
            ------------------------------------------------------------------------------------------------------------------------------------------------          
            OD.TIPO_DESPESA                                                                                               AS outraDespesaCodigoDespesa, 
--Código da despesa  |  String  |  2  |    |  Código da natureza da despesa, conforme tabela de domínio nº 25.  |  Obrigatório. 
            COALESCE(MOVIM.DATACONSUMO, ATEND.DATAINTERNACAO)                                                                AS outraDespesaServicosExecutadosDataExecucao, 
--Data de realização  |  Date  |  8  |  DDMMAAAA  |  Data de realização da despesa  |  Obrigatório. 
            MIN(ISNULL(MOVIM.HORACONSUMO, ATEND.HORAINTERNACAO))                                                         AS outraDespesaServicosExecutadosHoraInicial, 
--Hora inicial da realização do procedimento  |  Time  |  8  |  HH:MM:SS  |  Horário inicial da realização da despesa  |  Condicionado. Deve ser preenchido quando o item de despesa admitir cobrança mensurável em horas. 
            MIN(ISNULL(MOVIM.HORACONSUMO, ATEND.HORAINTERNACAO))                                                         AS outraDespesaServicosExecutadosHoraFinal, 
--Hora final da realização do procedimento  |  Time  |  8  |  HH:MM:SS  |  Horário final da realização da despesa  |  Condicionado. Deve ser preenchido quando o item de despesa admitir cobrança mensurável em horas. 
            OD.TIPO_TABELA                                                                                                AS outraDespesaServicosExecutadosCodigoTabela, 
--Tabela de referência do procedimento ou item assistencial realizado  |  String  |  2  |    |  Código da tabela utilizada para identificar os procedimentos realizados ou itens assistenciais utilizados, conforme tabela de domínio nº 87.  |  Obrigatório. 
            OD.COD_TUSS                                                                                                  AS outraDespesaServicosExecutadosCodigoProcedimento, 
--Código do item assistencial utilizado  |  String  |  10  |    |  Código do item assistencial das despesas realizadas, conforme tabela utilizada  |  Obrigatório. 
           SUM((ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) / ISNULL(MOVIM.CONVLANC,ISNULL(PROD.CONVLANC,1))) * 
                (CASE WHEN ISNULL(PRODCONV.FATOR_CONVERSOR_XML,0) = 0 THEN 1 ELSE PRODCONV.FATOR_CONVERSOR_XML END))     AS outraDespesaServicosExecutadosQuantidadeExecutada, 
--Quantidade do item assistencial utilizado  |  Numérico  |  3,4  |    |  Quantidade realizada da despesa apresentada  |  Obrigatório. 
            T60.CODIGO                                                                                                    AS outraDespesaServicosExecutadosUnidadeMedida, 
--Unidade de Medida  |  String  |  3  |    |  Código da unidade de medida, conforme tabela de domínio nº 60.  |  Condicionado. Deve ser preenchido quando o item cobrado possuir unidade de medida. 
            (CASE WHEN ISNULL(MOVIM.FATORREDUTOR,0) = 0 THEN 1 ELSE MOVIM.FATORREDUTOR END)                               AS outraDespesaServicosExecutadosReducaoAcrescimo, 
--Fator de redução ou acréscimo  |  Numérico  |  1,2  |    |  Fator de redução ou acréscimo sobre o valor do procedimento realizado ou item assistencial utilizado.  |  Obrigatório. Caso não haja acréscimo ou redução no valor do procedimento, preencher o campo com 1,00. 
           ((ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO)/ 
           (CASE WHEN ISNULL(MOVIM.FATORREDUTOR,0) = 0 THEN 1 ELSE MOVIM.FATORREDUTOR END)) * 
           ISNULL(MOVIM.CONVLANC,ISNULL(PROD.CONVLANC,1))) / 
           (CASE WHEN ISNULL(PRODCONV.FATOR_CONVERSOR_XML,0) = 0 THEN 1 ELSE PRODCONV.FATOR_CONVERSOR_XML END)           AS outraDespesaServicosExecutadosValorUnitario, 
--Valor unitário do procedimento realizado ou item assistencial utilizado  |  Numérico  |  6,2  |    |  Valor unitário do item assistencial realizado  |  Obrigatório. Nos casos em que esse valor não possa ser definido previamente por força contratual, o campo será preenchido com zero. 
           SUM(ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) * ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO))            AS outraDespesaServicosExecutadosValorTotal, 
--Valor total dos itens assistenciais utilizados  |  Numérico  |  6,2  |    |  Valor total dos itens assistenciais utilizados, considerando a quantidade do item assistencial, o valor unitário e o fator de redução ou acréscimo.  |  Obrigatório. 
            OD.DESC_TUSS                                                                                                  AS outraDespesaServicosExecutadosDescricaoProcedimento, 
--Descrição do item assistencial utilizado  |  String  |  150  |    |  Descrição do item assistencial utilizado  |  Obrigatório. 
            NULL                                                                                                          AS outraDespesaServicosExecutadosRegistroANVISA, 
--Registro ANVISA do material  |  String  |  15  |    |  Número de registro do material na ANVISA  |  Condicionado. Deve ser preenchido em caso de cobrança de órteses, próteses e materiais especiais,  quando for utilizado código de material ainda não cadastrado na TUSS. 
            NULL                                                                                                          AS outraDespesaServicosExecutadosCodigoRefFabricante, 
--Código de referência do material no fabricante  |  String  |  60  |    |  Código de referência do material no fabricante  |  Condicionado. Deve ser preenchido quando se tratar de órteses, próteses e materiais especiais, quando for utilizado código de material ainda não cadastrado na TUSS. 
            NULL                                                                                                          AS outraDespesaServicosExecutadosAutorizacaoFuncionamento  
--Número da autorização de funcionamento da empresa da qual o material está sendo comprado.  |  String  |  30  |    |  Número da autorização de funcionamento da empresa da qual o material está sendo comprado.  |  Condicionado. Deve ser preenchido em caso de cobrança de órteses,  próteses e materiais especiais que foram adquiridos pelo prestador solicitante. 
            --SELECT TOP 1 * 
             FROM   V_RECUPERADADOSTISS AS RDT 
                 INNER JOIN EXTERNO AS ATEND WITH (READPAST) 
                         ON ATEND.REGISTRO = RDT.REGISTRO 
                            AND RDT.TIPOREGISTRO = 3 
                            AND ISNULL(ATEND.CANCELADO, 0) = 0 
                            AND RDT.GUIAINTERNA = @GUIA 
                            AND ATEND.REGISTRO IN ( @REGISTRO ) 
                           AND RDT.GUIAINTERNA = 0 
                              
                INNER JOIN CONVENIOS CONV WITH (READPAST) 
                        ON CONV.CONVENIO = ATEND.CONVENIO 
                            
                 INNER JOIN INTERNO AS INTER WITH (READPAST) 
                         ON INTER.REGISTRO = ATEND.PACIENTE_INTERNO_FATURADO 
                            AND ISNULL(INTER.CANCELADO, 0) = 0 
                            
                 INNER JOIN MOVIM_EXT AS MOVIM WITH (READPAST) 
                         ON MOVIM.REGISTRO = ATEND.REGISTRO 
                            AND (ISNULL(MOVIM.QUANTIDADEGLOSA,MOVIM.QUANTIDADE) * ISNULL(MOVIM.VALORGLOSA,MOVIM.VALORUNITARIO)) > 0 
                            AND MOVIM.TIPOLANCAMENTO IN ( 1, 4 ) 
                            AND ISNULL(MOVIM.GUIAINTERNA, 0) = RDT.GUIAINTERNA 
        
                  LEFT JOIN PRODUTO PROD WITH (READPAST) 
                         ON PROD.PRODUTO = MOVIM.PROCEDIMENTO 
                         AND MOVIM.TIPOLANCAMENTO = 1 
                   
                  LEFT JOIN INSUMOS INSU WITH (READPAST) 
                         ON INSU.INSUMO = MOVIM.PROCEDIMENTO 
                         AND INSU.CONVENIO = ATEND.CONVENIO 
                         AND MOVIM.TIPOLANCAMENTO = 4 
                         AND INSU.PACOTE < 2  
--CASO O INSUMO SEJA PACOTE ASSISTENCIAL OU NÃO SEJA PACOTE 
 
                  LEFT JOIN PRODUTOCONVENIO PRODCONV WITH (READPAST) 
                         ON  PRODCONV.PRODUTO = MOVIM.PROCEDIMENTO 
                         AND PRODCONV.CONVENIO = ATEND.CONVENIO 
                         AND CONVERT(DATETIME,DBO.FN_TIPO_DATA_CONVENIO(PRODCONV.CONVENIO,@TIPO_REGISTRO,MOVIM.REGISTRO,MOVIM.SEQUENCIA,DEFAULT)) BETWEEN PRODCONV.INICIO_VIGENCIA AND CONVERT(DATETIME, ISNULL(PRODCONV.FINAL_VIGENCIA, GETDATE())) 
                         AND ISNULL(PRODCONV.EXCLUIDO,0) = 0 
                         AND MOVIM.TIPOLANCAMENTO=1 
                                                                                             
                   LEFT JOIN TUSS_DESPESA AS OD WITH (NOLOCK) 
                             ON  MOVIM.TIPOLANCAMENTO IN ( 1, 4 ) 
                             AND ( (  
--OD.TIPO_TABELA = 18 
                                   OD.TIPO_DESC = 'INSUMO' 
                                   AND OD.COD_SAVE = MOVIM.PROCEDIMENTO 
                                   AND OD.CONVENIO = ATEND.CONVENIO ) 
                                    OR (  
--OD.TIPO_TABELA = 19 
                                       OD.TIPO_DESC = 'MATERIAL' 
                                       AND OD.COD_SAVE = MOVIM.PROCEDIMENTO ) 
                                    OR (  
--OD.TIPO_TABELA = 20 
                                       OD.TIPO_DESC = 'MEDICAMENTO' 
                                       AND OD.COD_SAVE = MOVIM.PROCEDIMENTO ) ) 
                             AND ATEND.CONVENIO = ISNULL(OD.CONVENIO, ATEND.CONVENIO) 
                            AND CONVERT(DATETIME,DBO.FN_TIPO_DATA_CONVENIO(ATEND.CONVENIO,@TIPO_REGISTRO,MOVIM.REGISTRO,MOVIM.SEQUENCIA,DEFAULT)) BETWEEN OD.INICIO_VIGENCIA AND CONVERT(DATETIME, ISNULL(OD.FIM_VIGENCIA, GETDATE())) 
                             
                   LEFT JOIN TUSS_TAB60 AS T60 WITH (READPAST) 
                          ON T60.CODIGO = ISNULL(DBO.FC_RETORNA_DEPARA('PRODUTO','UNIDADEFATURAMENTO',(CASE WHEN ISNULL(PRODCONV.UNIDADE_FATURAMENTO_XML,'') NOT IN ('','0') THEN PRODCONV.UNIDADE_FATURAMENTO_XML ELSE MOVIM.UNIDADEFATURAMENTO END),GETDATE(),''), 36) 
           WHERE (MOVIM.TIPOLANCAMENTO = 1 AND ISNULL(PROD.DESPESA,0)=0 AND ISNULL(PRODCONV.AUTORIZADO, 0) = 0) 
           OR (MOVIM.TIPOLANCAMENTO = 4 AND INSU.INSUMO IS NOT NULL) 
            GROUP  BY ATEND.REGISTRO, 
                      ATEND.FATURACONTA, 
                      RDT.GUIAPRINCIPAL, 
                      RDT.GUIAINTERNA, 
                      RDT.REGISTRO, 
                      RDT.DATA, 
                      RDT.SENHA, 
                      ATEND.VALIDADEGUIA, 
                      RDT.GUIATISS, 
                      ATEND.UNIDADE, 
                      ATEND.CARTEIRINHA, 
                      ATEND.DATAINTERNACAO, 
                      MOVIM.DATACONSUMO, 
                      OD.TIPO_TABELA, 
                      OD.TIPO_DESPESA, 
                      OD.COD_TUSS, 
                      OD.DESC_TUSS, 
                     OD.TIPO_DESC, 
                     INSU.UNIDADEFATURAMENTO, 
                     PROD.CODIGOUNIMED, 
                     CONV.TIPOCONVENIO, 
                     MOVIM.PROCEDIMENTO, 
                      MOVIM.FATORREDUTOR, 
                      MOVIM.VALORUNITARIO, 
                      MOVIM.TIPOGUIA, 
                      MOVIM.TIPOLANCAMENTO, 
                      MOVIM.VALORGLOSA, 
                      PRODCONV.FATOR_CONVERSOR_XML, 
                      T60.CODIGO, 
                     ISNULL(MOVIM.CONVLANC,ISNULL(PROD.CONVLANC,1)) 
           ORDER BY ISNULL(MOVIM.DATACONSUMO,ATEND.DATAINTERNACAO) ASC, OD.DESC_TUSS 
        END 
  END
go

