-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spi_unidade_medida_associacao
	@id int  output,
	@unidadede int  = null,
	@unidadepara int  = null,
	@fator money  = null,
	@atualizacao varchar(150)  = null,
	@log bigint  = null
as
begin
	set nocount on
	insert into dbo.unidade_medida_associacao
		( unidadede, unidadepara, fator, atualizacao, log)
	values
		(@unidadede,@unidadepara,@fator,@atualizacao,@log)

	select @id = scope_identity()
end
go

