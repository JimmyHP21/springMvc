-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spi_pres_cad_via
	@via int  output,
	@descricao varchar(50)  = null,
	@atualizacao varchar(150)  = null
as
begin
	set nocount on
	insert into dbo.pres_cad_via
		( descricao, atualizacao)
	values
		(@descricao,@atualizacao)

	select @via = scope_identity()
end
go

