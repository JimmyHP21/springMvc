-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_pres_cad_item
	@id int = null,
	@descricao varchar(150) = null,
	@tipo int = null,
	@atualizacao varchar(150) = null,
	@log bigint = null
as
begin
	set nocount on
	select
	 id, descricao, tipo, atualizacao, log
	from dbo.pres_cad_item
where (id = @id or @id is null )
 and (descricao like @descricao or @descricao is null )
 and (tipo = @tipo or @tipo is null )
 and (atualizacao = @atualizacao or @atualizacao is null )
 and (log = @log or @log is null )
end
go

