-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spu_pres_cad_item
	@id int ,
	@descricao varchar(150)  = null,
	@tipo int  = null,
	@atualizacao varchar(150)  = null,
	@log bigint  = null
as
begin
	set nocount on
	update dbo.pres_cad_item
	set
		descricao = @descricao,
		tipo = @tipo,
		atualizacao = @atualizacao,
		log = @log
	where
		id = @id
end
go

