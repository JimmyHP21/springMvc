-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spd_pres_cad_produto_item
	@id int 
as
begin
	set nocount on
	delete from dbo.pres_cad_produto_item
	where
		id = @id
end
go

