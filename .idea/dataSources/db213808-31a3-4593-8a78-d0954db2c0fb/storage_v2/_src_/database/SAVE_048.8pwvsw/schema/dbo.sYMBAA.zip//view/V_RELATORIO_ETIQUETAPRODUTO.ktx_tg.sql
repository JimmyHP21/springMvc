CREATE VIEW [DBO].[V_RELATORIO_ETIQUETAPRODUTO] 
AS 
  SELECT DISTINCT 'PRODUTO'                                               AS 
                  TIPO, 
                  A.PRODUTO                                               AS 
                     PRODUTO, 
                  A.DESCRICAO                                             AS 
                     DESCRICAO, 
                  ISNULL(B.LOTE, 'S/ LOTE')                               AS 
                  LOTE, 
                  ISNULL(CONVERT(VARCHAR, B.VALIDADE, 103), '01/01/1900') AS 
                     VALIDADE, 
                  ISNULL(ISNULL(C.SEQUENCIA, A.PRODUTO), 0)               AS 
                     SEQUENCIA, 
                  ISNULL(CAST(D.CRF AS CHAR), '')                         AS CRF 
                  , 
                  ISNULL(D.FARMACEUTICO, '') 
                  AS 
                     FARMACEUTICO 
  FROM   PRODUTO A WITH (nolock) 
         INNER JOIN PRODUTOCENTROCUSTOLOTE B WITH (nolock) 
                 ON A.PRODUTO = B.PRODUTO 
         INNER JOIN PRODUTO_LOTE_ETIQUETA C WITH (nolock) 
                 ON C.PRODUTO = B.PRODUTO 
                    AND C.LOTE = B.LOTE 
                    AND C.VALIDADELOTE = B.VALIDADE 
         CROSS JOIN PARAMETROETIQUETA D 
  UNION ALL 
  SELECT DISTINCT 'KIT'                           AS TIPO, 
                  A.KITPROCEDIMENTO               AS PRODUTO, 
                  A.DESCRICAO                     AS DESCRICAO, 
                  'S/ LOTE'                       AS LOTE, 
                  '01/01/1900'                    AS VALIDADE, 
                  A.KITPROCEDIMENTO               AS SEQUENCIA, 
                  ISNULL(CAST(D.CRF AS CHAR), '') AS CRF, 
                  ISNULL(D.FARMACEUTICO, '')      AS FARMACEUTICO 
  FROM   KITPROCEDIMENTO A WITH (nolock) 
         CROSS JOIN PARAMETROETIQUETA D
go

