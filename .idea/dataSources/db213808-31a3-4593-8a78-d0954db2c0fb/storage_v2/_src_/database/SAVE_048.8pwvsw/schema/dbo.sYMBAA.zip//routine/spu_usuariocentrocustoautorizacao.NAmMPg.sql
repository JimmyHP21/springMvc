-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spu_usuariocentrocustoautorizacao
	@usuario int ,
	@centrocusto smallint ,
	@atualizacao varchar(150)  = null,
	@movimenta int  = null,
	@relatorio int  = null,
	@responsavel int  = null
as
begin
	set nocount on
	update dbo.usuariocentrocustoautorizacao
	set
		atualizacao = @atualizacao,
		movimenta = @movimenta,
		relatorio = @relatorio,
		responsavel = @responsavel
	where
		usuario = @usuario
		and centrocusto = @centrocusto
end
go

