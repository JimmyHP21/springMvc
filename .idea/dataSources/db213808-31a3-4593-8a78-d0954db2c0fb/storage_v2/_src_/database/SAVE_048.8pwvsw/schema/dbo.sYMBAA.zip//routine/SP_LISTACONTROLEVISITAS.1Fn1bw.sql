 CREATE PROCEDURE [dbo].[SP_LISTACONTROLEVISITAS]                                                 
       @TIPOPESQUISA int = 0,                                                                     
       @CAMPOPESQUISA VARCHAR(60) = ''                                                            
 AS                                                                                               
 BEGIN                                                                                            
   SET NOCOUNT ON;                                                                                
   IF (@TIPOPESQUISA = 0) BEGIN     -- PESQUISAR RG                                               
       Select  DISTINCT A.REGISTRO                                                                
               ,A.NOME AS NOMEVISITANTE                                                           
               ,A.RG                                                                              
               ,A.ENDERECO                                                                        
               ,A.NUMERO                                                                          
               ,A.BAIRRO                                                                          
               ,A.TELEFONE                                                                        
               ,D.CIDADE AS CODCIDADE                                                             
               ,D.DESCRICAO AS CIDADE                                                             
               ,E.ID_UF AS CODUF                                                                  
               ,E.SIGLA AS UF                                                                     
               from CONTROLEVISITA A LEFT JOIN CIDADES  D ON D.CIDADE   = A.CIDADE                
                                     LEFT JOIN UF       E ON E.ID_UF    = D.UF                    
           WHERE                                                                                  
           A.RG    LIKE @CAMPOPESQUISA + '%%'                                                     
   END                                                                                            
 ELSE IF (@TIPOPESQUISA = 1)                                                                      
   BEGIN                                       -- PESQUISA NOME                                   
       Select DISTINCT  A.REGISTRO                                                                
               ,A.NOME AS NOMEVISITANTE                                                           
               ,A.RG                                                                              
               ,A.ENDERECO                                                                        
               ,A.NUMERO                                                                          
               ,A.BAIRRO                                                                          
               ,A.TELEFONE                                                                  
               ,D.CIDADE AS CODCIDADE                                                             
               ,D.DESCRICAO AS CIDADE                                                             
               ,E.ID_UF AS CODUF                                                                  
               ,E.SIGLA AS UF                                                                     
               from CONTROLEVISITA A LEFT JOIN CIDADES       D ON D.CIDADE   = A.CIDADE           
                                     LEFT JOIN UF            E ON E.ID_UF    = D.UF               
           WHERE                                                                                  
           A.NOME LIKE @CAMPOPESQUISA + '%%'                                                      
   END                                                                                            
 ELSE IF (@TIPOPESQUISA = 2)                                                                      
   BEGIN                                       -- PESQUISA CODIGO                                 
       Select  A.CODIGO                                                                           
               ,A.REGISTRO                                                                        
               ,A.NOME AS NOMEVISITANTE                                                           
               ,A.RG                                                                              
               ,A.ENDERECO                                                                        
               ,A.NUMERO                                                                          
               ,A.BAIRRO                                                                          
               ,A.TELEFONE                                                                        
               ,D.CIDADE AS CODCIDADE                                                             
               ,D.DESCRICAO AS CIDADE                                                             
               ,E.ID_UF AS CODUF                                                                  
               ,E.SIGLA AS UF                                                                     
               from CONTROLEVISITA A LEFT  JOIN CIDADES      D ON D.CIDADE   = A.CIDADE           
                                     LEFT JOIN UF            E ON E.ID_UF    = D.UF               
           WHERE                                                                                  
           A.CODIGO = @CAMPOPESQUISA                                                              
   END                                                                                            
                                                                                                  
 END
 go

