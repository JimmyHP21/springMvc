-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_pres_cad_item_id
	@id int 
as
begin
	set nocount on
	select
	 id, descricao, tipo, atualizacao, log
	from dbo.pres_cad_item
	where
		id = @id
end
go

