-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_pres_cad_via_id
	@via int 
as
begin
	set nocount on
	select
	 via, descricao, atualizacao
	from dbo.pres_cad_via
	where
		via = @via
end
go

