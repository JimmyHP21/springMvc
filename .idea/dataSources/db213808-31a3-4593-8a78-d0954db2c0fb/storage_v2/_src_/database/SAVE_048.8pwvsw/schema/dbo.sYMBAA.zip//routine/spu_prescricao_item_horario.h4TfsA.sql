-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spu_prescricao_item_horario
	@id bigint ,
	@prescricao_item bigint  = null,
	@horario datetime  = null,
	@status int  = null,
	@usuario int  = null,
	@data datetime  = null,
	@atualizacao varchar(150)  = null,
	@log bigint  = null
as
begin
	set nocount on
	update dbo.prescricao_item_horario
	set
		prescricao_item = @prescricao_item,
		horario = @horario,
		status = @status,
		usuario = @usuario,
		data = @data,
		atualizacao = @atualizacao,
		log = @log
	where
		id = @id
end
go

