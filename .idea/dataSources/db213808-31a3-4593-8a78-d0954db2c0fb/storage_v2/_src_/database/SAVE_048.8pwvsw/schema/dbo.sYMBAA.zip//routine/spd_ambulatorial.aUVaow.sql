-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spd_ambulatorial
	@registro int 
as
begin
	set nocount on
	delete from dbo.ambulatorial
	where
		registro = @registro
end
go

