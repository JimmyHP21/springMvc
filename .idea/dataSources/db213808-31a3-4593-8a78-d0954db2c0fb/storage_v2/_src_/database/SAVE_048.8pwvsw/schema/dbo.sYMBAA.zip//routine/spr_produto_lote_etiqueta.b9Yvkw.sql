-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_produto_lote_etiqueta
	@produto int = null,
	@lote char(15) = null,
	@validadelote datetime = null,
	@sequencia int = null
as
begin
	set nocount on
	select
	 produto, lote, validadelote, sequencia
	from dbo.produto_lote_etiqueta
where (produto = @produto or @produto is null )
 and (lote = @lote or @lote is null )
 and (validadelote = @validadelote or @validadelote is null )
 and (sequencia = @sequencia or @sequencia is null )
end
go

