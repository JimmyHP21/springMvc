-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_unidade_medida
	@id int = null,
	@descricao varchar(50) = null,
	@atualizacao varchar(150) = null,
	@log bigint = null
as
begin
	set nocount on
	select
	 id, descricao, atualizacao, log
	from dbo.unidade_medida
where (id = @id or @id is null )
 and (descricao = @descricao or @descricao is null )
 and (atualizacao = @atualizacao or @atualizacao is null )
 and (log = @log or @log is null )
end
go

