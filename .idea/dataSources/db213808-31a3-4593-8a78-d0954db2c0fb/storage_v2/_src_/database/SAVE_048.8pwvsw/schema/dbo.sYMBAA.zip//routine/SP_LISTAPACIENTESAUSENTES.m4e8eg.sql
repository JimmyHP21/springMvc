                                                                                                           
 -- =============================================                                                          
 -- Author:        <M2>                                                                                    
 -- Create date: <Create Date 2015-12-21>                                                                  
 -- Description:   <PROCEDURE RECUPERA PACINETES AUSENTES NAS CONSULTAS AGENDADADS>                        
 -- =============================================                                                          
 CREATE PROCEDURE SP_LISTAPACIENTESAUSENTES                                                                
                                         @MEDICOINICIAL        INT = 0                                     
                                       , @MEDICOFINAL          INT = 999999999                             
                                       , @DATAINI_AGENDAMENTO  DATETIME                                    
                                       , @DATAFIM_AGENDAMENTO  DATETIME                                    
                                       , @AUSENCIA             INT = 0                                     
 AS                                                                                                        
 BEGIN                                                                                                     
   SET NOCOUNT ON;                                                                                         
                                                                                                           
   SELECT AG.MEDICO             AS MEDICO                                                                  
        , ME.NOME               AS NOME                                                                    
        , AG.DATA               AS DATA                                                                    
        , AG.HORA               AS HORA                                                                    
        , AG.PACIENTE           AS PACIENTE                                                                
        , AG.TELEFONE           AS TELEFONE                                                                
        , AG.CONVENIO           AS CODCONVENIO                                                             
        , CONV.DESCRICAO        AS CONVENIO                                                                
        , ISNULL(AG.AUSENCIA,0) AS AUSENCIA                                                                
        , ME.ESPECMEDICA        AS ESPACIALIDADE                                                           
        , ESP.DESCRICAO         AS NOMEESPECIALIDADE                                                       
        , AG.OBSERVACAO         AS OBSERVACAO                                                              
        , AG.DATAATUALIZACAO    AS DATAAUSENCIA                                                            
   FROM AGENDAMENTOCONSULTA AG INNER JOIN MEDICOS   ME   ON ME.MEDICO       = AG.MEDICO                    
                               LEFT  JOIN ESPMEDICA ESP  ON ESP.ESPECMEDICA = ME.ESPECMEDICA               
                               INNER JOIN CONVENIOS CONV ON CONV.CONVENIO   = AG.CONVENIO                  
   WHERE                                                                                                   
           AG.MEDICO BETWEEN @MEDICOINICIAL       AND @MEDICOFINAL                                         
       AND AG.DATA   BETWEEN @DATAINI_AGENDAMENTO AND @DATAFIM_AGENDAMENTO                                 
       AND ISNULL(AG.AUSENCIA,0) = @AUSENCIA                                                               
 END
 go

