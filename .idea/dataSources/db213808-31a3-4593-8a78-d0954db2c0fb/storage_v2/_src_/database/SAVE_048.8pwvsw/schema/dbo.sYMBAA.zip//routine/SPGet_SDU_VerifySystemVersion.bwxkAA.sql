
-- =============================================
-- Author:		Samuel Remoardo
-- Create date:	26/08/2014
-- Description:	
-- Revisions:	
-- =============================================
Create Procedure SPGet_SDU_VerifySystemVersion
	@idCurVerSysA int,
  @idCurVerSysB int,
  @idCurVerSysC int,
  @idCurVerSysD int,
  @idReqVerDatabase int
AS
Begin
  declare @idReqVerSysA int
  declare @idReqVerSysB int
  declare @idReqVerSysC int
  declare @idReqVerSysD int
  declare @idCurVerDatabase  int
  declare @idReqVerSys numeric(24)
  declare @idCurVerSys numeric(24)
  Declare @isUpdated bit
  
	SET NOCOUNT ON

  
  select top 1 
      @idCurVerDatabase = a.idVerDatabase,
      @idReqVerSysA = a.idReqVerSysA,
      @idReqVerSysB = a.idReqVerSysB,
      @idReqVerSysC = a.idReqVerSysC,
      @idReqVerSysD = a.idReqVerSysD    
  from SDU_DatabaseVersion a
  order by a.idVerDatabase desc;
    
  set @idCurVerDatabase = isnull(@idCurVerDatabase,0)
  set @idReqVerSysA = isnull(@idReqVerSysA,0)
  set @idReqVerSysB = isnull(@idReqVerSysB,0)
  set @idReqVerSysC = isnull(@idReqVerSysC,0)
  set @idReqVerSysD = isnull(@idReqVerSysD,0)
  
  set @idReqVerSys = cast(   right(replicate('0',6) + cast(@idReqVerSysA as varchar(6)),6)
                           + right(replicate('0',6) + cast(@idReqVerSysB as varchar(6)),6)
                           + right(replicate('0',6) + cast(@idReqVerSysC as varchar(6)),6)
                           + right(replicate('0',6) + cast(@idReqVerSysD as varchar(6)),6)
                     as numeric(24));
  set @idCurVerSys = cast(   right(replicate('0',6) + cast(@idCurVerSysA as varchar(6)),6)
                           + right(replicate('0',6) + cast(@idCurVerSysB as varchar(6)),6)
                           + right(replicate('0',6) + cast(@idCurVerSysC as varchar(6)),6)
                           + right(replicate('0',6) + cast(@idCurVerSysD as varchar(6)),6)
                     as numeric(24));                     
                     
  if @idCurVerDatabase < @idReqVerDatabase
    select 1 as tipo,'requer pacote' as descricao, cast(@idReqVerDatabase as varchar) as valor
  else if  @idCurVerSys < @idReqVerSys
    select 2 as tipo, 'requer versao' as descricao, cast(@idReqVerSysA as varchar) + '.' + cast(@idReqVerSysB as varchar) + '.' + cast(@idReqVerSysC as varchar) + '.' + cast(@idReqVerSysD as varchar) as valor
  else
    select 3 as tipo, 'atualizado' as descricao, '' as valor;
    
End
go

