-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spr_usuario
	@usuario int = null,
	@nome varchar(50) = null,
	@logon varchar(15) = null,
	@senha varchar(15) = null,
	@atualizacao varchar(150) = null,
	@administralicenca int = null,
	@sndi int = null,
	@snda int = null,
	@snde int = null,
	@almoxarifadoi int = null,
	@almoxarifadoa int = null,
	@almoxarifadoe int = null,
	@farmaciai int = null,
	@farmaciaa int = null,
	@farmaciae int = null,
	@estoquei int = null,
	@estoquea int = null,
	@estoquee int = null,
	@emailpadraocotacao varchar(155) = null,
	@prescricaointerno int = null,
	@prescricaoambulatorial int = null,
	@prescricaourgencia int = null,
	@ccpadraocotacao int = null,
	@observacao varchar(65) = null,
	@desativado int = null,
	@telamedicoapenasconsulta int = null,
	@alteraguiatelatransferencia int = null,
	@altera_tabela_preco_convenio int = null,
	@prescricaoexterno int = null,
	@medico_apenascbo int = null,
	@medico_cadastroespecialidade int = null,
	@medico_cadastroclassificacao int = null,
	@medico_cadastrohorario int = null,
	@tutorprescricao int = null,
	@medico int = null,
	@administracusto int = null,
	@excluibaixafinanceirocompensado int = null,
	@excluiragendaconsulta int = null,
	@permitereemprimirprescricao int = null,
	@permitealteranome int = null,
	@preparakitmedicamento int = null,
	@permite_alterar_lanc_pagterceiro int = null,
	@naopermitealteraragendamento int = null,
	@naopermitealteracaofinanceiro int = null,
	@referencia int = null,
	@unidadeencaminhamento int = null,
	@permite_apenas_lancar_contasreceber int = null,
	@permite_conferir_laudo int = null,
	@usuariounimed int = null,
	@gerente int = null,
	@naopermitecancelarregistros int = null,
	@permissaopredevolucao int = null,
	@permissaodevolucao int = null,
	@permitedevolucaodireta int = null,
	@medico_cadastrohonorario int = null,
	@relprescsomentedieta int = null,
	@cpf varchar(11) = null,
	@rg varchar(12) = null,
	@datanasc datetime = null,
	@inicializarsenha int = null,
	@data_atualizacao_senha datetime = null,
	@pres_cad_tutor int = null
as
begin
	set nocount on
	select
	 usuario, nome, logon, senha, atualizacao, administralicenca, sndi, snda, snde, almoxarifadoi, almoxarifadoa, almoxarifadoe, farmaciai, farmaciaa, farmaciae, estoquei, estoquea, estoquee, emailpadraocotacao, prescricaointerno, prescricaoambulatorial, prescricaourgencia, ccpadraocotacao, observacao, desativado, telamedicoapenasconsulta, alteraguiatelatransferencia, altera_tabela_preco_convenio, prescricaoexterno, medico_apenascbo, medico_cadastroespecialidade, medico_cadastroclassificacao, medico_cadastrohorario, tutorprescricao, medico, administracusto, excluibaixafinanceirocompensado, excluiragendaconsulta, permitereemprimirprescricao, permitealteranome, preparakitmedicamento, permite_alterar_lanc_pagterceiro, naopermitealteraragendamento, naopermitealteracaofinanceiro, referencia, unidadeencaminhamento, permite_apenas_lancar_contasreceber, permite_conferir_laudo, usuariounimed, gerente, naopermitecancelarregistros, permissaopredevolucao, permissaodevolucao, permitedevolucaodireta, medico_cadastrohonorario, relprescsomentedieta, cpf, rg, datanasc, inicializarsenha, data_atualizacao_senha, pres_cad_tutor
	from dbo.usuario
where (usuario = @usuario or @usuario is null )
 and (nome = @nome or @nome is null )
 and (logon = @logon or @logon is null )
 and (senha = @senha or @senha is null )
 and (atualizacao = @atualizacao or @atualizacao is null )
 and (administralicenca = @administralicenca or @administralicenca is null )
 and (sndi = @sndi or @sndi is null )
 and (snda = @snda or @snda is null )
 and (snde = @snde or @snde is null )
 and (almoxarifadoi = @almoxarifadoi or @almoxarifadoi is null )
 and (almoxarifadoa = @almoxarifadoa or @almoxarifadoa is null )
 and (almoxarifadoe = @almoxarifadoe or @almoxarifadoe is null )
 and (farmaciai = @farmaciai or @farmaciai is null )
 and (farmaciaa = @farmaciaa or @farmaciaa is null )
 and (farmaciae = @farmaciae or @farmaciae is null )
 and (estoquei = @estoquei or @estoquei is null )
 and (estoquea = @estoquea or @estoquea is null )
 and (estoquee = @estoquee or @estoquee is null )
 and (emailpadraocotacao = @emailpadraocotacao or @emailpadraocotacao is null )
 and (prescricaointerno = @prescricaointerno or @prescricaointerno is null )
 and (prescricaoambulatorial = @prescricaoambulatorial or @prescricaoambulatorial is null )
 and (prescricaourgencia = @prescricaourgencia or @prescricaourgencia is null )
 and (ccpadraocotacao = @ccpadraocotacao or @ccpadraocotacao is null )
 and (observacao = @observacao or @observacao is null )
 and (desativado = @desativado or @desativado is null )
 and (telamedicoapenasconsulta = @telamedicoapenasconsulta or @telamedicoapenasconsulta is null )
 and (alteraguiatelatransferencia = @alteraguiatelatransferencia or @alteraguiatelatransferencia is null )
 and (altera_tabela_preco_convenio = @altera_tabela_preco_convenio or @altera_tabela_preco_convenio is null )
 and (prescricaoexterno = @prescricaoexterno or @prescricaoexterno is null )
 and (medico_apenascbo = @medico_apenascbo or @medico_apenascbo is null )
 and (medico_cadastroespecialidade = @medico_cadastroespecialidade or @medico_cadastroespecialidade is null )
 and (medico_cadastroclassificacao = @medico_cadastroclassificacao or @medico_cadastroclassificacao is null )
 and (medico_cadastrohorario = @medico_cadastrohorario or @medico_cadastrohorario is null )
 and (tutorprescricao = @tutorprescricao or @tutorprescricao is null )
 and (medico = @medico or @medico is null )
 and (administracusto = @administracusto or @administracusto is null )
 and (excluibaixafinanceirocompensado = @excluibaixafinanceirocompensado or @excluibaixafinanceirocompensado is null )
 and (excluiragendaconsulta = @excluiragendaconsulta or @excluiragendaconsulta is null )
 and (permitereemprimirprescricao = @permitereemprimirprescricao or @permitereemprimirprescricao is null )
 and (permitealteranome = @permitealteranome or @permitealteranome is null )
 and (preparakitmedicamento = @preparakitmedicamento or @preparakitmedicamento is null )
 and (permite_alterar_lanc_pagterceiro = @permite_alterar_lanc_pagterceiro or @permite_alterar_lanc_pagterceiro is null )
 and (naopermitealteraragendamento = @naopermitealteraragendamento or @naopermitealteraragendamento is null )
 and (naopermitealteracaofinanceiro = @naopermitealteracaofinanceiro or @naopermitealteracaofinanceiro is null )
 and (referencia = @referencia or @referencia is null )
 and (unidadeencaminhamento = @unidadeencaminhamento or @unidadeencaminhamento is null )
 and (permite_apenas_lancar_contasreceber = @permite_apenas_lancar_contasreceber or @permite_apenas_lancar_contasreceber is null )
 and (permite_conferir_laudo = @permite_conferir_laudo or @permite_conferir_laudo is null )
 and (usuariounimed = @usuariounimed or @usuariounimed is null )
 and (gerente = @gerente or @gerente is null )
 and (naopermitecancelarregistros = @naopermitecancelarregistros or @naopermitecancelarregistros is null )
 and (permissaopredevolucao = @permissaopredevolucao or @permissaopredevolucao is null )
 and (permissaodevolucao = @permissaodevolucao or @permissaodevolucao is null )
 and (permitedevolucaodireta = @permitedevolucaodireta or @permitedevolucaodireta is null )
 and (medico_cadastrohonorario = @medico_cadastrohonorario or @medico_cadastrohonorario is null )
 and (relprescsomentedieta = @relprescsomentedieta or @relprescsomentedieta is null )
 and (cpf = @cpf or @cpf is null )
 and (rg = @rg or @rg is null )
 and (datanasc = @datanasc or @datanasc is null )
 and (inicializarsenha = @inicializarsenha or @inicializarsenha is null )
 and (data_atualizacao_senha = @data_atualizacao_senha or @data_atualizacao_senha is null )
 and (pres_cad_tutor = @pres_cad_tutor or @pres_cad_tutor is null )
end
go

