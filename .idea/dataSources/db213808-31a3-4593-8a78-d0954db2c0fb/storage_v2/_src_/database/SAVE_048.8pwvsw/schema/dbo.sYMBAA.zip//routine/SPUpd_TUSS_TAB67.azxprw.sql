 
-- =============================================
-- Author:		M2 TECNOLOGIA
-- Create date:	06/09/2017
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPUpd_TUSS_TAB67	@CODIGO int,
	@INICIOVIGENCIA datetime,
	@DESCRICAO varchar(1000),
	@FIMVIGENCIA datetime,
	@FIMIMPLANTACAO datetime
AS
BEGIN
	SET NOCOUNT ON
	UPDATE TUSS_TAB67
	SET
		DESCRICAO = @DESCRICAO,
		FIMVIGENCIA = @FIMVIGENCIA,
		FIMIMPLANTACAO = @FIMIMPLANTACAO
	WHERE
		CODIGO = @CODIGO
		AND INICIOVIGENCIA = @INICIOVIGENCIA
END
go

