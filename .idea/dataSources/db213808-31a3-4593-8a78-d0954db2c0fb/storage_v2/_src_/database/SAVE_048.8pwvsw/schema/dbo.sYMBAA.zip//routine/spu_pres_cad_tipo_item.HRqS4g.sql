-- =============================================
-- author:		m2 tecnologia
-- create date:	27/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spu_pres_cad_tipo_item
	@id int ,
	@descricao varchar(50)  = null,
	@ordemimpressao int  = null,
	@utilizavia int  = null,
	@utilizaunidade int  = null,
	@atualizacao varchar(150)  = null,
	@utilizaintervalo int  = null,
	@utilizaapresentacao int  = null,
	@log bigint  = null,
	@utilizaprodutoestoque int  = null,
	@exibe_em_dispensacao int  = null,
	@exibe_em_impressao int  = null,
	@assoc_material int  = null,
	@assoc_medicamento int  = null,
	@assoc_procedimento int  = null,
	@assoc_taxa int  = null,
	@exibe_em_prescricao int  = null
as
begin
	set nocount on
	update dbo.pres_cad_tipo_item
	set
		descricao = @descricao,
		ordemimpressao = @ordemimpressao,
		utilizavia = @utilizavia,
		utilizaunidade = @utilizaunidade,
		atualizacao = @atualizacao,
		utilizaintervalo = @utilizaintervalo,
		utilizaapresentacao = @utilizaapresentacao,
		log = @log,
		utilizaprodutoestoque = @utilizaprodutoestoque,
		exibe_em_dispensacao = @exibe_em_dispensacao,
		exibe_em_impressao = @exibe_em_impressao,
		assoc_material = @assoc_material,
		assoc_medicamento = @assoc_medicamento,
		assoc_procedimento = @assoc_procedimento,
		assoc_taxa = @assoc_taxa,
		exibe_em_prescricao = @exibe_em_prescricao
	where
		id = @id
end
go

