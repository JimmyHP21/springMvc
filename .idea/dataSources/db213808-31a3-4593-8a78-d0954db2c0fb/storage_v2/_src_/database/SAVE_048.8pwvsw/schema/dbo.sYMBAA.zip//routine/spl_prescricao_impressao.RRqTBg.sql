-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spl_prescricao_impressao

as
begin
	set nocount on
	select
	 id, data_impressao, prescricao, atualizacao, log, data, usuario
	from dbo.prescricao_impressao
end
go

