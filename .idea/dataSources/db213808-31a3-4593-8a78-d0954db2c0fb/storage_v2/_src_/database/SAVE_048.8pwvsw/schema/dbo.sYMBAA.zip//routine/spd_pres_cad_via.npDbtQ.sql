-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spd_pres_cad_via
	@via int 
as
begin
	set nocount on
	delete from dbo.pres_cad_via
	where
		via = @via
end
go

