CREATE PROCEDURE SPX_ATUALIZA_ASSOCIACAO_TNUMM 
                @CONVENIO AS INTEGER, 
                @PRODUTO AS INTEGER = NULL, 
                @USUARIO AS INTEGER = 0 
AS 
BEGIN 
BEGIN TRY 
   BEGIN TRANSACTION; 
   DECLARE @REFERENCIA AS DATETIME 
 
   /* 
          SET @PRODUTO = 1000090 
          SET @CONVENIO = 1 
          SET @USUARIO = 168 
          */ 
 
   SET @REFERENCIA = (SELECT MAX(DATA_IMPORTACAO) FROM TNUMM WHERE STATUS = 1) 
 
   IF @REFERENCIA IS NULL RETURN 
   --REMOVE O FIM DE VIGENCIA QUANDO FOR MENOR QUE O INICIO 
   UPDATE P 
      SET P.DATA_FIM_VIGENCIA = NULL 
     FROM PRODUTOTNUMM_ASSOCIADO P 
    WHERE P.CONVENIO = @CONVENIO 
      AND P.DATA_IMPORTACAO <= @REFERENCIA 
      AND P.DATA_FIM_VIGENCIA < P.DATA_INICIO_VIGENCIA 
      AND (P.PRODUTO = @PRODUTO OR @PRODUTO IS NULL); 
 
   --Eliminiar registros duplicados 
   DELETE P 
   FROM PRODUTOTNUMM_ASSOCIADO P 
   WHERE P.UTILIZADO = 1 
     AND P.CONVENIO = @CONVENIO 
     AND (P.PRODUTO = @PRODUTO OR @PRODUTO IS NULL) 
     AND P.ID <> ( 
           SELECT TOP 1 PX.ID 
             FROM PRODUTOTNUMM_ASSOCIADO PX 
            WHERE PX.PRODUTO = P.PRODUTO 
              AND PX.CONVENIO = P.CONVENIO 
              AND PX.DATA_INICIO_VIGENCIA = P.DATA_INICIO_VIGENCIA 
              AND PX.UTILIZADO = 1 
              ORDER BY PX.ID ASC 
   ); 
    
   --Remove final de vigência menor que inicio de vigência em associações 
   UPDATE P 
      SET P.DATA_IMPORTACAO = CONVERT(DATETIME,-1), 
          P.DATA_FIM_VIGENCIA = (CASE WHEN P.DATA_FIM_VIGENCIA < P.DATA_INICIO_VIGENCIA THEN NULL ELSE P.DATA_FIM_VIGENCIA END) 
     FROM PRODUTOTNUMM_ASSOCIADO P 
    WHERE P.UTILIZADO = 1 
      AND P.CONVENIO = @CONVENIO 
      AND P.DATA_IMPORTACAO <= @REFERENCIA 
      AND (P.PRODUTO = @PRODUTO OR @PRODUTO IS NULL); 
    
   --INSERE FIM DE VIGENCIA NAS ASSOCIAÇÕES ANTERIORES 
   UPDATE P 
   SET P.DATA_FIM_VIGENCIA = ( 
           CASE 
               WHEN T1.CD_TNUMM IS NULL 
                   THEN (@REFERENCIA - 1)  
--REVER 
               WHEN T2.CD_TNUMM IS NULL 
                   THEN ( 
                           CASE 
                               WHEN P.DATA_FIM_VIGENCIA > T1.DATA_FIM_VIGENCIA 
                                   THEN T1.DATA_FIM_VIGENCIA 
                               WHEN P.DATA_FIM_VIGENCIA <= ISNULL(T1.DATA_FIM_VIGENCIA, P.DATA_FIM_VIGENCIA) 
                                   THEN ISNULL(T1.DATA_FIM_VIGENCIA, P.DATA_FIM_VIGENCIA) 
                               WHEN P.DATA_FIM_VIGENCIA IS NULL AND P.DATA_INICIO_VIGENCIA = @REFERENCIA 
                                   THEN NULL 
                               ELSE (@REFERENCIA - 1) 
                               END 
                           ) 
               ELSE ISNULL(T2.DATA_FIM_VIGENCIA, P.DATA_FIM_VIGENCIA) 
               END 
           ), 
           P.DATA_IMPORTACAO = @REFERENCIA, 
           P.DATA_ASSOCIACAO = GETDATE(), 
           P.USUARIO_ASSOCIACAO = @USUARIO 
   --SELECT  T1.CD_TNUMM, T2.CD_TNUMM, P.DATA_FIM_VIGENCIA 
   FROM PRODUTOTNUMM_ASSOCIADO P 
   LEFT JOIN TNUMM T1 ON T1.CD_TNUMM = P.CD_TNUMM 
       AND T1.TIPO_PRODUTO = P.TIPO_PRODUTO 
       AND T1.TIPO_CODIFICACAO = P.TIPO_CODIFICACAO 
       AND T1.STATUS = 1 
   LEFT JOIN TNUMM T2 ON T2.CD_TNUMM = P.CD_TNUMM 
       AND T2.TIPO_PRODUTO = P.TIPO_PRODUTO 
       AND T2.TIPO_CODIFICACAO = P.TIPO_CODIFICACAO 
       AND T2.UNIDADE_MIN_FRACAO = P.UNIDADE_MIN_FRACAO 
       AND T2.VALOR_FATOR_CONVERSAO = P.VALOR_FATOR_CONVERSAO 
       AND T2.CD_TABELA = P.CD_TABELA 
       AND P.PRECO = ROUND(( 
           CASE 
               WHEN P.TIPO_PRODUTO = 1 
                   THEN ( 
                           CASE 
                               WHEN P.TIPO_PRECO = 0 
                                   THEN T2.PRECO_PF 
                               WHEN P.TIPO_PRECO = 1 
                                   THEN T2.PRECO_PF_12 
                               WHEN P.TIPO_PRECO = 2 
                                   THEN T2.PRECO_PF_17 
                               WHEN P.TIPO_PRECO = 3 
                                   THEN T2.PRECO_PF_17_ALC 
                               WHEN P.TIPO_PRECO = 4 
                                   THEN T2.PRECO_PF_17_5 
                               WHEN P.TIPO_PRECO = 5 
                                   THEN T2.PRECO_PF_17_5_ALC 
                               WHEN P.TIPO_PRECO = 6 
                                   THEN T2.PRECO_PF_18 
                               WHEN P.TIPO_PRECO = 7 
                                   THEN T2.PRECO_PF_18_ALC 
                               WHEN P.TIPO_PRECO = 8 
                                   THEN T2.PRECO_PF_20 
                               END 
                           ) 
               ELSE ( 
                       CASE 
                           WHEN P.TIPO_PRECO = 0 
                               THEN T2.PRECO_UNICO 
                           WHEN P.TIPO_PRECO = 1 
                               THEN T2.PRECO_FABRICA 
                           WHEN P.TIPO_PRECO = 2 
                               THEN T2.VALOR_INTERCAMBIO 
                           END 
                       ) 
               END 
           ),2) 
       AND T2.STATUS = 1 
   WHERE 1 = 1 
       AND P.DATA_IMPORTACAO = CONVERT(DATETIME,-1) 
       AND P.DATA_FIM_VIGENCIA IS NULL 
       AND P.UTILIZADO = 1 
       AND P.CONVENIO = @CONVENIO 
       AND P.DATA_IMPORTACAO <> @REFERENCIA 
       AND (P.PRODUTO = @PRODUTO OR @PRODUTO IS NULL); 
 
   -- ATUALIZA OS VALORES CASO FOR REALIZADO A MESMA IMPORTAÇÃO 
   UPDATE P 
       SET P.TIPO_PRODUTO = T1.TIPO_PRODUTO 
       ,P.TIPO_CODIFICACAO = T1.TIPO_CODIFICACAO 
       ,P.UNIDADE_MIN_FRACAO = T1.UNIDADE_MIN_FRACAO 
       ,P.VALOR_FATOR_CONVERSAO = T1.VALOR_FATOR_CONVERSAO 
       ,P.CD_TABELA = T1.CD_TABELA 
       ,P.PRECO = ROUND(( 
           CASE 
               WHEN P.TIPO_PRODUTO = 1 
                   THEN ( 
                           CASE 
                               WHEN P.TIPO_PRECO = 0 
                                   THEN T1.PRECO_PF 
                               WHEN P.TIPO_PRECO = 1 
                                   THEN T1.PRECO_PF_12 
                               WHEN P.TIPO_PRECO = 2 
                                   THEN T1.PRECO_PF_17 
                               WHEN P.TIPO_PRECO = 3 
                                   THEN T1.PRECO_PF_17_ALC 
                               WHEN P.TIPO_PRECO = 4 
                                   THEN T1.PRECO_PF_17_5 
                               WHEN P.TIPO_PRECO = 5 
                                   THEN T1.PRECO_PF_17_5_ALC 
                               WHEN P.TIPO_PRECO = 6 
                                   THEN T1.PRECO_PF_18 
                               WHEN P.TIPO_PRECO = 7 
                                   THEN T1.PRECO_PF_18_ALC 
                               WHEN P.TIPO_PRECO = 8 
                                   THEN T1.PRECO_PF_20 
                               END 
                           ) 
               ELSE ( 
                       CASE 
                           WHEN P.TIPO_PRECO = 0 
                               THEN T1.PRECO_UNICO 
                           WHEN P.TIPO_PRECO = 1 
                               THEN T1.PRECO_FABRICA 
                           WHEN P.TIPO_PRECO = 2 
                               THEN T1.VALOR_INTERCAMBIO 
                           END 
                       ) 
               END 
           ),2) 
   FROM PRODUTOTNUMM_ASSOCIADO P 
   INNER JOIN TNUMM T1 ON T1.CD_TNUMM = P.CD_TNUMM 
       AND T1.TIPO_PRODUTO = P.TIPO_PRODUTO 
       AND T1.TIPO_CODIFICACAO = P.TIPO_CODIFICACAO 
       AND T1.STATUS = 1 
        
   LEFT JOIN TNUMM T2 ON T2.CD_TNUMM = P.CD_TNUMM 
       AND T2.TIPO_PRODUTO = P.TIPO_PRODUTO 
       AND T2.TIPO_CODIFICACAO = P.TIPO_CODIFICACAO 
       AND T2.UNIDADE_MIN_FRACAO = P.UNIDADE_MIN_FRACAO 
       AND T2.VALOR_FATOR_CONVERSAO = P.VALOR_FATOR_CONVERSAO 
       AND T2.CD_TABELA = P.CD_TABELA 
       AND P.PRECO = ROUND(( 
           CASE 
               WHEN P.TIPO_PRODUTO = 1 
                   THEN ( 
                           CASE 
                               WHEN P.TIPO_PRECO = 0 
                                   THEN T2.PRECO_PF 
                               WHEN P.TIPO_PRECO = 1 
                                   THEN T2.PRECO_PF_12 
                               WHEN P.TIPO_PRECO = 2 
                                   THEN T2.PRECO_PF_17 
                               WHEN P.TIPO_PRECO = 3 
                                   THEN T2.PRECO_PF_17_ALC 
                               WHEN P.TIPO_PRECO = 4 
                                   THEN T2.PRECO_PF_17_5 
                               WHEN P.TIPO_PRECO = 5 
                                   THEN T2.PRECO_PF_17_5_ALC 
                               WHEN P.TIPO_PRECO = 6 
                                   THEN T2.PRECO_PF_18 
                               WHEN P.TIPO_PRECO = 7 
                                   THEN T2.PRECO_PF_18_ALC 
                               WHEN P.TIPO_PRECO = 8 
                                   THEN T2.PRECO_PF_20 
                               END 
                           ) 
               ELSE ( 
                       CASE 
                           WHEN P.TIPO_PRECO = 0 
                               THEN T2.PRECO_UNICO 
                           WHEN P.TIPO_PRECO = 1 
                               THEN T2.PRECO_FABRICA 
                           WHEN P.TIPO_PRECO = 2 
                               THEN T2.VALOR_INTERCAMBIO 
                           END 
                       ) 
               END 
           ),2) 
       AND T2.STATUS = 1 
   WHERE 1 = 1 
       AND T2.CD_TNUMM IS NULL 
       AND P.DATA_IMPORTACAO = @REFERENCIA 
       AND P.UTILIZADO = 1 
       AND P.CONVENIO = @CONVENIO 
       AND (P.PRODUTO = @PRODUTO OR @PRODUTO IS NULL) 
       AND P.DATA_INICIO_VIGENCIA = @REFERENCIA 
 
   --INSERE A NOVA VIGENCIA 
   INSERT INTO PRODUTOTNUMM_ASSOCIADO ( 
       PRODUTO 
       ,CD_TNUMM 
       ,TIPO_PRODUTO 
       ,DATA_INICIO_VIGENCIA 
       ,DATA_FIM_VIGENCIA 
       ,DATA_IMPORTACAO 
       ,UNIDADE_MIN_FRACAO 
       ,VALOR_FATOR_CONVERSAO 
       ,TIPO_PRECO 
       ,PRECO 
       ,TIPO_CODIFICACAO 
       ,CD_TABELA 
       ,DATA_ASSOCIACAO 
       ,USUARIO_ASSOCIACAO 
       ,CONVENIO 
       ,UTILIZADO 
       ) 
   SELECT DISTINCT P.PRODUTO 
       ,T1.CD_TNUMM 
       ,P.TIPO_PRODUTO 
       ,@REFERENCIA AS DATA_INICIO_VIGENCIA 
       ,T1.DATA_FIM_VIGENCIA 
       ,@REFERENCIA AS DATA_IMPORTACAO 
       ,T1.UNIDADE_MIN_FRACAO 
       ,T1.VALOR_FATOR_CONVERSAO 
       ,P.TIPO_PRECO 
       ,ROUND(( 
           CASE 
               WHEN P.TIPO_PRODUTO = 1 
                   THEN ( 
                           CASE 
                               WHEN P.TIPO_PRECO = 0 
                                   THEN T1.PRECO_PF 
                               WHEN P.TIPO_PRECO = 1 
                                   THEN T1.PRECO_PF_12 
                               WHEN P.TIPO_PRECO = 2 
                                   THEN T1.PRECO_PF_17 
                               WHEN P.TIPO_PRECO = 3 
                                   THEN T1.PRECO_PF_17_ALC 
                               WHEN P.TIPO_PRECO = 4 
                                   THEN T1.PRECO_PF_17_5 
                               WHEN P.TIPO_PRECO = 5 
                                   THEN T1.PRECO_PF_17_5_ALC 
                               WHEN P.TIPO_PRECO = 6 
                                   THEN T1.PRECO_PF_18 
                               WHEN P.TIPO_PRECO = 7 
                                   THEN T1.PRECO_PF_18_ALC 
                               WHEN P.TIPO_PRECO = 8 
                                   THEN T1.PRECO_PF_20 
                               END 
                           ) 
               ELSE ( 
                       CASE 
                           WHEN P.TIPO_PRECO = 0 
                               THEN T1.PRECO_UNICO 
                           WHEN P.TIPO_PRECO = 1 
                               THEN T1.PRECO_FABRICA 
                           WHEN P.TIPO_PRECO = 2 
                               THEN T1.VALOR_INTERCAMBIO 
                           END 
                       ) 
               END 
           ),2) AS PRECO 
       ,P.TIPO_CODIFICACAO 
       ,T1.CD_TABELA 
       ,GETDATE() AS DATA_ASSOCIACAO 
       ,@USUARIO 
       ,@CONVENIO 
       ,1 
   FROM PRODUTOTNUMM_ASSOCIADO P 
   INNER JOIN TNUMM T1 ON T1.CD_TNUMM = P.CD_TNUMM 
       AND T1.TIPO_PRODUTO = P.TIPO_PRODUTO 
       AND T1.TIPO_CODIFICACAO = P.TIPO_CODIFICACAO 
       AND T1.STATUS = 1 
        
   LEFT JOIN TNUMM T2 ON T2.CD_TNUMM = P.CD_TNUMM 
       AND T2.TIPO_PRODUTO = P.TIPO_PRODUTO 
       AND T2.TIPO_CODIFICACAO = P.TIPO_CODIFICACAO 
       AND T2.UNIDADE_MIN_FRACAO = P.UNIDADE_MIN_FRACAO 
       AND T2.VALOR_FATOR_CONVERSAO = P.VALOR_FATOR_CONVERSAO 
       AND T2.CD_TABELA = P.CD_TABELA 
       AND P.PRECO = ROUND(( 
           CASE 
               WHEN P.TIPO_PRODUTO = 1 
                   THEN ( 
                           CASE 
                               WHEN P.TIPO_PRECO = 0 
                                   THEN T2.PRECO_PF 
                               WHEN P.TIPO_PRECO = 1 
                                   THEN T2.PRECO_PF_12 
                               WHEN P.TIPO_PRECO = 2 
                                   THEN T2.PRECO_PF_17 
                               WHEN P.TIPO_PRECO = 3 
                                   THEN T2.PRECO_PF_17_ALC 
                               WHEN P.TIPO_PRECO = 4 
                                   THEN T2.PRECO_PF_17_5 
                               WHEN P.TIPO_PRECO = 5 
                                   THEN T2.PRECO_PF_17_5_ALC 
                               WHEN P.TIPO_PRECO = 6 
                                   THEN T2.PRECO_PF_18 
                               WHEN P.TIPO_PRECO = 7 
                                   THEN T2.PRECO_PF_18_ALC 
                               WHEN P.TIPO_PRECO = 8 
                                   THEN T2.PRECO_PF_20 
                               END 
                           ) 
               ELSE ( 
                       CASE 
                           WHEN P.TIPO_PRECO = 0 
                               THEN T2.PRECO_UNICO 
                           WHEN P.TIPO_PRECO = 1 
                               THEN T2.PRECO_FABRICA 
                           WHEN P.TIPO_PRECO = 2 
                               THEN T2.VALOR_INTERCAMBIO 
                           END 
                       ) 
               END 
           ),2) 
       AND T2.STATUS = 1 
   WHERE 1 = 1 
       AND T2.CD_TNUMM IS NULL 
       AND P.DATA_IMPORTACAO = @REFERENCIA 
       AND P.UTILIZADO = 1 
       AND P.CONVENIO = @CONVENIO 
       AND (P.PRODUTO = @PRODUTO OR @PRODUTO IS NULL) 
       AND NOT EXISTS ( 
           SELECT TOP 1 1 
             FROM PRODUTOTNUMM_ASSOCIADO PX 
            WHERE PX.PRODUTO = P.PRODUTO 
              AND PX.CONVENIO = P.CONVENIO 
              AND PX.DATA_INICIO_VIGENCIA = @REFERENCIA 
              AND PX.UTILIZADO = 1 
       ); 
        
   UPDATE PRODUTOTNUMM_ASSOCIADO 
   SET DATA_IMPORTACAO = @REFERENCIA 
   WHERE 1 =1 
   AND UTILIZADO = 1 
   AND CONVENIO = @CONVENIO 
   AND (DATA_IMPORTACAO IS NULL) 
   AND (PRODUTO = @PRODUTO OR @PRODUTO IS NULL); 
    
   UPDATE CONVENIOS 
   SET REFERENCIA_TNUMM = @REFERENCIA 
   WHERE CONVENIO = @CONVENIO 
   COMMIT TRANSACTION; 
END TRY 
BEGIN CATCH 
   IF @@TRANCOUNT > 0  ROLLBACK TRANSACTION; 
END CATCH 
END
go

