-- =============================================
-- author:		m2 tecnologia
-- create date:	20/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spd_produtocentrocustolote
	@centrocusto smallint ,
	@produto int ,
	@lote char(10) ,
	@validade datetime 
as
begin
	set nocount on
	delete from dbo.produtocentrocustolote
	where
		centrocusto = @centrocusto
		and produto = @produto
		and lote = @lote
		and validade = @validade
end
go

