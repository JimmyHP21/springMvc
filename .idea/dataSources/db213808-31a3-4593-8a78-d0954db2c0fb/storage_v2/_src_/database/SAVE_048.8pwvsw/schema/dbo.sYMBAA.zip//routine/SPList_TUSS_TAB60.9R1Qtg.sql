 
-- =============================================
-- Author:		M2 TECNOLOGIA
-- Create date:	06/09/2017
-- Description:	
-- Revisions:	
-- =============================================
CREATE PROCEDURE SPList_TUSS_TAB60
AS
BEGIN
	SET NOCOUNT ON

	SELECT
	 CODIGO, 
	 DESCRICAO, 
	 DETALHE, 
	 INICIOVIGENCIA, 
	 FIMVIGENCIA, 
	 FIMIMPLANTACAO
	FROM TUSS_TAB60
END
go

