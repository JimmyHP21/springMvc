-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spl_prescricao

as
begin
	set nocount on
	select
	 id, tipoatendimento, registro, medico, data, datacriacao, datafinalizacao, usuario, atualizacao, statusprescricao, log, urgente, horario_inicio
	from dbo.prescricao
end
go

