CREATE PROCEDURE [dbo].[SP_TISS_030200_CONSULTA] @REGISTRO      BIGINT = NULL,
                                         @TIPO_REGISTRO VARCHAR(MAX) = NULL,
										 @GUIA		    VARCHAR(MAX) = NULL
AS
BEGIN
  
    IF @TIPO_REGISTRO = 'AMBULATORIAL'
        OR @TIPO_REGISTRO = 'URGENCIA'
      BEGIN
					SELECT DISTINCT
-- ----------------------------------------------------------------------------------------------------------------------------------------------
-- --------CHAVES--------------------------------------------------------------------------------------------------------------------------------
-- ----------------------------------------------------------------------------------------------------------------------------------------------
          ( CASE
              WHEN ATEND.AMBUPA = 1 THEN 'AMBULATORIAL'
              ELSE 'URGENCIA'
            END )                                                           AS TIPO_REGISTRO,
          ATEND.REGISTRO                                                    AS REGISTRO,
          ATEND.FATURACONTA                                                 AS FATURA,
          RDT.GUIAINTERNA                                                   AS GUIA,
-- ----------------------------------------------------------------------------------------------------------------------------------------------
-- --------LOTE----------------------------------------------------------------------------------------------------------------------------------
-- ----------------------------------------------------------------------------------------------------------------------------------------------
          ATEND.FATURACONTA                                                 AS numeroLote,-- N�mero do lote  |  String  |  12  |    |  N�mero atribu�do pelo prestador ao enviar um conjunto de guias para a operadora.  |  Obrigat�rio.
-- ----------------------------------------------------------------------------------------------------------------------------------------------
-- --------CABECALHO GUIA - OBRIGATORIO----------------------------------------------------------------------------------------------------------
-- ----------------------------------------------------------------------------------------------------------------------------------------------
          RIGHT(REPLICATE('0',6) + CAST(CONV.REGISTROANS AS VARCHAR(6)),6)  AS cabecalhoConsultaRegistroANS,-- Registro ANS  |  String  |  6  |    |  Registro da operadora de plano privado de assist�ncia � sa�de na Ag�ncia Nacional de Sa�de Suplementar (ANS)  |  Obrigat�rio.			
		  (CASE WHEN ISNULL(CONV.TISS_CONSULTA_TAG_NUMEROGUIAPRESTADOR,'GPRE') = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
		  	    WHEN CONV.TISS_CONSULTA_TAG_NUMEROGUIAPRESTADOR = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
				WHEN CONV.TISS_CONSULTA_TAG_NUMEROGUIAPRESTADOR = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
				WHEN CONV.TISS_CONSULTA_TAG_NUMEROGUIAPRESTADOR = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
				WHEN CONV.TISS_CONSULTA_TAG_NUMEROGUIAPRESTADOR = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
				WHEN CONV.TISS_CONSULTA_TAG_NUMEROGUIAPRESTADOR = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
		   END)                                                            AS cabecalhoConsultaNumeroGuiaPrestador,-- N�mero da guia no prestador  |  String  |  20  |    |  N�mero que identifica a guia no prestador de servi�os.  |  "Obrigat�rio. � facultada �s operadoras e prestadores de servi�os a utiliza��o de c�digo de barras, impressos imediatamente abaixo da numera��o. O c�digo de barras deve seguir o padr�o CODE 39 de alta densidade."
		   CONV.CONVENIO												   AS CONVENIO,
-- ----------------------------------------------------------------------------------------------------------------------------------------------
-- --------BENEFICIARIO - OBRIGATORIO------------------------------------------------------------------------------------------------------------
-- ----------------------------------------------------------------------------------------------------------------------------------------------
-- LEFT(REPLICATE('0',3) + RIGHT(ISNULL(ATEND.UNIDADE,0),3),3) + LEFT(REPLICATE('0',17)+RIGHT(ISNULL(ATEND.CARTEIRINHA,0),17),17) AS numeroCarteira, -- N�mero da carteira do benefici�rio  |  String  |  20  |    |  N�mero da carteira do benefici�rio na operadora  |  Obrigat�rio.
          DBO.FN_MASCARA_NUMERO(CAST(ISNULL(ATEND.UNIDADE, '') AS VARCHAR(5))
          + CAST(ISNULL(ATEND.CARTEIRINHA, '') 
		  AS VARCHAR(20)), CONV.TISS_NUMERO_CARTEIRA_MASCARA)               AS dadosBeneficiarioNumeroCarteira,-- N�mero da carteira do benefici�rio  |  String  |  20  |    |  N�mero da carteira do benefici�rio na operadora  |  Obrigat�rio.
          PRON.NOME                                                         AS dadosBeneficiarioNomeBeneficiario,-- Nome do benefici�rio  |  String  |  70  |    |  Nome do benefici�rio  |  Obrigat�rio.
          NULL                                                              AS dadosBeneficiarioIdentificadorBeneficiario,-- Identificador biom�trico do benefici�rio  |  Bin�rio  |    |    |  C�digo biom�trico de identifica��o do benefici�rio  |  Opcional.
          PRON.CARTAOSUS                                                    AS dadosBeneficiarioNumeroCNS,-- Cart�o Nacional de Sa�de  |  String  |  15  |    |  N�mero do Cart�o Nacional de Sa�de do benefici�rio  |  Condicionado. Deve ser preenchido caso o benefici�rio possua o n�mero do Cart�o Nacional de Sa�de.
          ( CASE
              WHEN LEFT(PRON.NOME, 2) = 'RN' THEN 'S'
              ELSE 'N'
            END )                                                           AS dadosBeneficiarioAtendimentoRN,-- Indicador de atendimento ao rec�m-nato  |  String  |  1  |    |  Indica se o paciente � um rec�m-nato que est� sendo atendido no contrato do respons�vel, nos termos do Art. 12, inciso III, al�nea a, da Lei 9.656, de 03 de junho de 1998.  |  Obrigat�rio.  Deve ser informado "S" - sim - caso o atendimento seja do rec�m-nato e o benefici�rio seja o respons�vel e "N" - n�o - quando o atendimento for do pr�prio benefici�rio.			
-- ----------------------------------------------------------------------------------------------------------------------------------------------
-- --------CONTRATADO EXECUTANTE - OBRIGATORIO---------------------------------------------------------------------------------------------------
-- ----------------------------------------------------------------------------------------------------------------------------------------------
          PREE.TIPO_PRESTADOR_EXECUTANTE                                    AS contratadoExecutanteItemTipo,
		  DBO.FN_SONUMERICO(PREE.CODIGO_PRESTADOR_EXECUTANTE)               AS contratadoExecutanteItem,-- C�digo do contratado executante na operadora  |  String  |  14  |    |  C�digo identificador do prestador contratado executante junto a operadora, conforme contrato estabelecido.  |  Obrigat�rio.
          PREE.NOME_PRESTADOR_EXECUTANTE                                    AS contratadoExecutanteNomeContratado,-- Nome do contratado executante  |  String  |  70  |    |  Raz�o Social, nome fantasia ou nome do prestador contratado da operadora que executou o procedimento.  |  Obrigat�rio.
          PAR.CNES                                                          AS contratadoExecutanteCNES,-- C�digo no Cadastro Nacional de Estabelecimentos de Sa�de do executante  |  String  |  7  |    |  C�digo do prestador executante no Cadastro Nacional de Estabelecimentos de Sa�de do Minist�rio da Sa�de (CNES/MS)  |  Obrigat�rio. Caso o prestador ainda n�o possua o c�digo do CNES preencher o campo com 9999999.		  
-- ----------------------------------------------------------------------------------------------------------------------------------------------
-- --------PROFISSIONAL EXECUTANTE - OBRIGATORIO-------------------------------------------------------------------------------------------------
-- ----------------------------------------------------------------------------------------------------------------------------------------------
          MEXEC.NOME                                                        AS profissionalExecutanteNomeProfissional,-- Nome do profissional solicitante  |  String  |  70  |    |  Nome do profissional que est� solicitando o procedimento.  |  Condicionado. Deve ser preenchido quando o prestador contratado referido no campo Nome do Contratado for pessoa jur�dica.
-- MEXEC.CONSELHOPROFISSIONAL
          ISNULL(T26.CODIGO,10)                                             AS profissionalExecutanteConselhoProfissional,-- Conselho profissional do solicitante  |  String  |  2  |    |  C�digo do conselho profissional do solicitante do procedimento ou item assistencial,  conforme tabela de dom�nio n� 26.  |  Obrigat�rio.
          MEXEC.CRM                                                         AS profissionalExecutanteNumeroConselhoProfissional,-- N�mero do solicitante no conselho profissional  |  String  |  15  |    |  N�mero de registro do profissional solicitante no respectivo Conselho Profissional.  |  Obrigat�rio.
          UFEXEC.CODIGO_TUSS                                                AS profissionalExecutanteUF,-- UF do conselho do profissional solicitante  |  String  |  2  |    |  Sigla da Unidade Federativa do Conselho Profissional do solicitante do procedimento ou item assistencial, conforme tabela de dom�nio n� 59.  |  Obrigat�rio.
-- MEXEC.CBO
          ISNULL(T24.CODIGO,'999999')                                       AS profissionalExecutanteCBOS,-- C�digo na Classifica��o Brasileira de Ocupa��es do solicitante  |  String  |  6  |    |  C�digo na Classifica��o Brasileira de Ocupa��es do profissional solicitante do procedimento ou item assistencial, conforme tabela de dom�nio n� 24.  |  Obrigat�rio.
-- ----------------------------------------------------------------------------------------------------------------------------------------------
-- --------DADOS DO ATENDIMENTO - OBRIGATORIO----------------------------------------------------------------------------------------------------
-- ----------------------------------------------------------------------------------------------------------------------------------------------
		  T52.CODIGO                          							    AS dadosAtendimentoTipoConsulta,-- Tipo de consulta  |  String  |  1  |    |  C�digo do tipo de consulta realizada, conforme tabela de dom�nio n� 52.  |  Condicionado. Deve ser preenchido caso o campo Tipo de Atendimento seja igual a Consulta.
          ATEND.DATAINTERNACAO                                              AS dadosAtendimentoDataAtendimento,-- Data de atendimento  |  Date  |  8  |  DDMMAAAA  |  Data em que o atendimento/procedimento foi realizado  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.			
          HON.TIPO_TABELA                                                   AS dadosAtendimentoProcedimentoCodigoTabela,-- Tabela de refer�ncia do procedimento ou item assistencial realizado  |  String  |  2  |    |  C�digo da tabela utilizada para identificar os procedimentos realizados ou itens assistenciais utilizados, conforme tabela de dom�nio n� 87.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          HON.COD_TUSS                                                      AS dadosAtendimentoProcedimentoCodigoProcedimento,-- C�digo do procedimento realizado  |  String  |  10  |    |  C�digo identificador do procedimento realizado pelo prestador, conforme tabela de dom�nio.  |  Condicionado. Deve ser preenchido sempre que houver procedimento realizado sendo informado.
          ISNULL(MOVIM.VALORUNITARIO, 0) * ISNULL(MOVIM.QUANTIDADE, 0)      AS dadosAtendimentoProcedimentoValorProcedimento,-- Valor total dos dos procedimentos realizados  |  Num�rico  |  6,2  |    |  Valor total dos itens assistenciais utilizados, considerando a quantidade do item assistencial, o valor unit�rio e o fator de redu��o ou acr�scimo.  |  Obrigat�rio.			
-- ----------------------------------------------------------------------------------------------------------------------------------------------
-- --------GERAL---------------------------------------------------------------------------------------------------------------------------------
-- ----------------------------------------------------------------------------------------------------------------------------------------------
		   (CASE WHEN ISNULL(CONV.TISS_CONSULTA_TAG_NUMEROGUIAOPERADORA,'GOPE') = 'GOPE' THEN CONVERT(VARCHAR,RDT.GUIAOPERADORA)
				WHEN CONV.TISS_CONSULTA_TAG_NUMEROGUIAOPERADORA = 'GTISS' THEN CONVERT(VARCHAR,RDT.GUIATISS)
				WHEN CONV.TISS_CONSULTA_TAG_NUMEROGUIAOPERADORA = 'GINT' THEN CONVERT(VARCHAR,RDT.GUIAINTERNA)
				WHEN CONV.TISS_CONSULTA_TAG_NUMEROGUIAOPERADORA = 'GPRE' THEN CONVERT(VARCHAR,RDT.GUIAPRESTADOR)
				WHEN CONV.TISS_CONSULTA_TAG_NUMEROGUIAOPERADORA = 'GPRI' THEN CONVERT(VARCHAR,RDT.GUIAPRINCIPAL)
				WHEN CONV.TISS_CONSULTA_TAG_NUMEROGUIAOPERADORA = 'SENHA' THEN CONVERT(VARCHAR,RDT.SENHA)
		   END)                                                             AS numeroGuiaOperadora,-- N�mero da guia atribu�do pela operadora  |  String  |  20  |    |  N�mero que identifica a guia atribu�do pela operadora.  |  Condicionado. Deve ser preenchido caso a operadora atribua outro n�mero � guia, independente do n�mero que a identifica no prestador.
          T36.CODIGO                                                        AS indicacaoAcidente,-- Indica��o de acidente ou doen�a relacionada  |  String  |  1  |    |  Indica se o atendimento � devido a acidente ocorrido com o benefici�rio ou doen�a relacionada, conforme tabela de dom�nio n� 36.  |  Obrigat�rio.		  
          NULL                                                              AS observacao,-- Observa��o / Justificativa  |  String  |  500  |    |  Campo utilizado para adicionar quaisquer observa��es sobre o atendimento ou justificativas que julgue necess�rio  |  Opcional.
-- ASSINATURA DIGITAL - OPCIONAL
          NULL                                                              AS assinaturaDigital -- Assinatura digital do prestador  |  Bin�rio  |    |    |  Assinatura digital do prestador que est� encaminhando a mensagem.  |  Condicionado. Deve ser preenchido quando o prestador assinar digitalmente a mensagem.
          FROM   V_RECUPERADADOSTISS AS RDT
				CROSS JOIN PARAMETRO AS PAR WITH (READPAST)
                 INNER JOIN AMBULATORIAL AS ATEND WITH (READPAST)
                         ON ATEND.REGISTRO = RDT.REGISTRO
                            AND RDT.TIPOREGISTRO = 1
                            AND ISNULL(ATEND.CANCELADO, 0) = 0
                            AND ATEND.REGISTRO IN ( @REGISTRO )
							AND RDT.GUIAINTERNA = @GUIA
							
                 INNER JOIN FICHAS AS PRON WITH (READPAST)
                         ON PRON.FICHA = ATEND.FICHA
						 
                 INNER JOIN CONVENIOS AS CONV WITH (READPAST)
                         ON ATEND.CONVENIO = CONV.CONVENIO
						 
                 LEFT JOIN CONVENIODATA_PERIODO AS CDP WITH (READPAST)
                         ON CONV.CONVENIO = CDP.CONVENIO
                            AND CDP.FATURA = ATEND.FATURACONTA
				 INNER JOIN V_TISS_VERIFICA_CONSULTA CON
						ON CON.REGISTRO = ATEND.REGISTRO
					   AND RDT.GUIAINTERNA = CON.GUIAINTERNA
						   
                 INNER JOIN MOVIM_AMB AS MOVIM WITH (READPAST)
                         ON MOVIM.REGISTRO = ATEND.REGISTRO
							AND (MOVIM.QUANTIDADE * MOVIM.VALORUNITARIO ) > 0
                            AND MOVIM.TIPOLANCAMENTO = 3
                            AND ISNULL(MOVIM.GUIAINTERNA, 0) = RDT.GUIAINTERNA
							
                 LEFT JOIN TUSS_PROCEDIMENTO AS HON WITH (READPAST)
                        ON HON.TIPO_DESC = 'PROCEDIMENTO'
					   AND HON.COD_SAVE = MOVIM.PROCEDIMENTO
					   AND MOVIM.TIPOLANCAMENTO IN ( 2, 3 )
					   AND ( CASE
								 WHEN MOVIM.TIPOLANCAMENTO = 2 THEN CONV.TABELA
								 ELSE CONV.TABELAHONORARIO
							 END ) = HON.TAB_CONVENIO				 
                 AND MOVIM.DATACONSUMO BETWEEN HON.INICIO_VIGENCIA AND ISNULL(HON.FIM_VIGENCIA, GETDATE())
				 							
                 LEFT JOIN ATUACOES AS ATO WITH (READPAST)
                        ON ATO.ATUACAO = MOVIM.ATUACAO						
                 LEFT JOIN TUSS_TAB35 AS T35 WITH (READPAST)
                        ON T35.CODIGO = ATO.GRAUPARTICIPACAO
													   
                 LEFT JOIN MEDICOS AS MEXEC WITH (READPAST)
                        ON MEXEC.MEDICO = MOVIM.MEDICO
                 LEFT JOIN UF AS UFEXEC WITH (READPAST)
                        ON UFEXEC.ID_UF = MEXEC.UFCRM
				 LEFT JOIN V_TISS_PRESTADOR_EXECUTANTE PREE
						ON PREE.CONVENIO = ATEND.CONVENIO
					   AND PREE.MEDICO = ISNULL(MEXEC.MEDICO,ISNULL(PAR.MEDICOHOSPITAL,0))
					   AND PREE.TIPOREGISTRO = ( CASE
                                                          WHEN ATEND.AMBUPA = 1 THEN 2
                                                          ELSE 3
                                                        END )						
						   
				 LEFT JOIN TUSS_TAB26 AS T26 WITH (READPAST)
					ON T26.CODIGO = (CASE WHEN ISNULL(MEXEC.CONSELHOPROFISSIONAL,0) IN(0,7,11,12) THEN 10
										  WHEN MEXEC.CONSELHOPROFISSIONAL >= 8 AND MEXEC.CONSELHOPROFISSIONAL <= 10 THEN MEXEC.CONSELHOPROFISSIONAL -1
										  ELSE MEXEC.CONSELHOPROFISSIONAL END)        
										  
                 LEFT JOIN ESPMEDICA ESPEXEC WITH (READPAST)
                        ON ESPEXEC.ESPECMEDICA = MEXEC.ESPECMEDICA						
				 LEFT JOIN TUSS_TAB24 AS T24 WITH (READPAST)
						ON T24.CODIGO = ISNULL(ESPEXEC.CBOS030200, ESPEXEC.CBO2002)
						
                 LEFT JOIN TUSS_TAB50 AS T50 WITH (READPAST)
                        ON T50.CODIGO = 4
						
                 LEFT JOIN TUSS_TAB36 AS T36 WITH (READPAST)
                        ON T36.CODIGO = ISNULL(ATEND.INDICACAOACIDENTE, 9)
						
                 LEFT JOIN TUSS_TAB52 AS T52 WITH (READPAST)
                        ON T52.CODIGO = (CASE WHEN ISNULL(ATEND.TIPOTRATAMENTO,0) = 6 THEN 3
											  WHEN ISNULL(ATEND.TIPO,0) = 0 THEN 1
											  WHEN ISNULL(ATEND.TIPO,0) = 1 THEN 2
										 END)
						AND T50.CODIGO = 4
							
				END
      END
go

