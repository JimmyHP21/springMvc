CREATE PROCEDURE SP_SE_REPROCESSA_ESTOQUE
  @DATA_INICIAL  DATETIME= NULL,
  @DATA_FINAL    DATETIME= NULL,
  @PRODUTO       BIGINT= NULL,
  @SETOR		 BIGINT= NULL,
  @TIPO_PRODUTO  BIGINT= NULL,
  @TIPO_PROCESSO CHAR(1) = 'I' --[T]TOTAL, [P] PARCIAL, [I]INCREMENTAL
AS
  BEGIN TRY
    BEGIN TRAN
    PRINT '--| INICIO DA PROCEDURE [SP_SE_REPROCESSA_ESTOQUE] |------------------'
    IF @TIPO_PROCESSO = 'T'
    BEGIN
      SET @DATA_INICIAL = CONVERT(DATETIME,0);
      SET @DATA_FINAL = Getdate();
    END
    ELSE
    IF @TIPO_PROCESSO = 'P'
    BEGIN
      SET @DATA_INICIAL = ISNULL(@DATA_INICIAL,ISNULL(
      (
             SELECT Max(DATA)
             FROM   SE_MOVIMENTO),'1900/01/01'))
      SET @DATA_FINAL = ISNULL(@DATA_FINAL,Getdate());
    END
    ELSE
    IF @TIPO_PROCESSO = 'I'
    BEGIN
      SET @DATA_INICIAL = ISNULL(
      (
             SELECT Max(DATA)
             FROM   SE_MOVIMENTO),'1900/01/01');
      SET @DATA_FINAL = ISNULL(@DATA_FINAL,Getdate());
    END
    PRINT '=> REMOVENDO MOVIMENTOS EXISTENTES EM [SE_MOVIMENTO] ENTRE ' + CONVERT(VARCHAR,@DATA_INICIAL,121) + ' E ' + CONVERT(VARCHAR,@DATA_FINAL,121) + '.';
    IF @TIPO_PROCESSO = 'T'
    TRUNCATE TABLE SE_MOVIMENTO
    ELSE
    DELETE
    FROM   SE_MOVIMENTO
    WHERE  PRODUTO = ISNULL(@PRODUTO, PRODUTO)
    AND    DATA BETWEEN @DATA_INICIAL AND    @DATA_FINAL
    AND    SETOR_ESTOQUE = ISNULL(@SETOR, SETOR_ESTOQUE)
    AND    LEFT (RIGHT (Replicate ('0', 7)+ CONVERT (VARCHAR,PRODUTO),7),2) = ISNULL (@TIPO_PRODUTO,LEFT (RIGHT (Replicate ('0', 7)+ CONVERT (VARCHAR,PRODUTO),7),2));
    
    PRINT '=> COLETANDO MOVIMENTAÇÕES DE CONSUMO PARA ATENDIMENTOS INTERNOS';
    IF Object_id ('TEMPDB..#TEMP', 'U') IS NOT NULL
    DROP TABLE #TEMP;
    
    SELECT TOP 0
           *
    INTO   #TEMP
    FROM   SE_MOVIMENTO;
    
    INSERT INTO #TEMP
                (
                            TIPO,
                            DATA,
                            MOVIMENTO,
                            PRODUTO,
                            LOTE,
                            VALIDADE,
                            SETOR_ESTOQUE,
                            SETOR_DESTINO,
                            QUANTIDADE,
                            DOCUMENTO,
                            SEQUENCIA,
                            REGISTRO,
                            TIPO_REGISTRO,
                            FORNECEDOR,
                            TERCEIRO,
                            MOVIMENTA_SALDO,
                            USUARIO_MODIFICACAO,
                            DATA_MODIFICACAO
                )
    SELECT  DISTINCT
			   'S'                                                                                                                       AS TIPO,
               MOVIM.DATA_MOVIMENTO                                                                                                      AS DATA,
               'CONSUMO_PACIENTE'                                                                                                        AS MOVIMENTO,
               PROD.PRODUTO                                                                                                              AS PRODUTO,
               ISNULL (MOVIM.LOTE, 'S/ LOTE')                                                                                            AS LOTE,
               ISNULL (MOVIM.VALIDADELOTE, '1900/01/01')                                                                                 AS VALIDADE,
               MOVIM.CENTROCUSTO                                                                                                         AS SETOR_ESTOQUE,
               MOVIM.CENTROCUSTO_INTERNADO                                                                                               AS SETOR_DESTINO,
               (ISNULL (MOVIM.QUANTIDADEDISPENSADA, 0) + ISNULL (DEV.QUANTIDADE, 0)) / (MOVIM.FATORESTOQUE * ISNULL (MOVIM.CONVLANC, 1)) AS QUANTIDADE,
               /*        (ISNULL(MOVIM.QUANTIDADEDISPENSADA, 0) + ISNULL(DEV.QUANTIDADE, 0)) /
(ISNULL(ISNULL((SELECT TOP 1 MAUX.FATOR_ESTOQUE
FROM SE_HISTORICO_FATOR_ESTOQUE MAUX
WHERE MAUX.PRODUTO = PROD.PRODUTO
AND MAUX.DATA <= MOVIM.DATA_MOVIMENTO
ORDER BY MAUX.DATA DESC),MOVIM.FATORESTOQUE),1) * ISNULL(MOVIM.CONVLANC, 1) ) AS QUANTIDADE, */
               MOVIM.NOTA      AS DOCUMENTO,
               MOVIM.SEQUENCIA AS SEQUENCIA,
               MOVIM.REGISTRO  AS REGISTRO,
               'INTERNO'       AS TIPO_REGISTRO,
               NULL            AS FORNECEDOR,
               NULL            AS TERCEIRO, (
               CASE
                          WHEN MOVIM.SEMBAIXA = 1 THEN 0
                          ELSE 1
               END)                 AS MOVIMENTA_SALDO,
               NULL                 AS USUARIO_MODIFICACAO,
               MOVIM.DATA_MOVIMENTO AS DATA_MODIFICACAO
    FROM       MOVIM_INT MOVIM (NOLOCK)
    INNER JOIN PRODUTO PROD (NOLOCK)
    ON         MOVIM.PROCEDIMENTO = PROD.PRODUTO
    AND        MOVIM.DATA_MOVIMENTO IS NOT NULL
    AND        MOVIM.DATA_MOVIMENTO BETWEEN @DATA_INICIAL AND        @DATA_FINAL
    AND        PROD.PRODUTO = ISNULL (@PRODUTO, PROD.PRODUTO)
    AND        MOVIM.CENTROCUSTO = ISNULL (@SETOR, MOVIM.CENTROCUSTO)
    AND        LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO), 7 ), 2 ) = ISNULL (@TIPO_PRODUTO, LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO ), 7 ), 2 ) )
    AND        ISNULL (MOVIM.SEMBAIXA, 0) = 0
    LEFT JOIN
               (
                        SELECT   REGISTRO,
                                 SEQUENCIA,
                                 Sum (ISNULL (QUANTIDADENOVA, 0)) AS QUANTIDADE
                        FROM     MOVIMENTO_DEVOLUCAO (NOLOCK)
                        WHERE    TIPO = 'INTERNO'
                        GROUP BY REGISTRO,
                                 SEQUENCIA) DEV
    ON         DEV.REGISTRO = MOVIM.REGISTRO
    AND        DEV.SEQUENCIA = MOVIM.SEQUENCIA
-- WHERE (ISNULL(MOVIM.QUANTIDADEDISPENSADA, 0) + ISNULL(DEV.QUANTIDADE, 0)) > 0;
    WHERE      ISNULL (MOVIM.QUANTIDADEDISPENSADA, 0) > 0;
    
    PRINT '=> COLETANDO MOVIMENTAÇÕES DE CONSUMO PARA ATENDIMENTOS AMBULATORIAIS E DE URGÊNCIA';
    INSERT INTO #TEMP
                (
                            TIPO,
                            DATA,
                            MOVIMENTO,
                            PRODUTO,
                            LOTE,
                            VALIDADE,
                            SETOR_ESTOQUE,
                            SETOR_DESTINO,
                            QUANTIDADE,
                            DOCUMENTO,
                            SEQUENCIA,
                            REGISTRO,
                            TIPO_REGISTRO,
                            FORNECEDOR,
                            TERCEIRO,
                            MOVIMENTA_SALDO,
                            USUARIO_MODIFICACAO,
                            DATA_MODIFICACAO
                )
    SELECT  DISTINCT
			   'S'                                                                                                                       AS TIPO,
               MOVIM.DATA_MOVIMENTO                                                                                                      AS DATA,
               'CONSUMO_PACIENTE'                                                                                                        AS MOVIMENTO,
               PROD.PRODUTO                                                                                                              AS PRODUTO,
               ISNULL (MOVIM.LOTE, 'S/ LOTE')                                                                                            AS LOTE,
               ISNULL (MOVIM.VALIDADELOTE, '1900/01/01')                                                                                 AS VALIDADE,
               MOVIM.CENTROCUSTO                                                                                                         AS SETOR_ESTOQUE,
               MOVIM.CENTROCUSTO_INTERNADO                                                                                               AS SETOR_DESTINO,
               (ISNULL (MOVIM.QUANTIDADEDISPENSADA, 0) + ISNULL (DEV.QUANTIDADE, 0)) / (MOVIM.FATORESTOQUE * ISNULL (MOVIM.CONVLANC, 1)) AS QUANTIDADE,
               /*        (ISNULL(MOVIM.QUANTIDADEDISPENSADA, 0) + ISNULL(DEV.QUANTIDADE, 0)) /
(ISNULL(ISNULL((SELECT TOP 1 MAUX.FATOR_ESTOQUE
FROM SE_HISTORICO_FATOR_ESTOQUE MAUX
WHERE MAUX.PRODUTO = PROD.PRODUTO
AND MAUX.DATA <= MOVIM.DATA_MOVIMENTO
ORDER BY MAUX.DATA DESC),MOVIM.FATORESTOQUE),1) * ISNULL(MOVIM.CONVLANC, 1) ) AS QUANTIDADE,    */
               MOVIM.NOTA      AS DOCUMENTO,
               MOVIM.SEQUENCIA AS SEQUENCIA,
               MOVIM.REGISTRO  AS REGISTRO, (
               CASE
                          WHEN ATEND.AMBUPA = 1 THEN 'AMBULATORIAL'
                          ELSE 'URGENCIA'
               END) AS TIPO_REGISTRO,
               NULL AS FORNECEDOR,
               NULL AS TERCEIRO, (
               CASE
                          WHEN MOVIM.SEMBAIXA = 1 THEN 0
                          ELSE 1
               END)                AS MOVIMENTA_SALDO,
               NULL                AS USUARIO_MODIFICACAO,
               MOVIM.DATADIGITACAO AS DATA_MODIFICACAO
    FROM       MOVIM_AMB MOVIM (NOLOCK)
    INNER JOIN PRODUTO PROD (NOLOCK)
    ON         MOVIM.PROCEDIMENTO = PROD.PRODUTO
    AND        MOVIM.DATA_MOVIMENTO IS NOT NULL
    AND        MOVIM.DATA_MOVIMENTO BETWEEN @DATA_INICIAL AND        @DATA_FINAL
    AND        PROD.PRODUTO = ISNULL (@PRODUTO, PROD.PRODUTO)
    AND        MOVIM.CENTROCUSTO = ISNULL (@SETOR, MOVIM.CENTROCUSTO)
    AND        LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO), 7 ), 2 ) = ISNULL (@TIPO_PRODUTO, LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO ), 7 ), 2 ) )
    AND        ISNULL (MOVIM.SEMBAIXA, 0) = 0
    INNER JOIN AMBULATORIAL ATEND
    ON         ATEND.REGISTRO = MOVIM.REGISTRO
    LEFT JOIN
               (
                        SELECT   REGISTRO,
                                 SEQUENCIA,
                                 Sum (ISNULL (QUANTIDADENOVA, 0)) AS QUANTIDADE
                        FROM     MOVIMENTO_DEVOLUCAO (NOLOCK)
                        WHERE    TIPO IN ('AMBULATORIAL',
                                          'URGÊNCIA')
                        GROUP BY REGISTRO,
                                 SEQUENCIA) DEV
    ON         DEV.REGISTRO = MOVIM.REGISTRO
    AND        DEV.SEQUENCIA = MOVIM.SEQUENCIA
-- WHERE (ISNULL(MOVIM.QUANTIDADEDISPENSADA, 0) + ISNULL(DEV.QUANTIDADE, 0)) > 0;
    WHERE      ISNULL (MOVIM.QUANTIDADEDISPENSADA, 0) > 0;
    
    PRINT '=> COLETANDO MOVIMENTAÇÕES DE CONSUMO PARA ATENDIMENTOS EXTERNOS';
    INSERT INTO #TEMP
                (
                            TIPO,
                            DATA,
                            MOVIMENTO,
                            PRODUTO,
                            LOTE,
                            VALIDADE,
                            SETOR_ESTOQUE,
                            SETOR_DESTINO,
                            QUANTIDADE,
                            DOCUMENTO,
                            SEQUENCIA,
                            REGISTRO,
                            TIPO_REGISTRO,
                            FORNECEDOR,
                            TERCEIRO,
                            MOVIMENTA_SALDO,
                            USUARIO_MODIFICACAO,
                            DATA_MODIFICACAO
                )
    SELECT  DISTINCT
			   'S'                                                                                        AS TIPO,
               MOVIM.DATA_MOVIMENTO                                                                       AS DATA,
               'CONSUMO_PACIENTE'                                                                         AS MOVIMENTO,
               PROD.PRODUTO                                                                               AS PRODUTO,
               ISNULL (MOVIM.LOTE, 'S/ LOTE')                                                             AS LOTE,
               ISNULL (MOVIM.VALIDADELOTE, '1900/01/01')                                                  AS VALIDADE,
               MOVIM.CENTROCUSTO                                                                          AS SETOR_ESTOQUE,
               MOVIM.CENTROCUSTO_INTERNADO                                                                AS SETOR_DESTINO,
               ISNULL (MOVIM.QUANTIDADEDISPENSADA, 0) / (MOVIM.FATORESTOQUE * ISNULL (MOVIM.CONVLANC, 1)) AS QUANTIDADE,
               /*        ISNULL(MOVIM.QUANTIDADEDISPENSADA, 0) /
(ISNULL(ISNULL((SELECT TOP 1 MAUX.FATOR_ESTOQUE
FROM SE_HISTORICO_FATOR_ESTOQUE MAUX
WHERE MAUX.PRODUTO = PROD.PRODUTO
AND MAUX.DATA <= MOVIM.DATA_MOVIMENTO
ORDER BY MAUX.DATA DESC),MOVIM.FATORESTOQUE),1) * ISNULL(MOVIM.CONVLANC, 1) ) AS QUANTIDADE, */
               MOVIM.NOTA      AS DOCUMENTO,
               MOVIM.SEQUENCIA AS SEQUENCIA,
               MOVIM.REGISTRO  AS REGISTRO,
               'EXTERNO'       AS TIPO_REGISTRO,
               NULL            AS FORNECEDOR,
               NULL            AS TERCEIRO, (
               CASE
                          WHEN MOVIM.SEMBAIXA = 1 THEN 0
                          ELSE 1
               END)                AS MOVIMENTA_SALDO,
               NULL                AS USUARIO_MODIFICACAO,
               MOVIM.DATADIGITACAO AS DATA_MODIFICACAO
    FROM       MOVIM_EXT MOVIM (NOLOCK)
    INNER JOIN PRODUTO PROD (NOLOCK)
    ON         MOVIM.PROCEDIMENTO = PROD.PRODUTO
    AND        MOVIM.DATA_MOVIMENTO BETWEEN @DATA_INICIAL AND        @DATA_FINAL
    AND        PROD.PRODUTO = ISNULL (@PRODUTO, PROD.PRODUTO)
    AND        MOVIM.CENTROCUSTO = ISNULL (@SETOR, MOVIM.CENTROCUSTO)
    AND        LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO), 7 ), 2 ) = ISNULL (@TIPO_PRODUTO, LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO ), 7 ), 2 ) )
    AND        ISNULL (MOVIM.SEMBAIXA, 0) = 0
    WHERE      ISNULL (MOVIM.QUANTIDADEDISPENSADA, 0) > 0;
    
    PRINT '=> PROCESSANDO DEVOLUÇÕES'
    INSERT INTO #TEMP
                (
                            TIPO,
                            DATA,
                            MOVIMENTO,
                            PRODUTO,
                            LOTE,
                            VALIDADE,
                            SETOR_ESTOQUE,
                            SETOR_DESTINO,
                            QUANTIDADE,
                            DOCUMENTO,
                            SEQUENCIA,
                            REGISTRO,
                            TIPO_REGISTRO,
                            FORNECEDOR,
                            TERCEIRO,
                            MOVIMENTA_SALDO,
                            USUARIO_MODIFICACAO,
                            DATA_MODIFICACAO
                )
    SELECT  DISTINCT
			   'E'                                                                                                                                                                             AS TIPO,
               MOVIM.DATA_MOVIMENTO                                                                                                                                                            AS DATA,
               'DEVOLUCAO_PACIENTE'                                                                                                                                                            AS MOVIMENTO,
               PROD.PRODUTO                                                                                                                                                                    AS PRODUTO,
               ISNULL (MOVIM.LOTE, 'S/ LOTE')                                                                                                                                                  AS LOTE,
               ISNULL (MOVIM.VALIDADELOTE, '1900/01/01')                                                                                                                                       AS VALIDADE,
               CC.CENTROCUSTO                                                                                                                                                                  AS SETOR_ESTOQUE,
               NULL                                                                                                                                                                            AS SETOR_DESTINO,
               MOVIM.QUANTIDADENOVA / ISNULL (COALESCE (ISNULL (MI.CONVLANC, 1), ISNULL (MA.CONVLANC, 1), ISNULL (ME.CONVLANC, 1) ), 1 ) AS QUANTIDADE,
               MOVIM.NOTA      AS DOCUMENTO,
               MOVIM.SEQUENCIA AS SEQUENCIA,
               MOVIM.REGISTRO  AS REGISTRO, (
               CASE
                          WHEN MOVIM.TIPO = 'URGÊNCIA' THEN 'URGENCIA'
                          ELSE MOVIM.TIPO
               END)                AS TIPO_REGISTRO,
               NULL                AS FORNECEDOR,
               NULL                AS TERCEIRO,
               1                   AS MOVIMENTA_SALDO,
               NULL                AS USUARIO_MODIFICACAO,
               MOVIM.DATAALTERACAO AS DATA_MODIFICACAO
    FROM       MOVIMENTO_DEVOLUCAO MOVIM (NOLOCK)
    INNER JOIN PRODUTO PROD (NOLOCK)
    ON         MOVIM.PRODUTO = PROD.PRODUTO
    AND        MOVIM.DATA_MOVIMENTO IS NOT NULL
    AND        MOVIM.DATA_MOVIMENTO BETWEEN @DATA_INICIAL AND        @DATA_FINAL
    AND        PROD.PRODUTO = ISNULL (@PRODUTO, PROD.PRODUTO)
    AND        LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO ), 7 ), 2 ) = ISNULL (@TIPO_PRODUTO, LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO ), 7 ), 2 ) )
    LEFT JOIN  MOVIM_INT MI
    ON         MI.REGISTRO = MOVIM.REGISTRO
    AND        MI.SEQUENCIA = MOVIM.SEQUENCIA
    AND        MOVIM.TIPO = 'INTERNO'
    LEFT JOIN  MOVIM_AMB MA
    ON         MA.REGISTRO = MOVIM.REGISTRO
    AND        MA.SEQUENCIA = MOVIM.SEQUENCIA
    AND        MOVIM.TIPO IN ('AMBULATORIAL',
                              'URGÊNCIA')
    LEFT JOIN  MOVIM_EXT ME
    ON         ME.REGISTRO = MOVIM.REGISTRO
    AND        ME.SEQUENCIA = MOVIM.SEQUENCIA
    AND        MOVIM.TIPO = 'EXTERNO'
    INNER JOIN CENTROCUSTO CC
    ON         CC.CENTROCUSTO = COALESCE (MI.CENTROCUSTO, MA.CENTROCUSTO, ME.CENTROCUSTO )
    AND        CC.CENTROCUSTO = ISNULL (@SETOR, CC.CENTROCUSTO)
	
    PRINT '=> COLETANDO MOVIMENTAÇÕES DE CONSUMO PARA SETORES'
    INSERT INTO #TEMP
                (
                            TIPO,
                            DATA,
                            MOVIMENTO,
                            PRODUTO,
                            LOTE,
                            VALIDADE,
                            SETOR_ESTOQUE,
                            SETOR_DESTINO,
                            QUANTIDADE,
                            DOCUMENTO,
                            SEQUENCIA,
                            REGISTRO,
                            TIPO_REGISTRO,
                            FORNECEDOR,
                            TERCEIRO,
                            MOVIMENTA_SALDO,
                            USUARIO_MODIFICACAO,
                            DATA_MODIFICACAO
                )
    SELECT  DISTINCT
			   (
               CASE
                          WHEN MOVIM.TIPO = 0 THEN 'S'
                          ELSE 'E'
               END)                 AS TIPO,
               MOVIM.DATA_MOVIMENTO AS DATA, (
               CASE
                          WHEN MOVIM.TIPO = 0 THEN 'CONSUMO_SETOR'
                          ELSE 'DEVOLUCAO_SETOR'
               END)                                      AS MOVIMENTO,
               PROD.PRODUTO                              AS PRODUTO,
               ISNULL (MOVIM.LOTE, 'S/ LOTE')            AS LOTE,
               ISNULL (MOVIM.VALIDADELOTE, '1900/01/01') AS VALIDADE,
               MOVIM.CCORIGEM                            AS SETOR_ESTOQUE,
               MOVIM.CCDESTINO                           AS SETOR_DESTINO,
               MOVIM.QUANTIDADE                          AS QUANTIDADE,
               MOVIM.DOCUMENTO     AS DOCUMENTO,
               MOVIM.SEQUENCIA     AS SEQUENCIA,
               NULL                AS REGISTRO,
               NULL                AS TIPO_REGISTRO,
               NULL                AS FORNECEDOR,
               NULL                AS TERCEIRO,
               1                   AS MOVIMENTA_SALDO,
               NULL                AS USUARIO_MODIFICACAO,
               MOVIM.DATADIGITACAO AS DATA_MODIFICACAO
    FROM       MOVIMENTOCC MOVIM (NOLOCK)
    INNER JOIN PRODUTO PROD (NOLOCK)
    ON         MOVIM.PRODUTO = PROD.PRODUTO
    AND        MOVIM.DATA_MOVIMENTO BETWEEN @DATA_INICIAL AND        @DATA_FINAL
    AND        PROD.PRODUTO = ISNULL (@PRODUTO, PROD.PRODUTO)
    AND        MOVIM.CCORIGEM = ISNULL (@SETOR, MOVIM.CCORIGEM)
    AND        LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO), 7 ), 2 ) = ISNULL (@TIPO_PRODUTO, LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO ), 7 ), 2 ) )
    AND        ISNULL (MOVIM.CONSUMOINTERNO, 0) = 1
    WHERE      ISNULL (MOVIM.QUANTIDADE, 0) > 0;
    
    PRINT '=> TRANSFERÊNCIAS ENTRE SETORES'
    INSERT INTO #TEMP
                (
                            TIPO,
                            DATA,
                            MOVIMENTO,
                            PRODUTO,
                            LOTE,
                            VALIDADE,
                            SETOR_ESTOQUE,
                            SETOR_DESTINO,
                            QUANTIDADE,
                            DOCUMENTO,
                            SEQUENCIA,
                            REGISTRO,
                            TIPO_REGISTRO,
                            FORNECEDOR,
                            TERCEIRO,
                            MOVIMENTA_SALDO,
                            USUARIO_MODIFICACAO,
                            DATA_MODIFICACAO
                )
    SELECT  DISTINCT
			   (
               CASE
                          WHEN MOVIM.TIPO = 0 THEN 'S'
                          ELSE 'E'
               END)                                      AS TIPO,
               MOVIM.DATA_MOVIMENTO                      AS DATA,
               'TRANSFERENCIA'                           AS MOVIMENTO,
               PROD.PRODUTO                              AS PRODUTO,
               ISNULL (MOVIM.LOTE, 'S/ LOTE')            AS LOTE,
               ISNULL (MOVIM.VALIDADELOTE, '1900/01/01') AS VALIDADE,
               MOVIM.CCORIGEM                            AS SETOR_ESTOQUE,
               MOVIM.CCDESTINO                           AS SETOR_DESTINO,
               MOVIM.QUANTIDADE                          AS QUANTIDADE,
               MOVIM.DOCUMENTO     AS DOCUMENTO,
               MOVIM.SEQUENCIA     AS SEQUENCIA,
               NULL                AS REGISTRO,
               NULL                AS TIPO_REGISTRO,
               NULL                AS FORNECEDOR,
               NULL                AS TERCEIRO,
               1                   AS MOVIMENTA_SALDO,
               NULL                AS USUARIO_MODIFICACAO,
               MOVIM.DATADIGITACAO AS DATA_MODIFICACAO
    FROM       MOVIMENTOCC MOVIM (NOLOCK)
    INNER JOIN PRODUTO PROD (NOLOCK)
    ON         MOVIM.PRODUTO = PROD.PRODUTO
    AND        MOVIM.DATA_MOVIMENTO BETWEEN @DATA_INICIAL AND        @DATA_FINAL
    AND        PROD.PRODUTO = ISNULL (@PRODUTO, PROD.PRODUTO)
    AND        MOVIM.CCORIGEM = ISNULL (@SETOR, MOVIM.CCORIGEM)
    AND        LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO), 7 ), 2 ) = ISNULL (@TIPO_PRODUTO, LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO ), 7 ), 2 ) )
    AND        ISNULL (MOVIM.CONSUMOINTERNO, 0) = 0
    WHERE      ISNULL (MOVIM.QUANTIDADE, 0) > 0;
    
    INSERT INTO #TEMP
                (
                            TIPO,
                            DATA,
                            MOVIMENTO,
                            PRODUTO,
                            LOTE,
                            VALIDADE,
                            SETOR_ESTOQUE,
                            SETOR_DESTINO,
                            QUANTIDADE,
                            DOCUMENTO,
                            SEQUENCIA,
                            REGISTRO,
                            TIPO_REGISTRO,
                            FORNECEDOR,
                            TERCEIRO,
                            MOVIMENTA_SALDO,
                            USUARIO_MODIFICACAO,
                            DATA_MODIFICACAO
                )
    SELECT  DISTINCT
			   (
               CASE
                          WHEN MOVIM.TIPO = 0 THEN 'E'
                          ELSE 'S'
               END)                                      AS TIPO,
               MOVIM.DATA_MOVIMENTO                      AS DATA,
               'TRANSFERENCIA'                           AS MOVIMENTO,
               PROD.PRODUTO                              AS PRODUTO,
               ISNULL (MOVIM.LOTE, 'S/ LOTE')            AS LOTE,
               ISNULL (MOVIM.VALIDADELOTE, '1900/01/01') AS VALIDADE,
               MOVIM.CCDESTINO                           AS SETOR_ESTOQUE,
               MOVIM.CCORIGEM                            AS SETOR_DESTINO,
               MOVIM.QUANTIDADE                          AS QUANTIDADE,
               MOVIM.DOCUMENTO     AS DOCUMENTO,
               MOVIM.SEQUENCIA     AS SEQUENCIA,
               NULL                AS REGISTRO,
               NULL                AS TIPO_REGISTRO,
               NULL                AS FORNECEDOR,
               NULL                AS TERCEIRO,
               1                   AS MOVIMENTA_SALDO,
               NULL                AS USUARIO_MODIFICACAO,
               MOVIM.DATADIGITACAO AS DATA_MODIFICACAO
    FROM       MOVIMENTOCC MOVIM (NOLOCK)
    INNER JOIN PRODUTO PROD (NOLOCK)
    ON         MOVIM.PRODUTO = PROD.PRODUTO
    AND        MOVIM.DATA_MOVIMENTO BETWEEN @DATA_INICIAL AND        @DATA_FINAL
    AND        PROD.PRODUTO = ISNULL (@PRODUTO, PROD.PRODUTO)
    AND        MOVIM.CCDESTINO = ISNULL (@SETOR, MOVIM.CCDESTINO)
    AND        LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO), 7 ), 2 ) = ISNULL (@TIPO_PRODUTO, LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO ), 7 ), 2 ) )
    AND        ISNULL (MOVIM.CONSUMOINTERNO, 0) = 0
    WHERE      ISNULL (MOVIM.QUANTIDADE, 0) > 0;

    PRINT '=> COMPRAS E DOAÇÕES';
    INSERT INTO #TEMP
                (
                            TIPO,
                            DATA,
                            MOVIMENTO,
                            PRODUTO,
                            LOTE,
                            VALIDADE,
                            SETOR_ESTOQUE,
                            SETOR_DESTINO,
                            QUANTIDADE,
                            CUSTO_UNITARIO,
                            DOCUMENTO,
                            SEQUENCIA,
                            REGISTRO,
                            TIPO_REGISTRO,
                            FORNECEDOR,
                            TERCEIRO,
                            MOVIMENTA_SALDO,
                            USUARIO_MODIFICACAO,
                            DATA_MODIFICACAO
                )
    SELECT  DISTINCT
			   'E'                 AS TIPO,
               MOVIM.DATA_MOVIMENTO AS DATA, 
			   (CASE
                          WHEN ISNULL (MOVIM.DOACAO, 0) = 1 
						  THEN 'DOACAO_ENTRADA'
						  ELSE 'COMPRA_ENTRADA'
               END)                                      AS MOVIMENTO,
               PROD.PRODUTO                              AS PRODUTO,
               ISNULL (MOVIM.LOTE, 'S/ LOTE')            AS LOTE,
               ISNULL (MOVIM.VALIDADE, '1900/01/01') AS VALIDADE,
               MOVIM.CENTROCUSTO                         AS SETOR_ESTOQUE,
               NULL                                      AS SETOR_DESTINO,
               MOVIM.QUANTIDADE                          AS QUANTIDADE,
               MOVIM.VALOR				                 AS CUSTO_UNITARIO,
               CONVERT (VARCHAR, MOVIM.NOTA) + (
               CASE
                          WHEN ISNULL (CONVERT (VARCHAR, MOVIM.SERIE), '') <> '' THEN '/' + CONVERT (VARCHAR, MOVIM.SERIE)
                          ELSE ''
               END)                AS DOCUMENTO,
               NULL                AS SEQUENCIA,
               NULL                AS REGISTRO,
               NULL                AS TIPO_REGISTRO,
               MOVIM.FORNECEDOR    AS FORNECEDOR,
               NULL                AS TERCEIRO,
               (CASE WHEN ISNULL(CONSIGNACAO,0) = 1 THEN 0 ELSE 1 END)
								   AS MOVIMENTA_SALDO,
               NULL                AS USUARIO_MODIFICACAO,
               MOVIM.DATA_MOVIMENTO AS DATA_MODIFICACAO
    FROM       V_ENTRADA_NOTA MOVIM (NOLOCK)
    INNER JOIN PRODUTO PROD (NOLOCK)
    ON         MOVIM.PRODUTO = PROD.PRODUTO
    AND        MOVIM.DATA_LANCAMENTO BETWEEN @DATA_INICIAL AND        @DATA_FINAL
    AND        PROD.PRODUTO = ISNULL (@PRODUTO, PROD.PRODUTO)
    AND        MOVIM.CENTROCUSTO = ISNULL (@SETOR, MOVIM.CENTROCUSTO)
    AND        LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO), 7 ), 2 ) = ISNULL (@TIPO_PRODUTO, LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO ), 7 ), 2 ) )
    WHERE      ISNULL (MOVIM.QUANTIDADE, 0) > 0
    
    PRINT '=> PROCESSANDO EMPRÉSTIMOS';
    INSERT INTO #TEMP
                (
                            TIPO,
                            DATA,
                            MOVIMENTO,
                            PRODUTO,
                            LOTE,
                            VALIDADE,
                            SETOR_ESTOQUE,
                            SETOR_DESTINO,
                            QUANTIDADE,
                            DOCUMENTO,
                            SEQUENCIA,
                            REGISTRO,
                            TIPO_REGISTRO,
                            FORNECEDOR,
                            TERCEIRO,
                            MOVIMENTA_SALDO,
                            USUARIO_MODIFICACAO,
                            DATA_MODIFICACAO
                )
    SELECT  DISTINCT
			   (
               CASE
                          WHEN MOVIM.TIPO = 0
                          AND        MOVIM.TIPOEMPRESTIMO = 0 THEN 'S'
                          WHEN MOVIM.TIPO = 0
                          AND        MOVIM.TIPOEMPRESTIMO = 1 THEN 'E'
                          WHEN MOVIM.TIPO = 0
                          AND        MOVIM.TIPOEMPRESTIMO = 2 THEN 'E'
                          WHEN MOVIM.TIPO = 1
                          AND        MOVIM.TIPOEMPRESTIMO = 0 THEN 'E'
                          WHEN MOVIM.TIPO = 1
                          AND        MOVIM.TIPOEMPRESTIMO = 1 THEN 'S'
                          WHEN MOVIM.TIPO = 1
                          AND        MOVIM.TIPOEMPRESTIMO = 2 THEN 'S'
               END)                                      AS TIPO,
               MOVIM.DATA_MOVIMENTO                      AS DATA,
               'EMPRESTIMO'                              AS MOVIMENTO,
               PROD.PRODUTO                              AS PRODUTO,
               ISNULL (MOVIM.LOTE, 'S/ LOTE')            AS LOTE,
               ISNULL (MOVIM.VALIDADELOTE, '1900/01/01') AS VALIDADE, (
               CASE
                          WHEN MOVIM.TIPOEMPRESTIMO = 0 THEN MOVIM.ORIGEM
                          ELSE MOVIM.DESTINO
               END)             AS SETOR_ESTOQUE,
               NULL             AS SETOR_DESTINO,
               MOVIM.QUANTIDADE AS QUANTIDADE,
               MOVIM.DOCUMENTO AS DOCUMENTO,
               MOVIM.SEQUENCIA AS SEQUENCIA, (
               CASE
                          WHEN MOVIM.TIPOEMPRESTIMO = 2 THEN MOVIM.ORIGEM
                          ELSE NULL
               END) AS REGISTRO, (
               CASE
                          WHEN MOVIM.TIPOEMPRESTIMO = 2 THEN 'INTERNO'
                          ELSE NULL
               END) AS TIPO_REGISTRO,
               NULL AS FORNECEDOR, (
               CASE
                          WHEN MOVIM.TIPOEMPRESTIMO = 0 THEN MOVIM.DESTINO
                          WHEN MOVIM.TIPOEMPRESTIMO = 1 THEN MOVIM.ORIGEM
                          ELSE NULL
               END)                 AS TERCEIRO,
               1                    AS MOVIMENTA_SALDO,
               NULL                 AS USUARIO_MODIFICACAO,
               MOVIM.DATA_MOVIMENTO AS DATA_MODIFICACAO
    FROM       MOVIM_EMPRESTIMO MOVIM (NOLOCK)
    INNER JOIN PRODUTO PROD (NOLOCK)
    ON         MOVIM.PRODUTO = PROD.PRODUTO
    AND        MOVIM.DATA_MOVIMENTO IS NOT NULL
    AND        MOVIM.DATA_MOVIMENTO BETWEEN @DATA_INICIAL AND        @DATA_FINAL
    AND        PROD.PRODUTO = ISNULL (@PRODUTO, PROD.PRODUTO)
    AND        LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO), 7 ), 2 ) = ISNULL (@TIPO_PRODUTO, LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO ), 7 ), 2 ) )
    PRINT '=> PROCESSANDO ACERTOS DE ESTOQUE';
    INSERT INTO #TEMP
                (
                            TIPO,
                            DATA,
                            MOVIMENTO,
                            PRODUTO,
                            LOTE,
                            VALIDADE,
                            SETOR_ESTOQUE,
                            SETOR_DESTINO,
                            QUANTIDADE,
                            QUANTIDADE_BALANCO,
                            DOCUMENTO,
                            SEQUENCIA,
                            REGISTRO,
                            TIPO_REGISTRO,
                            FORNECEDOR,
                            TERCEIRO,
                            MOVIMENTA_SALDO,
                            USUARIO_MODIFICACAO,
                            DATA_MODIFICACAO
                )
    SELECT  DISTINCT
			   (
               CASE
                          WHEN MOVIM.TIPOACERTO = 0 THEN 'E'
                          ELSE 'S'
               END)                                      AS TIPO,
               MOVIM.DATA_MOVIMENTO                      AS DATA,
               'ACERTO_ESTOQUE'                          AS MOVIMENTO,
               PROD.PRODUTO                              AS PRODUTO,
               ISNULL (MOVIM.LOTE, 'S/ LOTE')            AS LOTE,
               ISNULL (MOVIM.VALIDADELOTE, '1900/01/01') AS VALIDADE,
               MOVIM.CENTROCUSTO                         AS SETOR_ESTOQUE,
               NULL                                      AS SETOR_DESTINO,
               0                                         AS QUANTIDADE,
               MOVIM.QUANTIDADE                          AS QUANTIDADE_BALANCO,
               MOVIM.DOCUMENTO      AS DOCUMENTO,
               MOVIM.SEQUENCIA      AS SEQUENCIA,
               NULL                 AS REGISTRO,
               NULL                 AS TIPO_REGISTRO,
               NULL                 AS FORNECEDOR,
               NULL                 AS TERCEIRO,
               1                    AS MOVIMENTA_SALDO,
               NULL                 AS USUARIO_MODIFICACAO,
               MOVIM.DATAOPERACAO   AS DATA_MODIFICACAO
    FROM       MOVIM_PRODUTO_ACERTOESTOQUE MOVIM (NOLOCK)
    INNER JOIN PRODUTO PROD (NOLOCK)
    ON         MOVIM.PRODUTO = PROD.PRODUTO
    AND        MOVIM.DATA_MOVIMENTO IS NOT NULL
    AND        MOVIM.DATA_MOVIMENTO BETWEEN @DATA_INICIAL AND        @DATA_FINAL
    AND        PROD.PRODUTO = ISNULL (@PRODUTO, PROD.PRODUTO)
    AND        LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO), 7 ), 2 ) = ISNULL (@TIPO_PRODUTO, LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO ), 7 ), 2 ) )
    PRINT '=> PROCESSANDO CONTAGENS DE ESTOQUE';
    INSERT INTO #TEMP
                (
                            TIPO,
                            DATA,
                            MOVIMENTO,
                            PRODUTO,
                            LOTE,
                            VALIDADE,
                            SETOR_ESTOQUE,
                            SETOR_DESTINO,
                            QUANTIDADE,
                            QUANTIDADE_BALANCO,
                            DOCUMENTO,
                            SEQUENCIA,
                            REGISTRO,
                            TIPO_REGISTRO,
                            FORNECEDOR,
                            TERCEIRO,
                            MOVIMENTA_SALDO,
                            USUARIO_MODIFICACAO,
                            DATA_MODIFICACAO
                )
    SELECT  DISTINCT
			   'I'                                   AS TIPO,
               MOVIM.DATA_MOVIMENTO                  AS DATA,
               'CONTAGEM'                            AS MOVIMENTO,
               PROD.PRODUTO                          AS PRODUTO,
               ISNULL (MOVIM.LOTE, 'S/ LOTE')        AS LOTE,
               ISNULL (MOVIM.VALIDADE, '1900/01/01') AS VALIDADE,
               MOVIM.CENTROCUSTO                     AS SETOR_ESTOQUE,
               NULL                                  AS SETOR_DESTINO,
               0                                     AS QUANTIDADE,
               MOVIM.SALDONOVO                       AS QUANTIDADE_BALANCO,
               NULL                 AS DOCUMENTO,
               NULL                 AS SEQUENCIA,
               NULL                 AS REGISTRO,
               NULL                 AS TIPO_REGISTRO,
               NULL                 AS FORNECEDOR,
               NULL                 AS TERCEIRO,
               1                    AS MOVIMENTA_SALDO,
               NULL                 AS USUARIO_MODIFICACAO,
               MOVIM.DATA_MOVIMENTO AS DATA_MODIFICACAO
    FROM       SAVELOG..CONTAGEMESTOQUE MOVIM (NOLOCK)
    INNER JOIN PRODUTO PROD (NOLOCK)
    ON         MOVIM.PRODUTO = PROD.PRODUTO
    AND        MOVIM.DATA_MOVIMENTO IS NOT NULL
    AND        MOVIM.DATA_MOVIMENTO BETWEEN @DATA_INICIAL AND        @DATA_FINAL
    AND        PROD.PRODUTO = ISNULL (@PRODUTO, PROD.PRODUTO)
    AND        LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO), 7 ), 2 ) = ISNULL (@TIPO_PRODUTO, LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO ), 7 ), 2 ) )
    PRINT '=> PROCESSANDO INICIALIZAÇÕES DE SALDO INDIVIDUAIS';
    INSERT INTO #TEMP
                (
                            TIPO,
                            DATA,
                            MOVIMENTO,
                            PRODUTO,
                            LOTE,
                            VALIDADE,
                            SETOR_ESTOQUE,
                            SETOR_DESTINO,
                            QUANTIDADE,
                            QUANTIDADE_BALANCO,
                            DOCUMENTO,
                            SEQUENCIA,
                            REGISTRO,
                            TIPO_REGISTRO,
                            FORNECEDOR,
                            TERCEIRO,
                            MOVIMENTA_SALDO,
                            USUARIO_MODIFICACAO,
                            DATA_MODIFICACAO
                )
    SELECT     'I'                                   AS TIPO,
               MOVIM.DATA_MOVIMENTO                  AS DATA,
               'INICIALIZACAO_SALDO_INDIVIDUAL'      AS MOVIMENTO,
               PROD.PRODUTO                          AS PRODUTO,
               ISNULL (MOVIM.LOTE, 'S/ LOTE')        AS LOTE,
               ISNULL (MOVIM.VALIDADE, '1900/01/01') AS VALIDADE,
               MOVIM.CENTROCUSTO                     AS SETOR_ESTOQUE,
               NULL                                  AS SETOR_DESTINO,
               0                                     AS QUANTIDADE,
               MOVIM.SALDO                           AS QUANTIDADE_BALANCO,
               NULL                 AS DOCUMENTO,
               NULL                 AS SEQUENCIA,
               NULL                 AS REGISTRO,
               NULL                 AS TIPO_REGISTRO,
               NULL                 AS FORNECEDOR,
               NULL                 AS TERCEIRO,
               NULL                 AS MOVIMENTA_SALDO,
               NULL                 AS USUARIO_MODIFICACAO,
               MOVIM.DATA_MOVIMENTO AS DATA_MODIFICACAO
    FROM       PRODUTOCENTROCUSTOLOTE_LOG MOVIM (NOLOCK)
    INNER JOIN PRODUTO PROD (NOLOCK)
    ON         MOVIM.PRODUTO = PROD.PRODUTO
    AND        MOVIM.DATA_MOVIMENTO IS NOT NULL
    AND        MOVIM.DATA_MOVIMENTO BETWEEN @DATA_INICIAL AND        @DATA_FINAL
    AND        PROD.PRODUTO = ISNULL (@PRODUTO, PROD.PRODUTO)
    AND        LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO), 7 ), 2 ) = ISNULL (@TIPO_PRODUTO, LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO ), 7 ), 2 ) )
    PRINT '=> PROCESSANDO INICIALIZAÇÕES DE SALDO MULTIPLAS';
    INSERT INTO #TEMP
                (
                            TIPO,
                            DATA,
                            MOVIMENTO,
                            PRODUTO,
                            LOTE,
                            VALIDADE,
                            SETOR_ESTOQUE,
                            SETOR_DESTINO,
                            QUANTIDADE,
                            QUANTIDADE_BALANCO,
                            DOCUMENTO,
                            SEQUENCIA,
                            REGISTRO,
                            TIPO_REGISTRO,
                            FORNECEDOR,
                            TERCEIRO,
                            MOVIMENTA_SALDO,
                            USUARIO_MODIFICACAO,
                            DATA_MODIFICACAO
                )
    SELECT  DISTINCT
			   'I'                                   AS TIPO,
               MOVIM.DATA_MOVIMENTO                  AS DATA,
               'INICIALIZACAO_MULTIPLA'              AS MOVIMENTO,
               PROD.PRODUTO                          AS PRODUTO,
               ISNULL (MOVIM.LOTE, 'S/ LOTE')        AS LOTE,
               ISNULL (MOVIM.VALIDADE, '1900/01/01') AS VALIDADE,
               MOVIM.CENTROCUSTO                     AS SETOR_ESTOQUE,
               NULL                                  AS SETOR_DESTINO,
               0                                     AS QUANTIDADE,
               MOVIM.SALDONOVO                       AS QUANTIDADE_BALANCO,
               NULL                 AS DOCUMENTO,
               NULL                 AS SEQUENCIA,
               NULL                 AS REGISTRO,
               NULL                 AS TIPO_REGISTRO,
               NULL                 AS FORNECEDOR,
               NULL                 AS TERCEIRO,
               1                    AS MOVIMENTA_SALDO,
               NULL                 AS USUARIO_MODIFICACAO,
               MOVIM.DATA_MOVIMENTO AS DATA_MODIFICACAO
    FROM       SAVELOG..ALTERACAO_SALDO_LOG MOVIM (NOLOCK)
    INNER JOIN PRODUTO PROD (NOLOCK)
    ON         MOVIM.PRODUTO = PROD.PRODUTO
    AND        MOVIM.DATA_MOVIMENTO IS NOT NULL
    AND        MOVIM.DATA_MOVIMENTO BETWEEN @DATA_INICIAL AND        @DATA_FINAL
    AND        PROD.PRODUTO = ISNULL (@PRODUTO, PROD.PRODUTO)
    AND        LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO), 7 ), 2 ) = ISNULL (@TIPO_PRODUTO, LEFT (RIGHT (Replicate ('0', 7) + CONVERT (VARCHAR, PROD.PRODUTO ), 7 ), 2 ) )
    PRINT '=> INSERINDO EM [SE_MOVIMENTO]';
-- INSERT INTO SE_MOVIMENTO
    SELECT * INTO REVISAO_DE_SALDO_1700053
    FROM   #TEMP;
    
    COMMIT TRAN
    PRINT '--| ENCERRANDO A PROCEDURE [SP_SE_REPROCESSA_ESTOQUE] |---------------'
  END TRY
  BEGIN CATCH
    ROLLBACK TRAN
    SELECT ERROR_NUMBER ()    AS ERRORNUMBER,
           ERROR_SEVERITY ()  AS ERRORSEVERITY,
           ERROR_STATE ()     AS ERRORSTATE,
           ERROR_PROCEDURE () AS ERRORPROCEDURE,
           ERROR_LINE ()      AS ERRORLINE,
           ERROR_MESSAGE ()   AS ERRORMESSAGE;
  
  END CATCH
go

