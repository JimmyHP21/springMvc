-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spd_produto
	@produto int 
as
begin
	set nocount on
	delete from dbo.produto
	where
		produto = @produto
end
go

