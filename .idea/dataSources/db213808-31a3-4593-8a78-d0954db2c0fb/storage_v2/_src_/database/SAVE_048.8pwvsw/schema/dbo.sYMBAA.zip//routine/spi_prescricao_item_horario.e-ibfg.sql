-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spi_prescricao_item_horario
	@id bigint  output,
	@prescricao_item bigint  = null,
	@horario datetime  = null,
	@status int  = null,
	@usuario int  = null,
	@data datetime  = null,
	@atualizacao varchar(150)  = null,
	@log bigint  = null
as
begin
	set nocount on
	insert into dbo.prescricao_item_horario
		( prescricao_item, horario, status, usuario, data, atualizacao, log)
	values
		(@prescricao_item,@horario,@status,@usuario,@data,@atualizacao,@log)

	select @id = scope_identity()
end
go

