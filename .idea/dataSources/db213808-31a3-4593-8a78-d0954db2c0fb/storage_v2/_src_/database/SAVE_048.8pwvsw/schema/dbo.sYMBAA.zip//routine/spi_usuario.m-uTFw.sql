-- =============================================
-- author:		m2 tecnologia
-- create date:	18/11/2015
-- description:	
-- revisions:	
-- =============================================
create procedure dbo.spi_usuario
	@usuario int  output,
	@nome varchar(50) ,
	@logon varchar(15) ,
	@senha varchar(15) ,
	@atualizacao varchar(150) ,
	@administralicenca int  = null,
	@sndi int  = null,
	@snda int  = null,
	@snde int  = null,
	@almoxarifadoi int  = null,
	@almoxarifadoa int  = null,
	@almoxarifadoe int  = null,
	@farmaciai int  = null,
	@farmaciaa int  = null,
	@farmaciae int  = null,
	@estoquei int  = null,
	@estoquea int  = null,
	@estoquee int  = null,
	@emailpadraocotacao varchar(155)  = null,
	@prescricaointerno int  = null,
	@prescricaoambulatorial int  = null,
	@prescricaourgencia int  = null,
	@ccpadraocotacao int  = null,
	@observacao varchar(65)  = null,
	@desativado int  = null,
	@telamedicoapenasconsulta int  = null,
	@alteraguiatelatransferencia int  = null,
	@altera_tabela_preco_convenio int  = null,
	@prescricaoexterno int  = null,
	@medico_apenascbo int  = null,
	@medico_cadastroespecialidade int  = null,
	@medico_cadastroclassificacao int  = null,
	@medico_cadastrohorario int  = null,
	@tutorprescricao int  = null,
	@medico int  = null,
	@administracusto int  = null,
	@excluibaixafinanceirocompensado int  = null,
	@excluiragendaconsulta int  = null,
	@permitereemprimirprescricao int  = null,
	@permitealteranome int  = null,
	@preparakitmedicamento int  = null,
	@permite_alterar_lanc_pagterceiro int  = null,
	@naopermitealteraragendamento int  = null,
	@naopermitealteracaofinanceiro int  = null,
	@referencia int  = null,
	@unidadeencaminhamento int  = null,
	@permite_apenas_lancar_contasreceber int  = null,
	@permite_conferir_laudo int  = null,
	@usuariounimed int  = null,
	@gerente int  = null,
	@naopermitecancelarregistros int  = null,
	@permissaopredevolucao int  = null,
	@permissaodevolucao int  = null,
	@permitedevolucaodireta int  = null,
	@medico_cadastrohonorario int  = null,
	@relprescsomentedieta int  = null,
	@cpf varchar(11)  = null,
	@rg varchar(12)  = null,
	@datanasc datetime  = null,
	@inicializarsenha int  = null,
	@data_atualizacao_senha datetime  = null,
	@pres_cad_tutor int  = null
as
begin
	set nocount on
	insert into dbo.usuario
		( nome, logon, senha, atualizacao, administralicenca, sndi, snda, snde, almoxarifadoi, almoxarifadoa, almoxarifadoe, farmaciai, farmaciaa, farmaciae, estoquei, estoquea, estoquee, emailpadraocotacao, prescricaointerno, prescricaoambulatorial, prescricaourgencia, ccpadraocotacao, observacao, desativado, telamedicoapenasconsulta, alteraguiatelatransferencia, altera_tabela_preco_convenio, prescricaoexterno, medico_apenascbo, medico_cadastroespecialidade, medico_cadastroclassificacao, medico_cadastrohorario, tutorprescricao, medico, administracusto, excluibaixafinanceirocompensado, excluiragendaconsulta, permitereemprimirprescricao, permitealteranome, preparakitmedicamento, permite_alterar_lanc_pagterceiro, naopermitealteraragendamento, naopermitealteracaofinanceiro, referencia, unidadeencaminhamento, permite_apenas_lancar_contasreceber, permite_conferir_laudo, usuariounimed, gerente, naopermitecancelarregistros, permissaopredevolucao, permissaodevolucao, permitedevolucaodireta, medico_cadastrohonorario, relprescsomentedieta, cpf, rg, datanasc, inicializarsenha, data_atualizacao_senha, pres_cad_tutor)
	values
		(@nome,@logon,@senha,@atualizacao,@administralicenca,@sndi,@snda,@snde,@almoxarifadoi,@almoxarifadoa,@almoxarifadoe,@farmaciai,@farmaciaa,@farmaciae,@estoquei,@estoquea,@estoquee,@emailpadraocotacao,@prescricaointerno,@prescricaoambulatorial,@prescricaourgencia,@ccpadraocotacao,@observacao,@desativado,@telamedicoapenasconsulta,@alteraguiatelatransferencia,@altera_tabela_preco_convenio,@prescricaoexterno,@medico_apenascbo,@medico_cadastroespecialidade,@medico_cadastroclassificacao,@medico_cadastrohorario,@tutorprescricao,@medico,@administracusto,@excluibaixafinanceirocompensado,@excluiragendaconsulta,@permitereemprimirprescricao,@permitealteranome,@preparakitmedicamento,@permite_alterar_lanc_pagterceiro,@naopermitealteraragendamento,@naopermitealteracaofinanceiro,@referencia,@unidadeencaminhamento,@permite_apenas_lancar_contasreceber,@permite_conferir_laudo,@usuariounimed,@gerente,@naopermitecancelarregistros,@permissaopredevolucao,@permissaodevolucao,@permitedevolucaodireta,@medico_cadastrohonorario,@relprescsomentedieta,@cpf,@rg,@datanasc,@inicializarsenha,@data_atualizacao_senha,@pres_cad_tutor)

	select @usuario = scope_identity()
end
go

