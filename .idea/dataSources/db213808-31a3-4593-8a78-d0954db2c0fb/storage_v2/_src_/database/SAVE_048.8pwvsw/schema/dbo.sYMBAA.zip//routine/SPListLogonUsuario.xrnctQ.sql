 CREATE PROCEDURE SPListLogonUsuario @logon varchar(15) 
 AS 
 BEGIN 
    SELECT USUARIO, LOGON FROM USUARIO  
    WHERE LOGON = @logon   
 END
 go

