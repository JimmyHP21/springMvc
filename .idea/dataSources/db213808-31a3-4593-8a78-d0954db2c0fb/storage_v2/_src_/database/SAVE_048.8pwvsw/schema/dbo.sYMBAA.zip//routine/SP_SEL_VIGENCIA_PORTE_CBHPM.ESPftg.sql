CREATE PROCEDURE [dbo].[SP_SEL_VIGENCIA_PORTE_CBHPM]                                                                                              
                       @ID_VIGENCIA            AS INTEGER      = NULL,                                                                            
                       @DESCRICAO_VIGENCIA     AS VARCHAR(100) = NULL                                                                             
AS                                                                                                                                                
   BEGIN                                                                                                                                          
       SET NOCOUNT ON                                                                                                                             
       IF @ID_VIGENCIA IS NOT NULL BEGIN                                                                                                          
           SELECT    ID_VIGENCIA                                                                                                                  
                   , DESCRICAO + ' - ' + CONVERT(varchar(10), DATA_INICIO_VIGENCIA,103) + ' - ' + CONVERT(varchar(10), DATA_FIM_VIGENCIA,103)     
                   , DATA_INICIO_VIGENCIA                                                                                                         
                   , DATA_FIM_VIGENCIA                                                                                                            
           FROM VIGENCIA_PORTE_CBHPM                                                                                                              
           WHERE                                                                                                                                  
               ID_VIGENCIA = @ID_VIGENCIA                                                                                                         
       END                                                                                                                                        
       ELSE IF @DESCRICAO_VIGENCIA IS NOT NULL BEGIN                                                                                              
           SELECT    ID_VIGENCIA                                                                                                                  
                   , DESCRICAO + ' - ' + CONVERT(varchar(10), DATA_INICIO_VIGENCIA,103) + ' - ' + CONVERT(varchar(10), DATA_FIM_VIGENCIA,103)     
                   , DATA_INICIO_VIGENCIA                                                                                                         
                   , DATA_FIM_VIGENCIA                                                                                                            
           FROM VIGENCIA_PORTE_CBHPM                                                                                                              
           WHERE                                                                                                                                  
               DESCRICAO LIKE @DESCRICAO_VIGENCIA + '%'                                                                                           
       END                                                                                                                                        
   END
go

